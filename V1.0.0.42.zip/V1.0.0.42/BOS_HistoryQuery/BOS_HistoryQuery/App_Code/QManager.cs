using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Collections;

namespace com.ddsc.core
{
 
 

    public class QueuePoolByLock<T>
    {
        readonly object _locker = new object();
        Thread[] _workers;
        int _DefaultThreadCount = 25;
        Queue<T> _itemQ = new Queue<T>();
        public delegate void ParameterHandler(T ff);
        private ParameterHandler m_ParameteExcute;
        public event ParameterHandler ParameterExcute
        {
            add
            {
                m_ParameteExcute += value;
            }
            remove
            {
                m_ParameteExcute -= value;
            }
        }
 
        public QueuePoolByLock()
        {
            _workers = new Thread[_DefaultThreadCount];

            for (int i = 0; i < _DefaultThreadCount; i++)
            {
                _workers[i] = new Thread(execQueueData);
                _workers[i].IsBackground = true;

            }
        }

        public QueuePoolByLock(int workerCount)
        {
            _DefaultThreadCount = workerCount;
            _workers = new Thread[_DefaultThreadCount];

            for (int i = 0; i < _DefaultThreadCount; i++)
            {
                _workers[i] = new Thread(execQueueData);
                _workers[i].IsBackground = true;

            }
        }

        public void Go()
        {
            for (int i = 0; i < _workers.Length; i++)
            {
                _workers[i].Start();
            }
        }
        public void Dispose()
        {
            foreach (Thread worker in _workers)
                worker.Abort();
            GC.SuppressFinalize(this);
        }
        public void Shutdown(bool waitForWorkers)
        {
            T f = default(T);
            foreach (Thread worker in _workers)
                PutData2Queue(f);

            if (waitForWorkers)
            {
                foreach (Thread worker in _workers)
                    worker.Join();
            }
            else
            {
                foreach (Thread worker in _workers)
                    worker.Abort();
            }
        }

        public void PutData2Queue(T item)
        {
            lock (_locker)
            {
                _itemQ.Enqueue(item);
                Monitor.Pulse(_locker);
            }
        }

        internal void execQueueData()
        {
            while (true)
            {
                T item;
                lock (_locker)
                {
                    while (_itemQ.Count == 0) Monitor.Wait(_locker);
                    item = _itemQ.Dequeue();
                }
                if (item == null) return;
                if (m_ParameteExcute != null)
                    m_ParameteExcute(item);

            }
        }
    }

    public class ManualResetEventByLock
    {
        readonly object _locker = new object();
        bool _signal;

        public void WaitOne()
        {
            lock (_locker)
            {
                while (!_signal) Monitor.Wait(_locker);
            }
        }

        public void Set()
        {
            lock (_locker) { _signal = true; Monitor.PulseAll(_locker); }
        }

        public void Reset() { lock (_locker) _signal = false; }
    }

    public class AutoResetEventByLock
    {
        readonly object _locker = new object();
        bool _signal;

        public void WaitOne()
        {
            lock (_locker)
            {
                while (!_signal) Monitor.Wait(_locker);
                _signal = false;
            }
        }

        public void Set()
        {
            lock (_locker) { _signal = true; Monitor.Pulse(_locker); }
        }

        public void Reset() { lock (_locker) _signal = false; }
    }
}
