﻿using System;
using System.IO;
using System.Text;
 
    /// <summary>
    /// WriterLOG 的摘要描述。

    /// </summary>
    public class WriterLOG7
    {
        StreamWriter sw_Log;
        public string ASTR_FileName = null;
        public string ASTR_FolderName = null;

        public string T1b 
        {
            get
            {
                return mstr_T1b;
            }
            set
            {
                mstr_T1b = value;
            }
        }
        public string T1e
        {
            get
            {
                return mstr_T1e;
            }
            set
            {
                mstr_T1e = value;
            }
        }
        public string T4b
        {
            get
            {
                return mstr_T4b;
            }
            set
            {
                mstr_T4b = value;
            }
        }
        public string T4e
        {
            get
            {
                return mstr_T4e;
            }
            set
            {
                mstr_T4e = value;
            }
        }
        private string mstr_T1b = "";
        private string mstr_T1e = "";
        private string mstr_T4b = "";
        private string mstr_T4e = "";
        public WriterLOG7(string STR_FileName)
        {
            try
            {
                string logPath = System.Configuration.ConfigurationManager.AppSettings["LOG_PATH"];

                ASTR_FileName = STR_FileName;
                //ASTR_FolderName ="e:\\Log\\" + DateTime.Now.ToString("yyyyMMdd");
                ASTR_FolderName = logPath + DateTime.Now.ToString("yyyyMMdd");
                //if (!Directory.Exists("e:\\Log"))
                if (!Directory.Exists(logPath))
                {
                    //Directory.CreateDirectory( "e:\\Log");
                    Directory.CreateDirectory(logPath);
                }
                if (!Directory.Exists(ASTR_FolderName))
                {
                    Directory.CreateDirectory(ASTR_FolderName);
                }
                //string str_path = "e:\\Log\\"
                string str_path = logPath
                    + DateTime.Now.ToString("yyyyMMdd") + "\\" + ASTR_FileName + DateTime.Now.ToString("yyyyMMdd") + ".txt";
                if (File.Exists(str_path))
                {
                    sw_Log = File.AppendText(str_path);
                }
                else
                {
                    sw_Log = File.CreateText(str_path);
                }
                sw_Log.WriteLine(DateTime.Now.ToString("yyyyMMdd HH:mm:ss.fff") + " -->:" + "Open Log File");
                sw_Log.Flush();
            }
            catch (Exception ex)
            {
                string test = ex.ToString();
            }
        }

        public WriterLOG7(string STR_FileName,bool Cashout)
        {
            try
            {
                string logPath = System.Configuration.ConfigurationManager.AppSettings["LOG_PATH"];

                ASTR_FileName = STR_FileName;
                //ASTR_FolderName ="e:\\Log\\" + DateTime.Now.ToString("yyyyMMdd");
                ASTR_FolderName = logPath+"cashout\\" + DateTime.Now.ToString("yyyyMMdd");
                //if (!Directory.Exists("e:\\Log"))
                if (!Directory.Exists(logPath))
                {
                    //Directory.CreateDirectory( "e:\\Log");
                    Directory.CreateDirectory(logPath);
                }
                if (!Directory.Exists(ASTR_FolderName))
                {
                    Directory.CreateDirectory(ASTR_FolderName);
                }
                //string str_path = "e:\\Log\\"
                string str_path = logPath + "cashout\\"
                    + DateTime.Now.ToString("yyyyMMdd") + "\\" + ASTR_FileName + DateTime.Now.ToString("yyyyMMdd") + ".txt";
                if (File.Exists(str_path))
                {
                    sw_Log = File.AppendText(str_path);
                }
                else
                {
                    sw_Log = File.CreateText(str_path);
                }
                sw_Log.WriteLine(DateTime.Now.ToString("yyyyMMdd HH:mm:ss.fff") + " -->:" + "Open Log File");
                sw_Log.Flush();
            }
            catch (Exception ex)
            {
                string test = ex.ToString();
            }
        }
        ~WriterLOG7()
        {
            Close();
        }
        public void Close()
        {
            try
            {
                if (sw_Log != null)
                {
                    sw_Log.Close();
                }
            }
            catch (Exception ex)
            {
            }
        }

        public void WriteEntryData(string l_strLogData)
        {
            //			sw_Log.WriteLine(DateTime.Now.ToString("yyyyMMdd HH:mm:ss -->:" + l_strLogData.Replace("'"," ")));
            try
            {
                sw_Log.WriteLine(DateTime.Now.ToString("yyyyMMdd HH:mm:ss.fff") + " -->:" + l_strLogData);
                sw_Log.Flush();
            }
            catch
            {
            }
        }
    }

    public class FileDate
    {
        public void delfile(int FileDate)
        {
            if (!Directory.Exists(AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "\\Log"))
            {
                Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "\\Log");
            }
            string[] dir = Directory.GetDirectories(AppDomain.CurrentDomain.BaseDirectory.ToString().Trim() + "Log");
            string[] dt = new string[dir.Length];
            int chk_day = int.Parse((DateTime.Now.AddDays(-(FileDate - 1))).ToString("yyyyMMdd"));

            for (int i = 0; i < dir.Length; i++)
            {
                dt[i] = (Directory.GetLastWriteTime(dir[i])).ToString("yyyyMMdd");
                if (int.Parse(dt[i]) < chk_day)
                {
                    Directory.Delete(dir[i], true);
                }
            }
        }
    }
 