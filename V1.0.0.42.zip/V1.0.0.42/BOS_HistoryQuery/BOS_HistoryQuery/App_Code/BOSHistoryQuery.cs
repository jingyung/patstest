﻿using System;
using System.Web;
using System.Text;
using System.Collections;
using System.Web.Services;
using System.Web.Services.Protocols;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Xml;
using System.Configuration;
using System.Data.Odbc;
using System.Collections.Generic;
using System.Net.Sockets;
using System.Runtime.InteropServices;
using MessageServer;
using com.ddsc.tool;
using com.ddsc.core;
/// <summary>
/// BOSHistoryQuery 的摘要描述
/// added 20100802 此webservice 只包含BOS查詢的部份 
/// ASTR_ConfigConnection3 : 連接本機VIPMOBDB 撈每日收盤後從後台轉檔的資料
/// ASTR_ConfigConnection2 : 連接有 VIPConfigDB的機器 , 取新舊商品名轉換的table(音需要function  dbo.fnGetProductId)
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class BOSHistoryQuery : System.Web.Services.WebService
{
    public class clsTWHOLIDAY_SET
    {
        public string HOLIDAY_DATE { get; set; }
        public string NOTE { get; set; }
        public string TWDAY { get; set; }
        public string ACTION_TYPE { get; set; }

    }
    string ASTR_ConfigConnection3;
    string ASTR_ConfigConnection2;
    string ASTR_ConfigConnection;
    string ASTR_TradeConnection;
    string ASTR_InfoConnection;
    string m_strOleDBConn;
    string AEConfigSQLConnection;
    bool closeday = false;
    class ErrorMessage
    {
        internal const string MSG0001 = "歷史轉檔中";
        internal const string MSG0002 = "無平倉資料";
        //internal const string MSG0003 = "14:30～16:30進行轉檔作業，16:30後請從歷史資料查詢 !!";
        //internal const string MSG0004 = "此功能16:30之後，暫停服務";
        internal const string MSG0005 = "處理發生錯誤的訊息";
        internal const string MSG0006 = "暫停服務";
        internal const string MSG0007 = "帳務過帳中,暫停出金作業,造成不便,敬請見諒!";

        // internal const string MSG0008 = "此功能23:59之後，暫停服務";


        // internal const string MSG0009 = "當日平倉損益只能查詢到23:59，23:59後請改選擇歷史選項進行查詢 !";

        internal const string MSG0010 = "申請作業逾時";

    }
    public static LogManager _LM;
    static object _lockCaObjectFile = new object();

    public BOSHistoryQuery()
    {


        //如果使用設計的元件，請取消註解下行程式碼 
        //InitializeComponent(); 


        //added by philip 20100112
        ASTR_ConfigConnection3 = ConfigurationSettings.AppSettings["SQLConnection3"];
        m_strOleDBConn = ConfigurationSettings.AppSettings["ODBConnection"];
        ASTR_ConfigConnection2 = ConfigurationSettings.AppSettings["SQLConnection2"];

        AEConfigSQLConnection = ConfigurationSettings.AppSettings["AEConfigSQLConnection"];

        //判斷是否為假日
        if (DateTime.Now.DayOfWeek.GetHashCode() == 0)
        {
            closeday = ConfigurationSettings.AppSettings["MOBGW_CloseDay"].ToString().Contains("7");
        }
        else
        {
            closeday = ConfigurationSettings.AppSettings["MOBGW_CloseDay"].ToString().Contains(DateTime.Now.DayOfWeek.GetHashCode().ToString());
        }
        string logPath = System.Configuration.ConfigurationManager.AppSettings["LOG_PATH"];
        if (_LM == null)
        {
            _LM = new LogManager(logPath);

            //_LM.AddFileWriter("WS_LOG", new FileWriter(logPath, "WS_LOG"));
            //_LM.AddFileWriter("WS_RECV", new FileWriter(logPath, "WS_RECV"));
            //_LM.AddFileWriter("WS_SEND", new FileWriter(logPath, "WS_SEND"));
            //_LM.AddFileWriter("WS_ERROR", new FileWriter(logPath, "WS_ERROR"));

            //_LM.AddFileWriter("WS_OPENRECV", new FileWriter(logPath, "WS_OPENRECV"));
            //_LM.AddFileWriter("WS_OPENSEND", new FileWriter(logPath, "WS_OPENSEND"));


        }
        else
        {
            //if (!_LM.checkFileWriter("WS_LOG"))
            //    _LM.AddFileWriter("WS_LOG", new FileWriter(logPath, "WS_LOG"));
            //if (!_LM.checkFileWriter("WS_RECV"))
            //    _LM.AddFileWriter("WS_RECV", new FileWriter(logPath, "WS_RECV"));
            //if (!_LM.checkFileWriter("WS_SEND"))
            //    _LM.AddFileWriter("WS_SEND", new FileWriter(logPath, "WS_SEND"));
            //if (!_LM.checkFileWriter("WS_ERROR"))
            //    _LM.AddFileWriter("WS_ERROR", new FileWriter(logPath, "WS_ERROR"));
            //if (!_LM.checkFileWriter("WS_OPENRECV"))
            //    _LM.AddFileWriter("WS_OPENRECV", new FileWriter(logPath, "WS_OPENRECV"));
            //if (!_LM.checkFileWriter("WS_OPENSEND"))
            //    _LM.AddFileWriter("WS_OPENSEND", new FileWriter(logPath, "WS_OPENSEND"));
        }

    }
    ~BOSHistoryQuery()
    {
        if (_LM != null)
        {
            _LM.Dispose();
        }
    }
    bool chkDBTime()
    {
        try
        {
            string DBTime = ConfigurationSettings.AppSettings["DBTime"].ToString();

            string[] DBTimes = DBTime.Split('|');

            //"0=1401~1600,1801~2000|1=1401~1600|2=1401~1600|3=1401~1600|4=1401~1600|5=1401~1600|6=1401~1600"

            foreach (string v in DBTimes)
            {
                string week = v.Split('=')[0];
                string value = v.Split('=')[1];

                if (week == ((int)DateTime.Now.DayOfWeek).ToString())
                {
                    string[] times = value.Split(',');
                    int now = int.Parse(DateTime.Now.ToString("HHmm"));
                    foreach (string time in times)
                    {
                        int begin = int.Parse(time.Split('~')[0]);
                        int end = int.Parse(time.Split('~')[1]);

                        if (now > begin && now < end)
                        {
                            return true;
                        }
                    }


                }
            }




        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", "chkDBTime" + ex.Message);
        }



        return false;
    }


    //[WebMethod]
    //public string HelloWorld()
    //{
    //    return "Hello World";
    //}

    ////20100110 added by philip 查詢FBWOSt(平倉資料暫存檔)內歷史資料可選的月份區間
    //[WebMethod]
    //public DataTable WS_getHistoryFBWOST_date_info(string mindate, string maxdate)
    //{
    //    DataTable dtData = new DataTable("DateSection");
    //    SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);
    //    SqlDataAdapter adp;

    //    string SqlCommand = " SELECT distinct  COMYM " +
    //                        "  FROM FBWOST " +
    //                        " WHERE     (OPTTRDDT BETWEEN '" + mindate + "' AND '" + maxdate + "')";
    //    adp = new SqlDataAdapter(SqlCommand, conn);
    //    adp.Fill(dtData);
    //    return dtData;
    //}



    ////20100119 added by philip 查詢FBWOST(平倉資料暫存檔)內歷史資料的最大與最小日期,幣別,商品類別,月份,C/P
    //[WebMethod]
    //public DataTable WS_getHistoryFBWOSTinfo(string company, string actno)
    //{
    //    DataTable dtData = new DataTable("Date");
    //    SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);
    //    SqlDataAdapter adp;
    //    string SqlCommand = " select  CURRENCY ,MIN(OPTTRDDT)as mindate ,MAX(OPTTRDDT)as maxdate from FBWOST where COMPANY = '" + company + "' and ACTNO ='" + actno + "'group by CURRENCY";
    //    adp = new SqlDataAdapter(SqlCommand, conn);
    //    adp.Fill(dtData);

    //    return dtData;

    //}



    ////20100112 added by philip 查詢FBSCUS(客戶帳款)內歷史資料的最大與最小日期與幣別
    //[WebMethod]
    //public DataTable WS_getHistoryFBSCUSinfo(string company, string actno)
    //{

    //    DataTable dtData = new DataTable("Date");
    //    SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);
    //    SqlDataAdapter adp;
    //    string SqlCommand = " select  CURRENCY ,MIN(TDDT)as mindate ,MAX(TDDT)as maxdate from FBSCUS where COMPANY = '" + company + "' and ACTNO ='" + actno + "'group by CURRENCY";
    //    adp = new SqlDataAdapter(SqlCommand, conn);
    //    adp.Fill(dtData);
    //    return dtData;
    //}


    // 20100104 added by philip 查詢歷史保證金
    [WebMethod]
    public string[] WS_getHistoryMargin(string SourceType, string company, string account, string begin_date, string end_date, string currency)
    {
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getHistoryMargin]";

        if (DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["Transfer_BeginTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["Transfer_EndTime"].ToString()))
        {
            BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + SourceType + company + account + begin_date + end_date + currency);
            return new string[] { " <HistoryMargin><Result><Error>" + ErrorMessage.MSG0001 + "</Error><ErrorCode>0001</ErrorCode></Result></HistoryMargin> ", "" };
        }
        try
        {

            getActno(ref company, ref account);

            //檢查此查詢來源是否有權限
            //  bool isok = AuthorityCheck(SourceType);
            string[] strData = new string[1];
            // if (isok) 
            if (true)
            {
                DataSet dsData = new DataSet("HistoryMargin");
                DataTable[] dtData = new DataTable[1] { new DataTable("Result") };
                // DataTable[] dtData = new DataTable[1] { new DataTable("InfoData") };

                SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);

                //日期檢核由SQL做 假使日期超出資料庫內有的資料 就取符合的
                string SqlCommand =


                    //依TDDT為條件
                    /*
                                "select  Result.DWAMT , Result.TMPAB , Result.PROLOS , Result.TDDT , Result.Margin , Result.ClearMargin , isnull(CONVERT( varchar(15) ,Result.charge ),'N/A')as charge , isnull(CONVERT (varchar(15) ,Result.tax),'N/A')as tax" +

                               " from" +
                               " (Select  RR.DWAMT , RR.TMPAB , RR.PROLOS  , RR.TDDT,RR.Margin,RR.ClearMargin  , RR.ORIGNFEE ,RR.CTAXAMT ,  RR.UTPRICE8 , RR.UTPRICE9 , RR.KIND , " +
                              " CASE RR.KIND" +
                              " WHEN '1'  Then (RR.ORIGNFEE + isnull(RR.UTPRICE8,0))" +
                               " WHEN '2'  Then (RR.ORIGNFEE + isnull(RR.UTPRICE8,0))" +
                              " WHEN 'D'  Then (RR.ORIGNFEE + isnull(RR.UTPRICE8,0))" +
                              " ELSE (isnull(RR.UTPRICE8,0) - RR.ORIGNFEE)" +
                              " End " +
                              "\"charge\"," +
                              " CASE RR.KIND" +
                              " WHEN '1'  Then (RR.CTAXAMT + isnull(RR.UTPRICE9,0))" +
                               "WHEN '2'  Then (RR.CTAXAMT + isnull(RR.UTPRICE9,0))" +
                               "WHEN 'D'  Then (RR.CTAXAMT + isnull(RR.UTPRICE9,0))" +
                               "ELSE (isnull(RR.UTPRICE9,0) - RR.CTAXAMT)" +
                               "End" +
                               "\"tax\"" +
                              " from" +
                              " (select  S.DWAMT ,R.KIND ,R.ORIGNFEE ,R.CTAXAMT ,R.UPDT ,D.UTPRICE9,D.UTPRICE8,D.ORDDT , S.COMPANY,S.ACTNO ,S.TDDT ,(S.TMIAMT+S.TMEXCESS)as Margin ,(S.TMIAMT+S.TMEXCESS+S.BMKTVAL+S.SMKTVAL)as ClearMargin   ,S.TMPAB , S.PROLOS  " +
                              " from FBSCUS as S " +
                              " left join" +
                             "  (select  SUM(ORIGNFEE)as ORIGNFEE,SUM(CTAXAMT)as CTAXAMT, UPDT , COMPANY,ACTNO,KIND " +
                              " from FBTDTR " +
                             "  where COMPANY ='" + company + "' and ACTNO ='" + account + "' and CURRENCY ='" + currency + "' and KIND <> '8' and UPDT between '" + begin_date + "' and '" + end_date + "'" +
                              " group by UPDT ,COMPANY,ACTNO,KIND ) R    on ((S.ACTNO=R.ACTNO)and(S.COMPANY=R.COMPANY)and(S.TDDT=R.UPDT)) " +
                              " left join (" +
                              " select   SUM(UTPRICE8)as UTPRICE8 ,SUM(UTPRICE9)as UTPRICE9, ORDDT , COMPANY,ACTNO" +
                              " from FOTORD" +
                              " where COMPANY ='" + company + "' and ACTNO ='" + account + "' and CURRENCY ='" + currency + "' and (ORDTYPE='1' or ORDTYPE='2') and CLOSETRD='N' and ORDDT between '" + begin_date + "' and '" + end_date + "'" +
                              " group by ORDDT ,COMPANY,ACTNO) D on ((S.ACTNO=D.ACTNO)and(S.COMPANY=D.COMPANY)and(S.TDDT=D.ORDDT)) " +
                              " where S.ACTNO = '" + account + "' and S.COMPANY='" + company + "'" + " and S.CURRENCY='" + currency + "'  ) RR )Result" +
                               " where Result.TDDT between '" + begin_date + "' and '" + end_date + "'";
                    */


                // modified 20100809 改成已處理過的table
                    //20100204   加上op平倉損益 與 op未平倉損益

             //    "select  isnull(CONVERT( varchar(15) ,Result.OP_PROLOS ),'N/A')as OP_PROLOS ,   isnull(CONVERT( varchar(15) ,Result.OP_TMPAB ),'N/A')as OP_TMPAB , Result.DWAMT , Result.TMPAB , Result.PROLOS , Result.TDDT , Result.Margin , Result.ClearMargin , isnull(CONVERT( varchar(15) ,Result.charge ),'N/A')as charge , isnull(CONVERT (varchar(15) ,Result.tax),'N/A')as tax" +

             //  " from" +
                    //  " (Select  RR.OP_PROLOS ,RR.OP_TMPAB , RR.DWAMT , RR.TMPAB , RR.PROLOS  , RR.TDDT,RR.Margin,RR.ClearMargin  , RR.ORIGNFEE ,RR.CTAXAMT ,  RR.UTPRICE8 , RR.UTPRICE9 , RR.KIND , " +
                    // " CASE RR.KIND" +
                    // " WHEN '1'  Then (RR.ORIGNFEE + isnull(RR.UTPRICE8,0))" +
                    //  " WHEN '2'  Then (RR.ORIGNFEE + isnull(RR.UTPRICE8,0))" +
                    // " WHEN 'D'  Then (RR.ORIGNFEE + isnull(RR.UTPRICE8,0))" +
                    // " ELSE (isnull(RR.UTPRICE8,0) - RR.ORIGNFEE)" +
                    // " End " +
                    // "\"charge\"," +
                    // " CASE RR.KIND" +
                    // " WHEN '1'  Then (RR.CTAXAMT + isnull(RR.UTPRICE9,0))" +
                    //  "WHEN '2'  Then (RR.CTAXAMT + isnull(RR.UTPRICE9,0))" +
                    //  "WHEN 'D'  Then (RR.CTAXAMT + isnull(RR.UTPRICE9,0))" +
                    //  "ELSE (isnull(RR.UTPRICE9,0) - RR.CTAXAMT)" +
                    //  "End" +
                    //  "\"tax\"" +
                    // " from" +
                    // " (select  PTT.OP_PROLOS , TT.OP_TMPAB , S.DWAMT ,R.KIND ,R.ORIGNFEE ,R.CTAXAMT ,R.TRDDT ,D.UTPRICE9,D.UTPRICE8,D.ORDDT , S.COMPANY,S.ACTNO ,S.TDDT ,(S.TMIAMT+S.TMEXCESS)as Margin ,(S.TMIAMT+S.TMEXCESS+S.BMKTVAL+S.SMKTVAL)as ClearMargin   ,S.TMPAB , S.PROLOS  " +
                    // " from FBSCUS as S " +
                    // " left join" +
                    //"  (select  SUM(ORIGNFEE)as ORIGNFEE,SUM(CTAXAMT)as CTAXAMT, TRDDT , COMPANY,ACTNO,KIND " +
                    // " from FBTDTR " +
                    //"  where COMPANY ='" + company + "' and ACTNO ='" + account + "' and CURRENCY ='" + currency + "' and KIND <> '8' and TRDDT between '" + begin_date + "' and '" + end_date + "'" +
                    // " group by TRDDT ,COMPANY,ACTNO,KIND ) R    on ((S.ACTNO=R.ACTNO)and(S.COMPANY=R.COMPANY)and(S.TDDT=R.TRDDT)) " +
                    // " left join " +
                    //       //added 201002024 加上op平倉損益 與 op未平倉損益

             // "  (select sum(T.OP_TMPAB) as OP_TMPAB , T.offsetdate " +
                    // "  from " +
                    // "  (select COMPANY , ACTNO , offsetdate , PS , OPTPRIC1 , TRDPRC1 " +
                    // "            , case when PS='B' then (OPTPRIC1 - TRDPRC1)        " +
                    // "                  when PS='S' then (TRDPRC1 - OPTPRIC1)          " +
                    // "                   end \"OP_TMPAB\"                              " +
                    // "  from FBWOST " +
                    // "  where COMPANY ='" + company + "' and ACTNO ='" + account + "' and comtype ='1' and offsetdate between '" + begin_date + "' and '" + end_date + "')T " +
                    // "  group by T.offsetdate )TT " +
                    // "  on (TT.offsetdate =S.TDDT ) " +
                    // "  left join " +
                    //       //----------------------------------------------------------------FOWOPT    op未平倉損益
                    //  "     (select sum(PT.OP_PROLOS) as OP_PROLOS , PT.TRDDT  " +
                    //  "     from " +
                    //  "     (select COMPANY , ACTNO , TRDDT , PS , TRDPRE1 , TRDPRC1 " +
                    //   "              , case when PS='B' then (TRDPRE1 - TRDPRC1) " +
                    //   "	                 when PS='S' then (TRDPRC1 - TRDPRE1)" +
                    //   "	                 end \"OP_PROLOS\"        " +
                    //   "    from FOWOPT " +
                    //   "    where COMPANY ='" + company + "' and ACTNO ='" + account + "' and comtype ='1' and TRDDT between '" + begin_date + "' and '" + end_date + "')PT" +
                    //    "   group by PT.TRDDT )PTT " +
                    //    "   on (PTT.TRDDT =S.TDDT ) " +
                    //    "   left join " +



             // "(" +

             // " select   COMPANY , ORDDT ,ACTNO, SUM(UTPRICE8)as UTPRICE8 ,SUM(UTPRICE9)as UTPRICE9 " +
                    // " from FOTORD" +
                    // " where COMPANY ='" + company + "' and ACTNO ='" + account + "' and CURRENCY ='" + currency + "' and (ORDTYPE='1' or ORDTYPE='2') and CLOSETRD='Y' and ORDDT between '" + begin_date + "' and '" + end_date + "'" +
                    // " group by ORDDT ,COMPANY,ACTNO) D on ((S.ACTNO=D.ACTNO)and(S.COMPANY=D.COMPANY)and(S.TDDT=D.ORDDT)) " +
                    // " where S.ACTNO = '" + account + "' and S.COMPANY='" + company + "'" + " and S.CURRENCY='" + currency + "'  ) RR )Result" +
                    //  " where Result.TDDT between '" + begin_date + "' and '" + end_date + "'" +
                    //   "  order by TDDT DESC ";


              //WS_getHistoryMargin(string SourceType, string company, string account, string begin_date, string end_date, string currency)
                    //"select  isnull(CONVERT( varchar(15) ,Result.OP_PROLOS ),'N/A')as OP_PROLOS ,   isnull(CONVERT( varchar(15) ,Result.OP_TMPAB ),'N/A')as OP_TMPAB , Result.DWAMT , Result.TMPAB , Result.PROLOS , Result.TDDT , Result.Margin , Result.ClearMargin , isnull(CONVERT( varchar(15) ,Result.charge ),'N/A')as charge , isnull(CONVERT (varchar(15) ,Result.tax),'N/A')as tax" +

               //" select isnull(CONVERT( decimal(18,2) ,OP_PROLOS ),'0')as OP_PROLOS , isnull(CONVERT( decimal(18,2),OP_TMPAB ),'0')as OP_TMPAB , DWAMT , TMPAB , PROLOS , TDDT , Margin , ClearMargin , isnull(CONVERT( decimal(18,2) ,charge ),'0')as charge , isnull(CONVERT( decimal(18,2),tax),'0')as tax  from HistoryMarginPreQuery  " +
                    //" where COMPANY = '" + company + "'  and Actno='" + account + "' and Currency='" + currency + "' and TDDT between '" + begin_date + "'  and '" + end_date + "'";



                "select TDATE tddt,CTDAB Margin,OPTEQUITY ClearMargin,ORIGNFEE charge,CTAXAMT tax,OSPRTLOS TMPAB,PRTLOS PROLOS,DWAMT,OPTRL OP_TMPAB,OPTPRTLOS OP_PROLOS,BPREMIUM,SPREMIUM,FU1921 ,ORDPREMUM "
                + "from FDTFM where tdate  between '" + begin_date + "'  and '" + end_date + "' and firm='" + company + "' and actno='" + account + "' and ccy='" + currency + "'  order by TDATE asc  ";



                DataTable dtReturn = new DataTable("Result");

                dtReturn.Columns.Add("SYSDATE").DefaultValue = DateTime.Now.ToString("yyyy/MM/dd");
                dtReturn.Columns.Add("SYSTIME").DefaultValue = DateTime.Now.ToString("HH:mm:ss");
                SqlDataAdapter adp;
                adp = new SqlDataAdapter(SqlCommand, conn);
                adp.Fill(dtReturn);

                dtData[0] = dtReturn.Clone();

                foreach (DataColumn dc in dtData[0].Columns)
                {
                    dc.DataType = typeof(string);
                }

                foreach (DataRow dr in dtReturn.Rows)
                {
                    DataRow drNew = dtData[0].NewRow();
                    drNew["tddt"] = dr["tddt"].ToString();
                    drNew["Margin"] = NumberTrim(dr["Margin"].ToString());
                    drNew["ClearMargin"] = NumberTrim(dr["ClearMargin"].ToString());
                    drNew["FU1921"] = NumberTrim(dr["FU1921"].ToString());
                    drNew["charge"] = NumberTrim(dr["charge"].ToString());
                    drNew["tax"] = NumberTrim(dr["tax"].ToString());
                    drNew["TMPAB"] = NumberTrim(dr["TMPAB"].ToString());
                    drNew["PROLOS"] = NumberTrim(dr["PROLOS"].ToString());
                    drNew["DWAMT"] = NumberTrim(dr["DWAMT"].ToString());
                    drNew["OP_TMPAB"] = NumberTrim(dr["OP_TMPAB"].ToString());
                    drNew["OP_PROLOS"] = NumberTrim(dr["OP_PROLOS"].ToString());
                    drNew["BPREMIUM"] = NumberTrim(dr["BPREMIUM"].ToString());
                    drNew["SPREMIUM"] = NumberTrim(dr["SPREMIUM"].ToString());
                    drNew["ORDPREMUM"] = NumberTrim(dr["ORDPREMUM"].ToString());


                    
                    dtData[0].Rows.Add(drNew);
                }

                for (int Index = 0; Index < dtData.Length; Index++)
                {
                    dsData.Tables.Add(dtData[Index]);
                }

                strData[0] = dsData.GetXml();
                BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + SourceType + company + account + begin_date + end_date + currency);
                return strData;

            }
            else
            {
                strData[0] = " <HistoryMargin><Result><Error>無查詢權限</Error><ErrorCode>0005</ErrorCode></Result></HistoryMargin> ";
                return strData;
            }

        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_getHistoryMargin]" + ex.Message);
            return new string[] { " <HistoryMargin><Result><Error>WSError:" + ex.Message.ToString() + "</Error><ErrorCode>0005</ErrorCode></Result></HistoryMargin> ", "" };

        }

    }

    //20100104 歷史查詢來源權限檢查
    private bool AuthorityCheck(string SourceType)
    {
        bool isok = false;

        DataTable[] dtData = new DataTable[1] { new DataTable("result") };
        SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);
        string SqlCommand = " select Qualified from userauthority where sourcetype = '" + SourceType + "'";
        SqlDataAdapter adp;
        adp = new SqlDataAdapter(SqlCommand, conn);
        adp.Fill(dtData[0]);

        DataRow[] result = dtData[0].Select();

        if (result.Length == 0)
        {
            return isok;
        }
        else if (result[0]["Qualified"].ToString() == "Y")
        {
            return isok = true;
        }
        else
        {
            return isok;
        }
    }

    // 20100119 added by philip 查詢歷史平倉損益(明細)
    [WebMethod]
    public string[] WS_getHistoryEquity(string SourceType, string company, string account, string begin_date, string end_date, string currency)
    {
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getHistoryEquity]";


        if (DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["Transfer_BeginTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["Transfer_EndTime"].ToString()))
        {
            BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + SourceType + company + account + begin_date + end_date + currency);
            return new string[] { " <HistoryEquity><Result><Error>" + ErrorMessage.MSG0001 + "</Error><ErrorCode>0001</ErrorCode></Result></HistoryEquity> ", "" };
        }

        try
        {

            getActno(ref company, ref account);
            //檢查此查詢來源是否有權限
            bool isok = AuthorityCheck(SourceType);
            string[] strData = new string[1];
            if (isok)
            {
                DataSet dsData = new DataSet("HistoryEquity");
                DataTable[] dtData = new DataTable[1] { new DataTable("Result") };


                SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);

                //日期檢核由SQL做 假使日期超出資料庫內有的資料 就取符合的
                //string SqlCommand =

                //     "   select Result.OFFSETDATE , Result.OPTTRDDT , Result.ProductName , Result.TRD_ORDNO , Result.PS , Result.TRDPRC1 , Result.OFFSETQTY , Result.OSPRTLOS , Result.OPT_ORDNO  , Result.OPTPRIC1 , Result.CURRENCY , Result.TRD_charge ,Result.OPT_charge , Result.TRD_tax , Result.OPT_tax , ( Result.OSPRTLOS - Result.TRD_charge - Result.OPT_charge - Result.TRD_tax - Result.OPT_tax ) as Equity " +
                //     "   from " +
                //     "   (    " +
                //     "   select Q.OFFSETDATE , Q.OPTTRDDT , Q.ProductName , Q.TRD_ORDNO , Q.PS , Q.TRDPRC1 , Q.OFFSETQTY , Q.OSPRTLOS_a , Q.OPT_ORDNO  , Q.OPTPRIC1 , Q.CURRENCY , Q.KIND , CASE Q.KIND " +
                //     "   when '1' then (Q.ORIGNFEE+Q.UTPRICE8) " +
                //     "   when '2' then (Q.ORIGNFEE+Q.UTPRICE8) " +
                //     "   when 'D' then (Q.ORIGNFEE+Q.UTPRICE8) " +
                //     "   else (Q.UTPRICE8-Q.ORIGNFEE) " +
                //     "   end  " +
                //     "   \"TRD_charge\"  " +
                //     "   ,CASE Q.KIND    " +
                //     "   when '1' then (Q.CTAXAMT+Q.UTPRICE9) " +
                //     "   when '2' then (Q.CTAXAMT+Q.UTPRICE9) " +
                //     "   when 'D' then (Q.CTAXAMT+Q.UTPRICE9) " +
                //     "   else (Q.UTPRICE9-Q.CTAXAMT) " +
                //     "   end " +
                //     "   \"TRD_tax\"    " +
                //     "   ,CASE Q.OPT_KIND " +
                //     "   when '1' then (Q.OPT_ORIGNFEE+Q.OPT_UTPRICE8) " +
                //     "   when '2' then (Q.OPT_ORIGNFEE+Q.OPT_UTPRICE8) " +
                //     "   when 'D' then (Q.OPT_ORIGNFEE+Q.OPT_UTPRICE8) " +
                //     "   else (Q.OPT_UTPRICE8-Q.OPT_ORIGNFEE) " +
                //     "   end " +
                //     "   \"OPT_charge\"  " +
                //     "   ,CASE Q.OPT_KIND " +
                //     "   when '1' then (Q.OPT_CTAXAMT+Q.OPT_UTPRICE9) " +
                //     "   when '2' then (Q.OPT_CTAXAMT+Q.OPT_UTPRICE9) " +
                //     "   when 'D' then (Q.OPT_CTAXAMT+Q.OPT_UTPRICE9) " +
                //     "   else (Q.OPT_UTPRICE9-Q.OPT_CTAXAMT) " +
                //     "   end  " +
                //     "   \"OPT_tax\" " +
                //    //計算Option的平倉損益 added by philip 20100203

                //     " , CASE WHEN Q.COMTYPE='1' AND Q.PS='B' THEN ((Q.OPTPRIC1 - Q.TRDPRC1)*Q.OFFSETQTY*50) " +
                //     "  WHEN Q.COMTYPE='1' AND Q.PS='S' THEN ((Q.TRDPRC1 - Q.OPTPRIC1)*Q.OFFSETQTY*50) " +
                //     "  WHEN Q.COMTYPE='0' THEN Q.OSPRTLOS_a " +
                //     "  end \"OSPRTLOS\" " +

                //     "   from " +
                //     "   ( " +
                //     "   select  T.COMTYPE , T.OFFSETDATE , T.TRD_ORDNO , T.CURRENCY , T.PS , T.ProductName  , T.TRDPRC1 , T.OPT_ORDNO , T.OPTTRDDT , T.OFFSETQTY , T.OPTPRIC1 , T.OSPRTLOS_a , R.KIND ,isnull( R.ORIGNFEE,0) as ORIGNFEE , isnull (R.CTAXAMT ,0) as CTAXAMT, isnull (D.UTPRICE8,0)as UTPRICE8  , isnull( D.UTPRICE9,0)as UTPRICE9 , OPT_R.OPT_KIND , isnull(OPT_R.OPT_ORIGNFEE,0) as OPT_ORIGNFEE , isnull(OPT_R.OPT_CTAXAMT,0) as OPT_CTAXAMT, isnull (OPT_D.OPT_UTPRICE8,0)as OPT_UTPRICE8 , isnull (OPT_D.OPT_UTPRICE9,0)as OPT_UTPRICE9 " + "   from " +
                //     "  (select   COMTYPE , OFFSETDATE , (TRDORDNO+' '+TRDLINESNO+TRDSEQNO) as TRD_ORDNO, (TRDORDNO+' '+TRDLINESNO) as TRD_ORDNO_A, CURRENCY , PS , dbo.YearMonth(COMNO,STKPRC,CALLPUT,COMYM)   as ProductName    , TRDPRC1   , (OPTORDNO+' '+OPTLINESNO+OPTSEQNO) as OPT_ORDNO ,(OPTORDNO+' '+OPTLINESNO) as OPT_ORDNO_A , OPTTRDDT , OFFSETQTY , OPTPRIC1 , OSPRTLOS as OSPRTLOS_a " +
                //     "   from FBWOST " +
                //     "   where COMPANY ='" + company + "' and ACTNO = '" + account + "' and OFFSETDATE between '" + begin_date + "' and '" + end_date + "')T " +
                //     "   left join " +
                //     "   (select KIND ,ORIGNFEE , CTAXAMT ,ORDNO as TRD_ORDNO  " +
                //     "   from FBTDTR  " +
                //     "    where COMPANY ='" + company + "' and ACTNO ='" + account + "'  and UPDT between '" + begin_date + "' and '" + end_date + "')R  " +
                //     "   on R.TRD_ORDNO = T.TRD_ORDNO " +
                //     "   left join " +
                //     "   (select UTPRICE8 ,UTPRICE9 , (ORDNO+' '+LINESNO) as TRD_ORDNO_A   " +
                //     "    from FOTORD   " +
                //     "   where COMPANY ='" + company + "' and ACTNO ='" + account + "' and  (ORDTYPE='1' or ORDTYPE='2') and CLOSETRD='N' and ORDDT between '" + begin_date + "' and '" + end_date + "')D " +
                //     "   on D.TRD_ORDNO_A=T.TRD_ORDNO_A " +
                //     "   left join " +
                //     "   (select KIND as OPT_KIND ,ORIGNFEE as OPT_ORIGNFEE , CTAXAMT as OPT_CTAXAMT ,ORDNO as OPT_ORDNO " +
                //     "    from FBTDTR  " +
                //     "    where COMPANY ='" + company + "' and ACTNO ='" + account + "'  and UPDT between '" + begin_date + "' and '" + end_date + "')OPT_R  " +
                //     "   on OPT_R.OPT_ORDNO = T.OPT_ORDNO " +
                //     "   left join " +
                //     "   (select UTPRICE8 as OPT_UTPRICE8 ,UTPRICE9 as OPT_UTPRICE9 , (ORDNO+' '+LINESNO) as OPT_ORDNO_A  " +
                //     "    from FOTORD   " +
                //     "   where COMPANY ='" + company + "' and ACTNO ='" + account + "' and (ORDTYPE='1' or ORDTYPE='2') and CLOSETRD='N' and ORDDT between '" + begin_date + "' and '" + end_date + "')OPT_D " +
                //     "   on OPT_D.OPT_ORDNO_A=T.OPT_ORDNO_A " +
                //     "   )Q " +
                //     "   )Result  order by offsetdate desc ";


                //modified 20100811 by philip 改查整理後的table
                //modified 20100528 by philip 

                string sqlcurrency = "";
                if (currency.Trim().Length > 0)
                {
                    sqlcurrency = " and CCY='" + currency + "' ";
                }
                string SqlCommand =


                    // " select Result.OFFSETDATE , Result.OPTTRDDT , Result.ProductName , Result.TRD_ORDNO , Result.PS , Result.TRDPRC1" +
                    // " , Result.OFFSETQTY , Result.OSPRTLOS , Result.OPT_ORDNO  , Result.OPTPRIC1 , Result.CURRENCY , Result.TRD_charge ,Result.OPT_charge , Result.TRD_tax , Result.OPT_tax" +
                    // " , ( Result.OSPRTLOS - Result.TRD_charge - Result.OPT_charge - Result.TRD_tax - Result.OPT_tax ) as Equity " +
                    // " from ( " +
                    // " select Q.OFFSETDATE , Q.OPTTRDDT , Q.ProductName , Q.TRD_ORDNO , Q.PS , Q.TRDPRC1 , Q.OFFSETQTY , Q.OSPRTLOS_a , Q.OPT_ORDNO " +
                    // " , Q.OPTPRIC1 , Q.CURRENCY , (Q.ORIGNFEE+Q.UTPRICE8) as TRD_charge , (Q.CTAXAMT+Q.UTPRICE9) as TRD_tax" +
                    //  " , (Q.OPT_ORIGNFEE+Q.OPT_UTPRICE8) as OPT_charge , (Q.OPT_CTAXAMT+Q.OPT_UTPRICE9) as OPT_tax  " +

                    //  " , CASE WHEN Q.COMTYPE='1' AND Q.PS='B' THEN ((Q.OPTPRIC1 - Q.TRDPRC1)*Q.OFFSETQTY*50) " +
                    //  " WHEN Q.COMTYPE='1' AND Q.PS='S' THEN ((Q.TRDPRC1 - Q.OPTPRIC1)*Q.OFFSETQTY*50)  " +
                    // "  WHEN Q.COMTYPE='0' THEN Q.OSPRTLOS_a   end \"OSPRTLOS\"  " +

                    // " from (    select  T.COMTYPE , T.OFFSETDATE , T.TRD_ORDNO , T.CURRENCY , T.PS , T.ProductName  , T.TRDPRC1 , T.OPT_ORDNO " +
                    // " , T.OPTTRDDT , T.OFFSETQTY , T.OPTPRIC1 , T.OSPRTLOS_a ,isnull( R.ORIGNFEE,0) as ORIGNFEE , isnull (R.CTAXAMT ,0) as CTAXAMT, isnull (D.UTPRICE8,0)as UTPRICE8" +
                    // " , isnull( D.UTPRICE9,0)as UTPRICE9  , isnull(OPT_R.OPT_ORIGNFEE,0) as OPT_ORIGNFEE " +
                    // " , isnull(OPT_R.OPT_CTAXAMT,0) as OPT_CTAXAMT, isnull (OPT_D.OPT_UTPRICE8,0)as OPT_UTPRICE8" +
                    // " , isnull (OPT_D.OPT_UTPRICE9,0)as OPT_UTPRICE9" +
                    // " from " +
                    // " (select   COMTYPE , OFFSETDATE , (TRDORDNO+' '+TRDLINESNO+TRDSEQNO) as TRD_ORDNO, (TRDORDNO+' '+TRDLINESNO) as TRD_ORDNO_A" +
                    // " , CURRENCY , PS , dbo.YearMonth(COMNO,STKPRC,CALLPUT,COMYM)   as ProductName    , TRDPRC1  " +
                    // " , (OPTORDNO+' '+OPTLINESNO+OPTSEQNO) as OPT_ORDNO ,(OPTORDNO+' '+OPTLINESNO) as OPT_ORDNO_A " +
                    // " , OPTTRDDT , OFFSETQTY , OPTPRIC1 , OSPRTLOS as OSPRTLOS_a  " +
                    // "  from FBWOST  " +
                    // " where COMPANY ='"+company+"' and ACTNO = '"+account+"' and OFFSETDATE between '"+begin_date+"' and '"+end_date+"')T  " +
                    // " left join  " +
                    //  " (select  ORDNO as TRD_ORDNO , TRDDT, ORIGNFEE , CTAXAMT   from FBTDTR   where COMPANY ='"+company+"' and ACTNO ='"+account+"' and KIND='2' and TRDDT between '"+begin_date+"' and '"+end_date+"')R  " +
                    //" on R.TRD_ORDNO = T.TRD_ORDNO  and R.TRDDT =T.OFFSETDATE   left join   (select ORDDT , (ORDNO+' '+LINESNO) as TRD_ORDNO_A  , UTPRICE8 ,UTPRICE9   " +
                    // " from FOTORD   where COMPANY ='"+company+"' and ACTNO ='"+account+"' and  (ORDTYPE='1' or ORDTYPE='2') and CLOSETRD='Y' " +
                    //  " and ORDDT between '"+begin_date+"' and '"+end_date+"')D on D.TRD_ORDNO_A=T.TRD_ORDNO_A  and D.ORDDT = T.OFFSETDATE " +
                    //  " left join  (select  ORDNO as OPT_ORDNO , TRDDT as OPT_TRDDT ,ORIGNFEE as OPT_ORIGNFEE , CTAXAMT as OPT_CTAXAMT  " +
                    // "  from FBTDTR   where COMPANY ='"+company+"' and ACTNO ='"+account+"' and KIND = '2' " +
                    // " and TRDDT between '"+begin_date+"' and '"+end_date+"')OPT_R   on OPT_R.OPT_ORDNO = T.OPT_ORDNO    and OPT_R.OPT_TRDDT = T.OFFSETDATE " +
                    //" left join  (select ORDDT as  OPT_ORDDT , (ORDNO+' '+LINESNO) as OPT_ORDNO_A , UTPRICE8 as OPT_UTPRICE8 ,UTPRICE9 as OPT_UTPRICE9" +
                    //" from FOTORD  where COMPANY ='"+company+"' and ACTNO ='"+account+"' and (ORDTYPE='1' or ORDTYPE='2') and CLOSETRD='Y' " +
                    //" and ORDDT between '"+begin_date+"' and '"+end_date+"')OPT_D  on OPT_D.OPT_ORDNO_A=T.OPT_ORDNO_A   and OPT_D.OPT_ORDDT =T.OFFSETDATE    )Q " +
                    //" ) Result ";

                    //" select distinct OFFSETDATE , OPTTRDDT , ProductName , TRD_ORDNO , PS , TRDPRC1 , OFFSETQTY , OSPRTLOS , OPT_ORDNO  , OPTPRIC1 , CURRENCY , TRD_charge  , TRD_tax  , OPT_charge ,  OPT_tax , Equity  from HistoryEquityClearListPreQuery" +
                    //" where company ='"+company+"'  and actno='"+account+"' and  offsetdate between '" + begin_date + "' and '" + end_date + "'";

                //modified by philip 20100816   HistoryEquityClearListPreQuery 設index . select時照index的順序 
                    //" select distinct  COMPANY , ACTNO , TRD_ORDNO , OPTTRDDT , OPT_ORDNO  ,OFFSETDATE  , ProductName , PS , convert( decimal(18,2),TRDPRC1) TRDPRC1, OFFSETQTY ,convert( decimal(18,2), OSPRTLOS  )OSPRTLOS ,convert( decimal(18,2), OPTPRIC1)OPTPRIC1 , CURRENCY , convert( decimal(18,2),TRD_charge  )TRD_charge,convert( decimal(18,2), TRD_tax) TRD_tax , convert( decimal(18,2),OPT_charge )OPT_charge, convert( decimal(18,2), OPT_tax) OPT_tax, convert( decimal(18,2),Equity)Equity,case when optexh='MTX' then '大小台互抵' else abbr end abbr,convert( decimal(18,2),stkprc)stkprc,HistoryEquityClearListPreQuery.callput, comym,trdtrddt,ordtype   from HistoryEquityClearListPreQuery  left join (select abbr,comno,callput from fbmcob)fbmcob on HistoryEquityClearListPreQuery.comno=fbmcob.comno and HistoryEquityClearListPreQuery.callput=fbmcob.callput " +
                    //  " where company ='" + company + "'  and actno='" + account + "' and  offsetdate between '" + begin_date + "' and '" + end_date + "'";

                " select FIRM	COMPANY,ACTNO,TRNNO	TRD_ORDNO	,OPTTRDDT,OPTTRNNO	OPT_ORDNO	,TRDDT	offsetdate	,"
        + "COMMODX	ProductName,BS	PS	,TRDPRC1,OFFSETQTY,OSPRTLOS,OPTPRC1 OPTPRIC1,CCY	CURRENCY	,"
        + "TRDCHARGE	TRD_charge	,TRDTAX	TRD_tax	,OPTCHARGE	OPT_charge	,OPTTAX	OPT_tax	,EQUITY,rtrim(ABBR)ABBR,"
        + "STKPRC,CALLPUT,COMYM,TRDDT trdtrddt,ORDTYPE "
        + "from FOFFSETM where trddt between '" + begin_date + "' and '" + end_date + "' and firm='" + company + "' and actno='" + account + "' " + sqlcurrency + "    order by TRDDT,COMMODX ";

                DataTable dtReturn = new DataTable("Result");

                dtReturn.Columns.Add("SYSDATE").DefaultValue = DateTime.Now.ToString("yyyy/MM/dd");
                dtReturn.Columns.Add("SYSTIME").DefaultValue = DateTime.Now.ToString("HH:mm:ss");
                SqlDataAdapter adp;
                adp = new SqlDataAdapter(SqlCommand, conn);
                adp.Fill(dtReturn);

                dtData[0] = dtReturn.Clone();

                foreach (DataColumn dc in dtData[0].Columns)
                {
                    dc.DataType = typeof(string);
                }

                foreach (DataRow dr in dtReturn.Rows)
                {
                    DataRow drNew = dtData[0].NewRow();
                    drNew["COMPANY"] = dr["COMPANY"].ToString();
                    drNew["ACTNO"] = dr["ACTNO"].ToString();
                    drNew["TRD_ORDNO"] = dr["TRD_ORDNO"].ToString();
                    drNew["OPTTRDDT"] = dr["OPTTRDDT"].ToString();
                    drNew["OPT_ORDNO"] = dr["OPT_ORDNO"].ToString();
                    drNew["offsetdate"] = dr["offsetdate"].ToString();

                    drNew["ProductName"] = dr["ProductName"].ToString();

                    drNew["PS"] = dr["PS"].ToString();
                    drNew["TRDPRC1"] = NumberTrim(dr["TRDPRC1"].ToString());
                    drNew["OFFSETQTY"] = dr["OFFSETQTY"].ToString();
                    drNew["OSPRTLOS"] = NumberTrim(dr["OSPRTLOS"].ToString());
                    drNew["OPTPRIC1"] = NumberTrim(dr["OPTPRIC1"].ToString());
                    drNew["CURRENCY"] = dr["CURRENCY"].ToString();
                    drNew["TRD_charge"] = NumberTrim(dr["TRD_charge"].ToString());
                    drNew["TRD_tax"] = NumberTrim(dr["TRD_tax"].ToString());
                    drNew["OPT_charge"] = NumberTrim(dr["OPT_charge"].ToString());
                    drNew["OPT_tax"] = NumberTrim(dr["OPT_tax"].ToString());
                    drNew["EQUITY"] = NumberTrim(dr["EQUITY"].ToString());
                    drNew["ABBR"] = dr["ABBR"].ToString();
                    drNew["STKPRC"] = dr["STKPRC"].ToString();
                    if (dr["callput"].ToString().Trim() != "")
                    {
                        drNew["callput"] = dr["callput"].ToString();
                    }
                    else
                    {
                        drNew["callput"] = "N";
                    }
                    drNew["COMYM"] = dr["COMYM"].ToString();
                    drNew["trdtrddt"] = dr["trdtrddt"].ToString();
                    drNew["ORDTYPE"] = dr["ORDTYPE"].ToString();
                    dtData[0].Rows.Add(drNew);
                }

                for (int Index = 0; Index < dtData.Length; Index++)
                {
                    dsData.Tables.Add(dtData[Index]);
                }

                strData[0] = dsData.GetXml();
                BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + SourceType + company + account + begin_date + end_date + currency);
                return strData;

            }
            else
            {
                strData[0] = " <HistoryEquity><Result><Error>無查詢權限</Error><ErrorCode>0005</ErrorCode></Result></HistoryEquity> ";
                return strData;
            }

        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_getHistoryEquity]" + ex.Message);
            return new string[] { " <HistoryEquity><Result><Error>WSError:" + ex.Message.ToString() + "</Error><ErrorCode>0005</ErrorCode></Result></HistoryEquity> ", "" };

        }


    }


    // 20100121 added by philip 查詢歷史平倉損益(彙總)
    [WebMethod]
    public string[] WS_getHistoryEquityCollect(string SourceType, string company, string account, string begin_date, string end_date, string currency, string comtype, string comym, string min_price, string max_price, string CP)
    {
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getHistoryEquityCollect]";
        if (DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["Transfer_BeginTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["Transfer_EndTime"].ToString()))
        {
            BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + SourceType + company + account + begin_date + end_date + currency + comtype + comym + min_price + max_price + CP);

            return new string[] { " <HistoryEquity><Result><Error>" + ErrorMessage.MSG0001 + "</Error><ErrorCode>0001</ErrorCode></Result></HistoryEquity> ", "" };
        }

        try
        {
            getActno(ref company, ref account);
            //檢查此查詢來源是否有權限
            bool isok = AuthorityCheck(SourceType);
            string[] strData = new string[1];
            if (isok)
            {
                DataSet dsData = new DataSet("HistoryEquity");
                DataTable[] dtData = new DataTable[1] { new DataTable("Result") };
                string sqlcondition = null;
                string comymcondidtion = null;

                SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);

                //modified by philip 20100813
                string productCondition = "";

                //先串商品類型
                if (comtype == "0")//期貨
                {
                    productCondition += " and comtype='0' ";
                }
                else if (comtype == "1")//選擇權
                {
                    productCondition += " and comtype='1' ";

                    if ((min_price != "" & max_price != "")) //選擇權商品 多串 callput & 履約價
                    {
                        productCondition += "   and stkprc between '" + min_price + "' and '" + max_price + "'";
                    }
                    if (CP != "") //選擇權商品 多串 callput & 履約價
                    {
                        productCondition += " and CALLPUT='" + CP + "' ";
                    }
                }
                //else if(comtype == "2") //期貨 選擇權都看
                //{                    
                //   productCondition += " ";
                //}

                //串商品月份
                if (comym != "")
                {
                    productCondition += " and comym='" + comym + "' ";
                }
                if (currency != "")
                {
                    productCondition += " and CCY='" + currency + "' ";
                }


                //若只要看選擇權 多串CP跟履約價的條件
                //if (comtype == "1")
                //{
                //    if (min_price != "" & max_price != "")
                //    {
                //        sqlcondition = " and COMTYPE = '" + comtype + "' and CALLPUT = '" + CP + "' and STKPRC between '" + min_price + "' and '" + max_price + "'";
                //    }
                //    else
                //    {
                //        sqlcondition = " and COMTYPE = '" + comtype + "' and CALLPUT = '" + CP + "'";
                //    }
                //}


                //if (comtype == "0")
                //{
                //    sqlcondition = " and COMTYPE = '" + comtype + "'";
                //}



                //if (comym == "")
                //{
                //    comymcondidtion = "  ";
                //}
                //else
                //{
                //    comymcondidtion = "  and COMYM ='" + comym + "' ";
                //}




                //日期檢核由SQL做 假使日期超出資料庫內有的資料 就取符合的
                //string SqlCommand =


                // "  select * "+
                // "  from "+
                // "  ( "+
                // "  select Result_A.COMYM,Result_A.STKPRC,Result_A.CALLPUT,Result_A.COMTYPE ,Result_A.OFFSETDATE,Result_A.OPTTRDDT , Result_A.ProductName , Result_A.TRD_ORDNO , Result_A.PS , Result_A.TRDPRC1 , Result_A.OFFSETQTY , Result_A.OSPRTLOS , Result_A.OPT_ORDNO  , Result_A.OPTPRIC1 , Result_A.CURRENCY , (Result_A.TRD_charge +Result_A.OPT_charge) as charge , (Result_A.TRD_tax + Result_A.OPT_tax) as tax , ( Result_A.OSPRTLOS + Result_A.TRD_charge + Result_A.OPT_charge + Result_A.TRD_tax + Result_A.OPT_tax ) as Equity  "+
                // "  from   "+
                // "  (   "+    
                // "  select  Q.COMYM,Q.STKPRC ,Q.CALLPUT ,Q.COMTYPE , Q.OFFSETDATE , Q.OPTTRDDT , Q.ProductName , Q.TRD_ORDNO , Q.PS , Q.TRDPRC1 , Q.OFFSETQTY , Q.OSPRTLOS , Q.OPT_ORDNO  , Q.OPTPRIC1 , Q.CURRENCY , Q.KIND "+
                // "  , CASE Q.KIND   "+
                // "   when '1' then (Q.ORIGNFEE+Q.UTPRICE8)"+
                // "   when '2' then (Q.ORIGNFEE+Q.UTPRICE8) "+ 
                // "   when 'D' then (Q.ORIGNFEE+Q.UTPRICE8)  "+ 
                // "   else (Q.UTPRICE8-Q.ORIGNFEE)    "+
                // "  end  \"TRD_charge\""+    
                // "   ,CASE Q.KIND "+     
                // "   when '1' then (Q.CTAXAMT+Q.UTPRICE9) "+
                // "     when '2' then (Q.CTAXAMT+Q.UTPRICE9)  "+
                // "   when 'D' then (Q.CTAXAMT+Q.UTPRICE9)   "+
                // "   else (Q.UTPRICE9-Q.CTAXAMT)    "+
                // "  end    \"TRD_tax\""+      
                // "   ,CASE Q.OPT_KIND   "+
                // "   when '1' then (Q.OPT_ORIGNFEE+Q.OPT_UTPRICE8)  "+
                // "    when '2' then (Q.OPT_ORIGNFEE+Q.OPT_UTPRICE8)  "+ 
                // "   when 'D' then (Q.OPT_ORIGNFEE+Q.OPT_UTPRICE8)   "+
                // "   else (Q.OPT_UTPRICE8-Q.OPT_ORIGNFEE)   "+ 
                // "  end    \"OPT_charge\" "+    
                // "  ,CASE Q.OPT_KIND    "+
                // "  when '1' then (Q.OPT_CTAXAMT+Q.OPT_UTPRICE9)  "+  
                // "  when '2' then (Q.OPT_CTAXAMT+Q.OPT_UTPRICE9)   "+ 
                // "  when 'D' then (Q.OPT_CTAXAMT+Q.OPT_UTPRICE9)  "+  
                // "  else (Q.OPT_UTPRICE9-Q.OPT_CTAXAMT)  "+  
                // "  end     \"OPT_tax\"  "+  
                // "  from  "+ 
                // "   (    select T.COMYM,T.STKPRC ,T.CALLPUT ,T.COMTYPE ,T.OFFSETDATE , T.TRD_ORDNO , T.CURRENCY , T.PS , T.ProductName  , T.TRDPRC1 , T.OPT_ORDNO , T.OPTTRDDT , T.OFFSETQTY , T.OPTPRIC1 , T.OSPRTLOS , R.KIND ,isnull( R.ORIGNFEE,0) as ORIGNFEE , isnull (R.CTAXAMT ,0) as CTAXAMT, isnull (D.UTPRICE8,0)as UTPRICE8  , isnull( D.UTPRICE9,0)as UTPRICE9 , OPT_R.OPT_KIND , isnull(OPT_R.OPT_ORIGNFEE,0) as OPT_ORIGNFEE , isnull(OPT_R.OPT_CTAXAMT,0) as OPT_CTAXAMT, isnull (OPT_D.OPT_UTPRICE8,0)as OPT_UTPRICE8 , isnull (OPT_D.OPT_UTPRICE9,0)as OPT_UTPRICE9 "+   
                // "  from   "+
                //"   (select   COMYM,STKPRC ,CALLPUT,COMTYPE,OFFSETDATE , (TRDORDNO+' '+TRDLINESNO+TRDSEQNO) as TRD_ORDNO, (TRDORDNO+' '+TRDLINESNO) as TRD_ORDNO_A, CURRENCY , PS , (COMNO+' '+COMYM) as ProductName  , TRDPRC1   , (OPTORDNO+' '+OPTLINESNO+OPTSEQNO) as OPT_ORDNO ,(OPTORDNO+' '+OPTLINESNO) as OPT_ORDNO_A , OPTTRDDT , OFFSETQTY , OPTPRIC1 , OSPRTLOS "+  
                //"    from FBWOST  "+  
                //"   where COMPANY ='"+company+"' and ACTNO = '"+account+"' and CURRENCY ='"+currency+"' and COMYM ='"+comym+"' and OFFSETDATE between '"+begin_date+"' and '"+end_date+"' )T  "+
                // "    left join   "+
                // "   (select KIND ,ORIGNFEE , CTAXAMT ,ORDNO as TRD_ORDNO   "+ 
                // "   from FBTDTR  "+   
                // "   where COMPANY ='"+company+"' and ACTNO ='"+account+"' and CURRENCY ='"+currency+"' and COMYM ='"+comym+"'  and UPDT between '"+begin_date+"' and '"+end_date+"')R     on R.TRD_ORDNO = T.TRD_ORDNO  "+
                // "    left join  "+
                // "    (select UTPRICE8 ,UTPRICE9 , (ORDNO+' '+LINESNO) as TRD_ORDNO_A   "+ 
                // "     from FOTORD  "+   
                // "     where COMPANY ='"+company+"' and ACTNO ='"+account+"' and  (ORDTYPE='1' or ORDTYPE='2') and CLOSETRD='N'  and CURRENCY ='"+currency+"' and COMYM ='"+comym+"' and ORDDT between '"+begin_date+"' and '"+end_date+"')D  "+ 
                // "   on D.TRD_ORDNO_A=T.TRD_ORDNO_A  "+
                // "    left join    (select KIND as OPT_KIND ,ORIGNFEE as OPT_ORIGNFEE , CTAXAMT as OPT_CTAXAMT ,ORDNO as OPT_ORDNO  "+
                // "     from FBTDTR     "+
                // "   where COMPANY ='"+company+"' and ACTNO ='"+account+"' and CURRENCY ='"+currency+"'  and COMYM ='"+comym+"'  and UPDT between '"+begin_date+"' and '"+end_date+"')OPT_R  "+ 
                // "    on OPT_R.OPT_ORDNO = T.OPT_ORDNO   "+
                // "   left join  "+ 
                // "   (select UTPRICE8 as OPT_UTPRICE8 ,UTPRICE9 as OPT_UTPRICE9 , (ORDNO+' '+LINESNO) as OPT_ORDNO_A  "+  
                // "    from FOTORD    "+  
                // "  where COMPANY ='"+company+"' and ACTNO ='"+account+"' and (ORDTYPE='1' or ORDTYPE='2') and CLOSETRD='N'   and CURRENCY ='"+currency+"'  and COMYM ='"+comym+"'and ORDDT between '"+begin_date+"' and '"+end_date+"')OPT_D "+   
                // "  on OPT_D.OPT_ORDNO_A=T.OPT_ORDNO_A    )Q    )Result_A )Result "+
                //   sqlcondition ;



                //string SqlCommand =



                //           " select Result.tax , Result.charge , Result.Equity , Result.OFFSETQTY , Result.OSPRTLOS , Result.ProductName , Result.OFFSETDATE , Result.CURRENCY , isnull(Result.GiveUp,0)as GiveUp " +
                //           " from " +
                //           " ( " +
                //           " select * " +
                //          "  from " +
                //           " ( select " +
                //          "  sum(Result_B.tax)as tax  , sum(Result_B.charge) as charge , sum(Result_B.Equity)as Equity , sum(Result_B.OFFSETQTY)as OFFSETQTY ,sum(Result_B.OSPRTLOS)as OSPRTLOS , Result_B.ProductName , Result_B.OFFSETDATE , Result_B.CURRENCY  " +
                //            " from   (  " +
                //           "  select Result_A.COMYM,Result_A.STKPRC,Result_A.CALLPUT,Result_A.COMTYPE ,Result_A.OFFSETDATE,Result_A.OPTTRDDT , Result_A.ProductName , Result_A.TRD_ORDNO , Result_A.PS , Result_A.TRDPRC1 , Result_A.OFFSETQTY , Result_A.OSPRTLOS , Result_A.OPT_ORDNO  , Result_A.OPTPRIC1 , Result_A.CURRENCY , (Result_A.TRD_charge +Result_A.OPT_charge) as charge , (Result_A.TRD_tax + Result_A.OPT_tax) as tax , ( Result_A.OSPRTLOS - Result_A.TRD_charge - Result_A.OPT_charge - Result_A.TRD_tax - Result_A.OPT_tax ) as Equity  " +
                //           "  from   " +
                //           "  (   " +
                //           "  select  Q.COMYM,Q.STKPRC ,Q.CALLPUT ,Q.COMTYPE , Q.OFFSETDATE , Q.OPTTRDDT , Q.ProductName , Q.TRD_ORDNO , Q.PS , Q.TRDPRC1 , Q.OFFSETQTY , Q.OSPRTLOS , Q.OPT_ORDNO  , Q.OPTPRIC1 , Q.CURRENCY , Q.KIND " +
                //           "  , CASE Q.KIND   " +
                //           "   when '1' then (Q.ORIGNFEE+Q.UTPRICE8)" +
                //           "   when '2' then (Q.ORIGNFEE+Q.UTPRICE8) " +
                //           "   when 'D' then (Q.ORIGNFEE+Q.UTPRICE8)  " +
                //           "   else (Q.UTPRICE8-Q.ORIGNFEE)    " +
                //           "  end  \"TRD_charge\"" +
                //           "   ,CASE Q.KIND " +
                //           "   when '1' then (Q.CTAXAMT+Q.UTPRICE9) " +
                //           "     when '2' then (Q.CTAXAMT+Q.UTPRICE9)  " +
                //           "   when 'D' then (Q.CTAXAMT+Q.UTPRICE9)   " +
                //           "   else (Q.UTPRICE9-Q.CTAXAMT)    " +
                //           "  end    \"TRD_tax\"" +
                //           "   ,CASE Q.OPT_KIND   " +
                //           "   when '1' then (Q.OPT_ORIGNFEE+Q.OPT_UTPRICE8)  " +
                //           "    when '2' then (Q.OPT_ORIGNFEE+Q.OPT_UTPRICE8)  " +
                //           "   when 'D' then (Q.OPT_ORIGNFEE+Q.OPT_UTPRICE8)   " +
                //           "   else (Q.OPT_UTPRICE8-Q.OPT_ORIGNFEE)   " +
                //           "  end    \"OPT_charge\" " +
                //           "  ,CASE Q.OPT_KIND    " +
                //           "  when '1' then (Q.OPT_CTAXAMT+Q.OPT_UTPRICE9)  " +
                //           "  when '2' then (Q.OPT_CTAXAMT+Q.OPT_UTPRICE9)   " +
                //           "  when 'D' then (Q.OPT_CTAXAMT+Q.OPT_UTPRICE9)  " +
                //           "  else (Q.OPT_UTPRICE9-Q.OPT_CTAXAMT)  " +
                //           "  end     \"OPT_tax\"  " +





                //           "  from  " +
                //           "   (    select T.COMYM,T.STKPRC ,T.CALLPUT ,T.COMTYPE ,T.OFFSETDATE , T.TRD_ORDNO , T.CURRENCY , T.PS , T.ProductName  , T.TRDPRC1 , T.OPT_ORDNO , T.OPTTRDDT , T.OFFSETQTY , T.OPTPRIC1 , T.OSPRTLOS , R.KIND ,isnull( R.ORIGNFEE,0) as ORIGNFEE , isnull (R.CTAXAMT ,0) as CTAXAMT, isnull (D.UTPRICE8,0)as UTPRICE8  , isnull( D.UTPRICE9,0)as UTPRICE9 , OPT_R.OPT_KIND , isnull(OPT_R.OPT_ORIGNFEE,0) as OPT_ORIGNFEE , isnull(OPT_R.OPT_CTAXAMT,0) as OPT_CTAXAMT, isnull (OPT_D.OPT_UTPRICE8,0)as OPT_UTPRICE8 , isnull (OPT_D.OPT_UTPRICE9,0)as OPT_UTPRICE9 " +
                //           "  from   " +
                //          "   (select   COMYM,STKPRC ,CALLPUT,COMTYPE,OFFSETDATE , (TRDORDNO+' '+TRDLINESNO+TRDSEQNO) as TRD_ORDNO, (TRDORDNO+' '+TRDLINESNO) as TRD_ORDNO_A, CURRENCY , PS , dbo.YearMonth(COMNO,STKPRC,CALLPUT,COMYM)   as ProductName  , TRDPRC1   , (OPTORDNO+' '+OPTLINESNO+OPTSEQNO) as OPT_ORDNO ,(OPTORDNO+' '+OPTLINESNO) as OPT_ORDNO_A , OPTTRDDT , OFFSETQTY , OPTPRIC1  " +

                //          ///////

                //           "   ,case when comtype='1' and PS='B' then (OPTPRIC1-TRDPRC1)" +
                //            "  when comtype='1' and PS='S' then (TRDPRC1-OPTPRIC1)" +
                //           "   else (OSPRTLOS)" +
                //            "  end \"OSPRTLOS\" " +




                //          "    from FBWOST  " +
                //          "   where COMPANY ='" + company + "' and ACTNO = '" + account + "' and CURRENCY ='" + currency + "'" + comymcondidtion + " and OFFSETDATE between '" + begin_date + "' and '" + end_date + "' )T  " +
                //           "    left join   " +
                //           "   (select KIND ,ORIGNFEE , CTAXAMT ,ORDNO as TRD_ORDNO   " +
                //           "   from FBTDTR  " +
                //           "   where COMPANY ='" + company + "' and ACTNO ='" + account + "' and CURRENCY ='" + currency + "' " + comymcondidtion + "  and UPDT between '" + begin_date + "' and '" + end_date + "')R     on R.TRD_ORDNO = T.TRD_ORDNO  " +
                //           "    left join  " +
                //           "    (select UTPRICE8 ,UTPRICE9 , (ORDNO+' '+LINESNO) as TRD_ORDNO_A   " +
                //           "     from FOTORD  " +
                //                                                                                                //modified by philip 20100521 CLOSETRD='Y'
                //           "     where COMPANY ='" + company + "' and ACTNO ='" + account + "' and  (ORDTYPE='1' or ORDTYPE='2') and CLOSETRD='Y'  and CURRENCY ='" + currency + "'" + comymcondidtion + "  and ORDDT between '" + begin_date + "' and '" + end_date + "')D  " +
                //           "   on D.TRD_ORDNO_A=T.TRD_ORDNO_A  " +
                //           "    left join    (select KIND as OPT_KIND ,ORIGNFEE as OPT_ORIGNFEE , CTAXAMT as OPT_CTAXAMT ,ORDNO as OPT_ORDNO  " +
                //           "     from FBTDTR     " +
                //           "   where COMPANY ='" + company + "' and ACTNO ='" + account + "' and CURRENCY ='" + currency + "' " + comymcondidtion + "   and UPDT between '" + begin_date + "' and '" + end_date + "')OPT_R  " +
                //           "    on OPT_R.OPT_ORDNO = T.OPT_ORDNO   " +
                //           "   left join  " +
                //           "   (select UTPRICE8 as OPT_UTPRICE8 ,UTPRICE9 as OPT_UTPRICE9 , (ORDNO+' '+LINESNO) as OPT_ORDNO_A  " +
                //           "    from FOTORD    " +
                //                                                                                            //modified by philip 20100521 CLOSETRD='Y'
                //           "  where COMPANY ='" + company + "' and ACTNO ='" + account + "' and (ORDTYPE='1' or ORDTYPE='2') and CLOSETRD='Y'   and CURRENCY ='" + currency + "' " + comymcondidtion + " and ORDDT between '" + begin_date + "' and '" + end_date + "')OPT_D " +
                //           "  on OPT_D.OPT_ORDNO_A=T.OPT_ORDNO_A    )Q    )Result_A  " +
                //             sqlcondition + " )Result_B " +
                //           "  group by ProductName , OFFSETDATE , CURRENCY) Result_C " +
                //           " left join " +
                //           " ( " +
                //           "select kind ,  UPDT  , (COMNO+' '+COMYM)as ProductName_g  , count(qty)as GiveUp " +   // "  select count(kind)as GiveUp   , UPDT  , (COMNO+' '+COMYM)as ProductName_g " +
                //           " from FBTDTR  " +
                //            "where COMPANY='" + company + "' and actno='" + account + "'  and kind = '6' "          +   //  "  where COMPANY ='" + company + "' and ACTNO ='" + account + "'  and kind = '6' " +
                //           " group by KIND ,COMPANY , ACTNO , UPDT , COMNO , COMYM) Result_D " +
                //           " on Result_C.OFFSETDATE = Result_D.UPDT and Result_C.ProductName = Result_D.ProductName_g )Result  order by offsetdate desc ";

                //modified by philip 20100528
                //string SqlCommand =


                //                 "select OFFSETDATE , CURRENCY , PRODUCTNAME , OSPRTLOS , OFFSETQTY , tax , charge , Equity , isnull(GiveUp,0)as GiveUp  " +
                //                 "from ( " +
                //                 "select    Result.OFFSETDATE,Result.CURRENCY,Result.PRODUCTNAME , sum(Result.OSPRTLOS) as OSPRTLOS , sum(Result.OFFSETQTY) as OFFSETQTY , " +
                //                 "sum(Result.tax) as tax , sum(Result.charge) as charge ,sum(Result.Equity) as Equity  " +
                //                 "from ( " +
                //                 "select    OFFSETDATE,CURRENCY,PRODUCTNAME , OSPRTLOS , OFFSETQTY , " +
                //                 " (CTAXAMT + UTPRICE9 + OPT_CTAXAMT + OPT_UTPRICE9)as tax , (ORIGNFEE + UTPRICE8 + OPT_ORIGNFEE + OPT_UTPRICE8)as charge , " +
                //                 " (OSPRTLOS - CTAXAMT - UTPRICE9 - OPT_CTAXAMT - OPT_UTPRICE9 -ORIGNFEE - UTPRICE8 - OPT_ORIGNFEE - OPT_UTPRICE8)   as Equity " +
                //                 " from   " +
                //                 " (select   OFFSETDATE , (TRDORDNO+' '+TRDLINESNO+TRDSEQNO) as TRD_ORDNO , (TRDORDNO+' '+TRDLINESNO) as TRD_ORDNO_A, CURRENCY  ,PS " +
                //                 ", dbo.YearMonth(COMNO,STKPRC,CALLPUT,COMYM)   as ProductName , (OPTORDNO+' '+OPTLINESNO+OPTSEQNO) as OPT_ORDNO ,(OPTORDNO+' '+OPTLINESNO) as OPT_ORDNO_A " +
                //                 ", OPTTRDDT , OFFSETQTY    ,case when comtype='1' and PS='B' then (OPTPRIC1-TRDPRC1)  when comtype='1' and PS='S' then (TRDPRC1-OPTPRIC1)   else (OSPRTLOS)    end \"OSPRTLOS\"    " +
                //                 " from FBWOST   where COMPANY ='" + company + "' and ACTNO = '" + account + "' and CURRENCY ='NTT' " + sqlcondition + comymcondidtion + "  and OFFSETDATE between '" + begin_date + "' and '" + end_date + "' )T  " +
                //                 " left join  (select  ORDNO as TRD_ORDNO ,KIND ,TRDDT ,ORIGNFEE , CTAXAMT   from FBTDTR    where COMPANY ='" + company + "' and ACTNO ='" + account + "' and CURRENCY ='NTT' " + comymcondidtion + " and KIND='2'    and TRDDT between '" + begin_date + "' and '" + end_date + "')R  " +
                //                 " on R.TRD_ORDNO = T.TRD_ORDNO   and  R.TRDDT =T.OFFSETDATE  left join   (select  ORDDT ,(ORDNO+' '+LINESNO) as TRD_ORDNO_A , UTPRICE8 ,UTPRICE9 " +
                //                 "  from FOTORD   where COMPANY ='" + company + "' and ACTNO ='" + account + "' and  (ORDTYPE='1' or ORDTYPE='2') and CLOSETRD='Y'  and CURRENCY ='NTT'  " + comymcondidtion +
                //                 " and ORDDT between '"+begin_date+"' and '"+end_date+"')D  on D.TRD_ORDNO_A=T.TRD_ORDNO_A  and D.ORDDT = T.OFFSETDATE " +
                //                 " left join " +
                //                 "  (select  ORDNO as OPT_ORDNO ,KIND as OPT_KIND , TRDDT as OPT_TRDDT ,ORIGNFEE as OPT_ORIGNFEE , CTAXAMT as OPT_CTAXAMT  " +
                //                 "    from FBTDTR   " +
                //                 "   where COMPANY ='" + company + "' and ACTNO ='" + account + "' and CURRENCY ='NTT' " + comymcondidtion + "and KIND='2'  and TRDDT between '" + begin_date + "' and '" + end_date + "')OPT_R " +
                //                 "   on OPT_R.OPT_ORDNO = T.OPT_ORDNO  and OPT_R.OPT_TRDDT = T.OFFSETDATE " +
                //                 "  left join  " +
                //                 "  (select ORDDT as  OPT_ORDDT , (ORDNO+' '+LINESNO) as OPT_ORDNO_A  , UTPRICE8 as OPT_UTPRICE8 ,UTPRICE9 as OPT_UTPRICE9 " +
                //                 "    from FOTORD  " +
                //                 " where COMPANY ='" + company + "' and ACTNO ='" + account + "' and (ORDTYPE='1' or ORDTYPE='2') and CLOSETRD='Y'   and CURRENCY ='NTT'  " + comymcondidtion +
                //                 "  and ORDDT between '"+begin_date+"' and '"+end_date+"')OPT_D  " +
                //                 " on OPT_D.OPT_ORDNO_A=T.OPT_ORDNO_A   and OPT_D.OPT_ORDDT =T.OFFSETDATE )Result  " +

                //                 "  group by ProductName , OFFSETDATE , CURRENCY )F " +
                //                 " left join ( " +
                //                 " select kind ,  TRDDT  , (COMNO+' '+COMYM)as ProductName_g  , count(qty)as GiveUp " +
                //                 "  from FBTDTR  " +
                //                 " where   COMPANY='" + company + "' and actno='" + account + "'  and  kind = '6'" +
                //                 " group by KIND ,COMPANY , ACTNO , TRDDT , COMNO , COMYM " +
                //                 " ) G " +
                //                 " on  F.OFFSETDATE = G.TRDDT and F.ProductName = G.ProductName_g  " +
                //                 "  order by offsetdate desc ";

                //modified by philip 20100813 
                string SqlCommand =

                   //"select   OFFSETDATE  , ProductName  ,sum(OFFSETQTY)  as OFFSETQTY   ,convert( decimal(18,2),sum(OSPRTLOS)) "
                    //+ "as  OSPRTLOS , CURRENCY , convert( decimal(18,2),sum(Equity) )as Equity , convert( decimal(18,2), sum(tax)) as tax, convert( decimal(18,2), sum(charge)) as charge , "
                    //+ "H.comno , H.comym ,convert( decimal(18,2), H.stkprc)stkprc , H.callput,case when optexh='MTX' then '大小台互抵' "
                    //+ " else abbr end abbr ,H.comtype ,ordtype from (select * from HistoryEquityClearListPreQuery "
                    //+" where company = '" + company + "' and actno ='" + account + "' and offsetdate between '" + begin_date + "' and '" + end_date + "' "
                    //+ productCondition   //此行為商品的condition
                    //+ "   )H left join (select abbr,comno,callput from fbmcob)fbmcob on H.comno=fbmcob.comno and H.callput=fbmcob.callput "
                    //+ "  group by OFFSETDATE  , ProductName , CURRENCY ,  H.comno , H.comym , H.stkprc , H.callput,abbr ,optexh,H.comtype,ordtype ";

                " select trddt offsetdate,COMMODX	ProductName,sum(OFFSETQTY)	OFFSETQTY,sum(OSPRTLOS)	OSPRTLOS,CCY	CURRENCY "
 + ",sum(Equity)	equity,sum(tax)	tax,sum(charge)	charge,COMNO ,comym,stkprc	,callput,"
     + " abbr ,comtype,ordtype from FOFFSETM where trddt between '" + begin_date + "' and '" + end_date + "' and firm='" + company + "' and actno='" + account + "' " + productCondition
 + "group by  trddt,COMMODX ,CCY,COMNO ,comym,stkprc	,callput,abbr ,comtype,ordtype  order by TRDDT,COMMODX  ";

                DataTable dtReturn = new DataTable("Result");

                dtReturn.Columns.Add("SYSDATE").DefaultValue = DateTime.Now.ToString("yyyy/MM/dd");
                dtReturn.Columns.Add("SYSTIME").DefaultValue = DateTime.Now.ToString("HH:mm:ss");
                SqlDataAdapter adp;
                adp = new SqlDataAdapter(SqlCommand, conn);
                adp.Fill(dtReturn);

                dtData[0] = dtReturn.Clone();

                foreach (DataColumn dc in dtData[0].Columns)
                {
                    dc.DataType = typeof(string);
                }

                foreach (DataRow dr in dtReturn.Rows)
                {
                    DataRow drNew = dtData[0].NewRow();
                    drNew["offsetdate"] = dr["offsetdate"].ToString();
                    drNew["ProductName"] = dr["ProductName"].ToString();
                    drNew["OFFSETQTY"] = dr["OFFSETQTY"].ToString();
                    drNew["CURRENCY"] = dr["CURRENCY"].ToString();

                    drNew["COMNO"] = dr["COMNO"].ToString();
                    drNew["comym"] = dr["comym"].ToString();

                    drNew["stkprc"] = dr["stkprc"].ToString();
                    if (dr["callput"].ToString().Trim() != "")
                    {
                        drNew["callput"] = dr["callput"].ToString();
                    }
                    else
                    {
                        drNew["callput"] = "N";
                    }
                    drNew["abbr"] = dr["abbr"].ToString();
                    drNew["comtype"] = dr["comtype"].ToString();
                    drNew["ordtype"] = dr["ordtype"].ToString();
                    drNew["OSPRTLOS"] = NumberTrim(dr["OSPRTLOS"].ToString());
                    drNew["equity"] = NumberTrim(dr["equity"].ToString());
                    drNew["tax"] = NumberTrim(dr["tax"].ToString());
                    drNew["charge"] = NumberTrim(dr["charge"].ToString());

                    dtData[0].Rows.Add(drNew);
                }



                for (int Index = 0; Index < dtData.Length; Index++)
                {
                    dsData.Tables.Add(dtData[Index]);
                }


                strData[0] = dsData.GetXml();
                BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + SourceType + company + account + begin_date + end_date + currency + comtype + comym + min_price + max_price + CP);

                return strData;

            }
            else
            {
                strData[0] = " <HistoryEquity><Result><Error>無查詢權限</Error><ErrorCode>0005</ErrorCode></Result></HistoryEquity> ";
                return strData;
            }

        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_getHistoryEquityCollect]" + ex.Message);
            return new string[] { " <HistoryEquity><Result><Error>WSError:" + ex.Message.ToString() + "</Error><ErrorCode>0005</ErrorCode></Result></HistoryEquity> ", "" };

        }

    }



    // 20100122 added by philip 查詢即時平倉損益(明細)
    [WebMethod]
    public string[] WS_getCurrentEquity(string SourceType, string company, string account, string currency)
    {
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getCurrentEquity]";

        string[] strData = new string[1];
        FunctionHandler fh = new FunctionHandler();
        DataSet dsReturn = new DataSet("Equity");

        try
        {

            getActno(ref company, ref account);
            //檢查此查詢來源是否有權限
            bool isok = AuthorityCheck(SourceType);

            if (isok)
            {
                MobDataParse mobData = new MobDataParse();

                //------------------------
                //判斷目前時間是否超過MOBGW啟動時間
                //並且超過小於MOBGW關閉時間,才可以查MOBGW,其餘透過DB查

                //if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_OpenTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_CloseTime"].ToString()))
                if (!chkDBTime())
                {
                    string[] OriginalstrData = fh.getCurrentEquity(company, account, currency, "", "", "", "", "", "999999999");
                    if (OriginalstrData != null)
                    {
                        mobData.parseMobInfoData(OriginalstrData);
                        string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
                        Int32 idx = 0;

                    }
                    if (mobData.mdt_CurrentEquity.Rows.Count == 0)
                    {
                        strData[0] = " <Equity><Result><Error>" + ErrorMessage.MSG0002 + "</Error><ErrorCode>0002</ErrorCode></Result></Equity> ";
                        return strData;
                    }
                    XmlDocument xd = new XmlDocument();
                    mobData.mdt_CurrentEquity.TableName = "Result";
                    DataTable dtResult = mobData.mdt_CurrentEquity.Clone();

                    foreach (DataColumn dc in dtResult.Columns)
                    {
                        dc.DataType = typeof(string);
                    }

                    foreach (DataRow dr in mobData.mdt_CurrentEquity.Rows)
                    {
                        DataRow drNew = dtResult.NewRow();
                        drNew["OPTPRIC1"] = NumberTrim(dr["OPTPRIC1"].ToString());
                        drNew["COMPANY"] = dr["COMPANY"].ToString();
                        drNew["ACTNO"] = dr["ACTNO"].ToString();
                        drNew["COMTYPE"] = dr["COMTYPE"].ToString();
                        drNew["TRD_ORDNO"] = dr["TRD_ORDNO"].ToString();
                        drNew["TRDORDNO"] = dr["TRDORDNO"].ToString();
                        drNew["trdlinesno"] = dr["trdlinesno"].ToString();
                        drNew["trdseqno"] = dr["trdseqno"].ToString();
                        drNew["CURRENCY"] = dr["CURRENCY"].ToString();
                        drNew["PS"] = dr["PS"].ToString();
                        drNew["COMNO"] = dr["COMNO"].ToString();
                        drNew["COMYM"] = dr["COMYM"].ToString();
                        drNew["STKPRC"] = dr["STKPRC"].ToString();
                        drNew["CALLPUT"] = dr["CALLPUT"].ToString();
                        drNew["TRDPRC1"] = NumberTrim(dr["TRDPRC1"].ToString());
                        drNew["OPT_ORDNO"] = dr["OPT_ORDNO"].ToString();
                        drNew["OPTTRDDT"] = dr["OPTTRDDT"].ToString();

                        drNew["OFFSETQTY"] = dr["OFFSETQTY"].ToString();
                        drNew["OSPRTLOS"] = NumberTrim(dr["OSPRTLOS"].ToString());
                        drNew["TRD_charge"] = NumberTrim(dr["TRD_charge"].ToString());
                        drNew["TRD_tax"] = NumberTrim(dr["TRD_tax"].ToString());
                        drNew["OPT_charge"] = NumberTrim(dr["OPT_charge"].ToString());
                        drNew["OPT_tax"] = NumberTrim(dr["OPT_tax"].ToString());
                        drNew["EQUITY"] = NumberTrim(dr["EQUITY"].ToString());
                        drNew["ORDTYPE"] = dr["ORDTYPE"].ToString();

                        drNew["ProductName"] = dr["ProductName"].ToString();
                        drNew["offsetdate"] = dr["offsetdate"].ToString();



                        dtResult.Rows.Add(drNew);
                    }


                    dsReturn.Tables.Add(dtResult);
                    xd.LoadXml(dsReturn.GetXml());
                    foreach (XmlNode xn in xd.SelectNodes("//Equity/Result"))
                    {
                        strData[0] += xn.OuterXml;
                    }
                    strData[0] = "<Equity>" + strData[0] + "</Equity>";
                }
                else
                {


                    strData[0] = " <Equity><Result><Error>" + ErrorMessage.MSG0006 + "</Error><ErrorCode>0009</ErrorCode></Result></Equity> ";
                }

            }
            else
            {
                strData[0] = " <Equity><Result><Error>無查詢權限</Error><ErrorCode>0005</ErrorCode></Result></Equity> ";

            }

        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_getCurrentEquity]" + ex.Message);
            // return null ;
            return new string[] { " <Equity><Result><Error>WSError:" + ex.Message.ToString() + "</Error><ErrorCode>0005</ErrorCode></Result></Equity> ", "" };

        }
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + SourceType + company + account + currency);
        return strData;

    }




    // 20100122 added by philip 查詢即時平倉損益(彙總)
    [WebMethod]
    public string[] WS_getCurrentEquityCollect(string SourceType, string company, string account, string currency, string comtype, string comym, string min_price, string max_price, string CP)
    {
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getCurrentEquityCollect]";

        string[] strData = new string[1];
        FunctionHandler fh = new FunctionHandler();




        try
        {

            getActno(ref company, ref account);
            //檢查此查詢來源是否有權限
            bool isok = AuthorityCheck(SourceType);

            if (isok)
            {
                MobDataParse mobData = new MobDataParse();

                //------------------------
                //判斷目前時間是否超過MOBGW啟動時間
                //並且超過小於MOBGW關閉時間,才可以查MOBGW,其餘透過DB查

                // if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_OpenTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_CloseTime"].ToString()))
                if (!chkDBTime())
                {
                    string[] OriginalstrData = fh.getCurrentEquity(company, account, currency, "", "", "", "", "", "999999999");
                    if (OriginalstrData != null)
                    {
                        mobData.parseMobInfoData(OriginalstrData);
                        string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
                        Int32 idx = 0;
                        for (idx = 0; idx < OriginalstrData.Length; idx++)
                        {

                        }
                    }

                    if (mobData.mdt_CurrentEquity.Rows.Count == 0)
                    {
                        strData[0] = " <Equity><Result><Error>" + ErrorMessage.MSG0002 + "</Error><ErrorCode>0002</ErrorCode></Result></Equity> ";
                        return strData;
                    }
                    mobData.mdt_CurrentEquityCollect.TableName = "Result";

                    DataTable dtResult = new DataTable("Result");

                    foreach (DataColumn dc in mobData.mdt_CurrentEquityCollect.Columns)
                    {
                        dtResult.Columns.Add(dc.ColumnName);
                    }

                    foreach (DataRow dr in mobData.mdt_CurrentEquityCollect.Rows)
                    {
                        DataRow drNew = dtResult.NewRow();
                        drNew["OSPRTLOS"] = NumberTrim(dr["OSPRTLOS"].ToString());
                        drNew["OFFSETQTY"] = dr["OFFSETQTY"].ToString();
                        drNew["CURRENCY"] = dr["CURRENCY"].ToString();
                        drNew["COMNO"] = dr["COMNO"].ToString();
                        drNew["COMYM"] = dr["COMYM"].ToString();
                        drNew["STKPRC"] = dr["STKPRC"].ToString();
                        drNew["CALLPUT"] = dr["CALLPUT"].ToString();
                        drNew["comtype"] = dr["comtype"].ToString();
                        drNew["offsetdate"] = dr["offsetdate"].ToString();
                        drNew["ProductName"] = dr["ProductName"].ToString();
                        drNew["GiveUp"] = dr["GiveUp"].ToString();

                        drNew["charge"] = NumberTrim(dr["charge"].ToString());
                        drNew["tax"] = NumberTrim(dr["tax"].ToString());
                        drNew["EQUITY"] = NumberTrim(dr["EQUITY"].ToString());

                        drNew["ORDTYPE"] = dr["ORDTYPE"].ToString();

                        drNew["SYSDATE"] = dr["SYSDATE"].ToString();
                        drNew["SYSTIME"] = dr["SYSTIME"].ToString();
                        dtResult.Rows.Add(drNew);
                    }

                    DataSet dsReturn = new DataSet("Equity");

                    XmlDocument xd = new XmlDocument();

                    dsReturn.Tables.Add(dtResult);
                    xd.LoadXml(dsReturn.GetXml());

                    foreach (XmlNode xn in xd.SelectNodes("//Equity/Result"))
                    {
                        strData[0] += xn.OuterXml;
                    }
                    strData[0] = "<Equity>" + strData[0] + "</Equity>";
                }
                else
                {



                    strData[0] = " <Equity><Result><Error>" + ErrorMessage.MSG0006 + "</Error><ErrorCode>0009</ErrorCode></Result></Equity> ";
                }

            }
            else
            {
                strData[0] = " <Equity><Result><Error>無查詢權限</Error><ErrorCode>0005</ErrorCode></Result></Equity> ";

            }
            BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + SourceType + company + account + currency + comtype + comym + min_price + max_price + CP);
        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_getCurrentEquityCollect]" + ex.Message);
            // return null ;
            return new string[] { " <Equity><Result><Error>WSError:" + ex.Message.ToString() + "</Error><ErrorCode>0005</ErrorCode></Result></Equity> ", "" };

        }
        return strData;
    }
    /*
        //added 20100204 商品名稱轉換
        private string ProductNameTransfer(string comno, string comym, string stkprc, string comtype, string callput)
        {
            string productname = null;

            //期貨
            if (comtype == "0")
            {
                switch (comno)
                {
                    case "FICBF":
                        productname = "CBF";
                        break;
                    case "FICHF":
                        productname = "CHF";
                        break;
                    case "FICDF":
                        productname = "CDF";
                        break;
                    case "FICCF":
                        productname = "CCF";
                        break;
                    case "FICQF":
                        productname = "CQF";
                        break;
                    case "DEF":
                        productname = "DEF";
                        break;
                    case "FIDFF":
                        productname = "DFF";
                        break;
                    case "FIDF2":
                        productname = "DF2";
                        break;
                    case "FIDGF":
                        productname = "DGF";
                        break;
                    case "FICB1":
                        productname = "CB1";
                        break;
                    case "FIDF1":
                        productname = "DF1";
                        break;
                    case "FICQ1":
                        productname = "CQ1";
                        break;
                    case "FICD1":
                        productname = "CD1";
                        break;
                    case "FIDG1":
                        productname = "DG1";
                        break;
                    case "FIDF3":
                        productname = "DF3";
                        break;
                    case "FICQ2":
                        productname = "CQ2";
                        break;

                    case "FICH1":
                        productname = "CH1";
                        break;
                    case "FIGT":
                        productname = "GTF";
                        break;
                    case "FIXI":
                        productname = "XIF";
                        break;
                    case "FITG":
                        productname = "TGF";
                        break;
                    case "FIGD":
                        productname = "GDF";
                        break;
                    case "FIMS":
                        productname = "MSF";
                        break;
                    case "FITE":
                        productname = "EXF";
                        break;

                    case "FITF":
                        productname = "FXF";
                        break;

                    case "FIT5":
                        productname = "T5F";
                        break;
                    case "FIGB":
                        productname = "GBF";
                        break;
                    case "FIMTX":
                        productname = "MXF";
                        break;
                    case "FITX":
                        productname = "TXF";
                        break;
                    case "FICP":
                        productname = "CPF";
                        break;
                    default:
                        productname = "N/A";
                        break;

                }

                productname = productname + MonthCode(comym.Substring(4, 2), "C") + comym.Substring(3, 1);

                return productname;

            }
            //選擇權
            else
            {


                string price = string.Format("{0:0}", decimal.Parse(stkprc));

                productname = comno + price.PadLeft(5, '0') + MonthCode(comym.Substring(4, 2), callput);
                return productname;


            }

        }
        //月份代碼
        private string MonthCode(string month, string callput)
        {
            string code = null;

            if (callput == "C")
            {
                switch (month)
                {
                    case "01":
                        code = "A";
                        break;
                    case "02":
                        code = "B";
                        break;
                    case "03":
                        code = "C";
                        break;
                    case "04":
                        code = "D";
                        break;
                    case "05":
                        code = "E";
                        break;
                    case "06":
                        code = "F";
                        break;
                    case "07":
                        code = "G";
                        break;
                    case "08":
                        code = "H";
                        break;
                    case "09":
                        code = "I";
                        break;
                    case "10":
                        code = "J";
                        break;
                    case "11":
                        code = "K";
                        break;
                    case "12":
                        code = "L";
                        break;

                }
            }
            else
            {

                switch (month)
                {
                    case "01":
                        code = "M";
                        break;
                    case "02":
                        code = "N";
                        break;
                    case "03":
                        code = "O";
                        break;
                    case "04":
                        code = "P";
                        break;
                    case "05":
                        code = "Q";
                        break;
                    case "06":
                        code = "R";
                        break;
                    case "07":
                        code = "S";
                        break;
                    case "08":
                        code = "T";
                        break;
                    case "09":
                        code = "U";
                        break;
                    case "10":
                        code = "V";
                        break;
                    case "11":
                        code = "W";
                        break;
                    case "12":
                        code = "X";
                        break;
                }

            }

            return code;
        }

        //added 20100223 查資料庫轉換新舊商品名
        [WebMethod]
        public string WS_getProductNameTrans(string comno, string comym, string stkprc, string comtype, string callput)
        {

            if (callput == "N")
            {
                callput = "";
            }

            decimal price = Convert.ToDecimal(stkprc);


            DataTable[] dtData = new DataTable[1] { new DataTable("result") };
            // DataTable[] dtData = new DataTable[1];
            SqlConnection conn = new SqlConnection(ASTR_ConfigConnection2);

            //SELECT dbo.fnGetProductId('1','TGO','201004',03950,'C')
            //SELECT dbo.fnGetProductId('0','FITE','201003',000000,'')

            //使用 VIPConfigDB.dbo.fnGetProductId函式轉換
            string SqlCommand = " SELECT VIPConfigDB.dbo.fnGetProductId('" + comtype + "','" + comno + "','" + comym + "'," + price + ",'" + callput + "')";


            SqlDataAdapter adp;
            adp = new SqlDataAdapter(SqlCommand, conn);
            adp.Fill(dtData[0]);

            return dtData[0].Rows[0][0].ToString().Trim();


        }
    */




    public static string[] NewProductNameTransfer(string comno, string comym, string stkprc, string comtype, string callput) //added 20100525 by philip  新舊商品名轉換 改為從webservice記憶體內的table
    {
        //DataRow[] result = new DataRow[1];
        //if(comtype=="0") // future
        //{
        //    //先做新舊商品名轉換
        //    string command = "field_value='" + comno + "'";
        //    DataRow[] dt =dtTranslateValue.Select(command);

        //    if (dt.Length != 0)
        //    {
        //        string newID = dt[0]["field_text"].ToString().Trim();

        //        string command2 = "class_name='" + newID + "' and settlement_month='" + comym + "'";
        //        result = dtFuture.Select(command2);               

        //    }
        //    else
        //    {
        //        return new string[] { "NA", "NA" };
        //    }

        //}
        //else  //comtype=="1" Option
        //{
        //    string command ="class_name='"+comno+"' and  Settlement_month='"+comym+"' and  Strike_Price='"+stkprc+"' and  CP='"+callput+"'";
        //   // string command = "class_name='" + comno + "' and  Settlement_month='201505' and  Strike_Price='" + stkprc + "' and  CP='" + callput + "'";
        //    result = dtOption.Select(command);
        //}

        //if (result.Length!=0)
        //{
        if (comtype == "0") // future
        {
            return new string[] { "", comno + comym.Substring(4, 2) };
        }
        else
        {
            return new string[] { "", comno + decimal.Parse(stkprc).ToString("#0.####") + callput + comym.Substring(4, 2) };
        }
        //}
        //else
        //{
        //    return new string[] { "NA", "NA" };
        //}

    }


    //20100302 有價證券抵繳查詢
    [WebMethod]
    public string WS_getTMCOFUSE(string company, string actno, string currency)
    {
        getActno(ref company, ref actno);
        DataTable[] dt = new DataTable[1] { new DataTable("Result") };

        string BOScommand = null;

        OdbcConnection oConn = new OdbcConnection(m_strOleDBConn);  //連接 BOS

        BOScommand =
            "SELECT tmcofuse " +
            "FROM FBSCUS " +
            "WHERE COMPANY='" + company + "'  and ACTNO ='" + actno + "' and CURRENCY='" + currency + "'";

        OdbcDataAdapter OleDbadp = new OdbcDataAdapter(BOScommand, oConn);

        OleDbadp.Fill(dt[0]);
        if (dt[0] != null)
        {
            return dt[0].Rows[0][0].ToString().Trim();
        }
        else
        {
            return "0";
        }
    }



    /// <summary>
    /// 20100512 added by Kelly Huang
    /// 歷史權益總值查詢
    /// </summary>
    /// <returns></returns>
    [WebMethod]
    public DataTable WS_getHistoryOPTEQUITY(string strUSERIDList, string strCURRENCY, string strLTRDDTList)
    {
        string SqlCommand = "SELECT COMPANY, ACTNO, LTRDDT, NVL(BPREMIUM,0)BPREMIUM,NVL(SPREMIUM,0)SPREMIUM,NVL(TMEXCESS,0)TMEXCESS,NVL(TMIAMT,0)TMIAMT FROM FBTCUS WHERE  ACTNO in (" + strUSERIDList + ") AND CURRENCY='" + strCURRENCY + "' AND LTRDDT in (" + strLTRDDTList + ")";
        OdbcConnection oConn = new OdbcConnection(m_strOleDBConn);
        OdbcDataAdapter ODBCadp;
        DataTable dtData = new DataTable("History");
        ODBCadp = new OdbcDataAdapter(SqlCommand, oConn);
        ODBCadp.Fill(dtData);
        return dtData;
        //return SqlCommand;
    }



    /// <summary>
    /// added 20101203 歷史成交回報查詢
    /// </summary>
    /// <param name="SourceType"></param>
    /// <returns></returns>
    [WebMethod]
    public DataTable WS_getHistoryFBTDTR_List(string company, string actno, string comtype, string date1, string date2)
    {

        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + "[WS_getHistoryFBTDTR_List]";

        if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["Transfer_BeginTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["Transfer_EndTime"].ToString()))
        {
            BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + company + actno + comtype + date1 + date2);
            DataTable dtError = new DataTable("result");
            dtError.Columns.Add("Error");
            dtError.Columns.Add("ErrorCode");
            dtError.Rows.Add(new object[] { ErrorMessage.MSG0001, "0001" });
            return dtError;
        }
        try
        {

            getActno(ref company, ref actno);
            bool isok = false;

            DataTable[] dtData = new DataTable[1] { new DataTable("result") };
            SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);

            string strComtype;

            if (comtype == "")
            {
                strComtype = " ";
            }
            else
            {
                //strComtype = "  and F.COMTYPE ='" + comtype + "' ";
                if (comtype == "0")
                {
                    strComtype = "  and ctype ='F' ";
                }
                else
                {
                    strComtype = "  and ctype ='O' ";
                }
            }


            //string SqlCommand = " select Qualified from userauthority where sourcetype = '" + SourceType + "'";
            string SqlCommand =

          //  "  select B.ORDNO_ , B.EXH ,  B.PS   , B.totalQTY ,  B.TRDTM , B.ENTCD  , B.ProductInfo , (B.totalPrice / B.totalQTY)average"+
                // " from( "+
                // " select A.ORDNO_ , A.EXH ,  A.PS   , sum(A.QTY)totalQTY ,  A.COMPANY, A.TRDTM , A.ENTCD , sum(A.totalPrice)totalPrice , A.ProductInfo "+
                // " from( "+
                //"  select SUBSTRING(ORDNO,1,7)ORDNO_ , KIND , TRDDT , EXH , COMTYPE,  PS , COMNO , COMYM , STKPRC , CALLPUT  , QTY , TRDPRC1, COMPANY, TRDTM , ENTCD , (QTY*TRDPRC1)totalPrice , "+
                // " case COMTYPE when '0'  then COMNO+COMYM+CALLPUT  when '1'  then COMNO+COMYM+ rtrim(convert(char,STKPRC)) +CALLPUT  end \"ProductInfo\" "+
                //"  from FBTDTR "+
                //"  where ACTNO='" + actno + "' and COMPANY ='" + company + "'" +strComtype+"  and COMTYPE ='0' and WRITTENDATE between '" + date1 + "' and '" + date2 + "' " +
                // " ) A group by A.ORDNO_ , A.EXH ,  A.PS   ,  A.COMPANY, A.TRDTM , A.ENTCD  , A.ProductInfo ) B " ;

            ///// modified 20101213 by philip 補下單來源的中文名稱

    //        " select B.ORDNO  , B.EXH ,  B.PS   , B.totalQTY,b.TRDDT ,  B.TRDTM , B.ENTCD  , B.ProductInfo  ,CONVERT( decimal(18,2) , case when  B.totalQTY=0 then 0 else (B.totalPrice / B.totalQTY) end )average " +
                //" from( select A.ORDNO , A.EXH ,  A.PS  " +
                //", sum(A.QTY)totalQTY ,  A.COMPANY,A.TRDDT, substring(A.TRDTM,1,2)+':'+substring(A.TRDTM,3,2)+':'+substring(A.TRDTM,5,2)+'.'+substring(A.TRDTM,7,3) TRDTM , A.ENTCD , sum(A.totalPrice)totalPrice , A.ProductInfo  from(  select F.ORDNO , F.KIND , F.TRDDT , F.EXH , " +
                //" F.COMTYPE,  F.PS ,  F.COMNO , F.COMYM , F.STKPRC , F.CALLPUT  , F.QTY , F.TRDPRC1, F.COMPANY, F.TRDTM ,  (F.QTY*F.TRDPRC1)totalPrice ,  O.Translation as ENTCD, " +
                //" case COMTYPE   when '0'  then  rtrim(fbmcob.ABBR)+substring(COMYM ,5,2)  when '1'  then rtrim(fbmcob.ABBR)+ rtrim(cast(STKPRC  as float )) +fbmcob.CALLPUT +substring(COMYM ,5,2) end  ProductInfo " +
                //" from FBTDTR as F left join OrderSourceConfig as O " +
                // " on   F.ENTCD collate   Chinese_PRC_CS_AS_WS = O.R6_Code left join " +
                //"(select comno ,abbr,callput from fbmcob)fbmcob " +
                //" on f.comno=fbmcob.comno and f.callput=fbmcob.callput " +
                //" where f.kind='2' and F.ACTNO= '" + actno + "' and F.COMPANY ='" + company + "'" + strComtype + "  and F.WRITTENDATE between '" + date1 + "' and '" + date2 + "' " +
                // " ) A group by A.ORDNO  , A.EXH ,  A.PS   ,  A.COMPANY,A.TRDDT, A.TRDTM , A.ENTCD  , A.ProductInfo ) B ";



            "select  f.ORDNO ,"
            + "'TIM' EXH,BSCODE PS,totalQTY,TDATE TRDDT,"
            + "substring(MTHTIME,1,2)+':'+substring(MTHTIME,3,2)+':'+substring(MTHTIME,5,2)+'.'+substring(MTHTIME,7,2)  TRDTM "
            + ",case CTYPE   when 'F'  then  rtrim(fs.short_name)+substring(SETMTH ,5,2)  when 'O'  then rtrim(os.short_name)+ rtrim(cast(STKPRC  as float )) +CPCODE +substring(SETMTH ,5,2) end  ProductInfo"
            + ",isnull(O.Translation,'') ENTCD,"
            + " convert(decimal(18,4),case when  totalQTY=0 then 0 else ( totalPrice /  totalQTY) end) average "
             + " from (select ORDNO,ORDSEQ,BSCODE,sum(MTHQTY)totalQTY,TDATE,MTHTIME,ctype,SETMTH,STKPRC,CPCODE,COMMODX ,sum(MTHQTY*MTHPRC)totalPrice  from FMATCHM "
            + "where tdate  between '" + date1 + "' and '" + date2 + "' and  BROKER='" + company + "' and IVACNO='" + actno + "' " + strComtype + " group by ORDNO,ORDSEQ,BSCODE ,TDATE,MTHTIME,ctype,SETMTH,STKPRC,CPCODE,COMMODX)f "
             + " left join (select ORDNO,ORDSEQ,ORDSRC from forderm "
             + " where tdate  between '" + date1 + "' and '" + date2 + "' and  BROKER='" + company + "' and IVACNO='" + actno + "'  )r on "
             + " f.ORDNO  collate   Chinese_PRC_CS_AS_WS =r.ORDNO and  f.ORDSEQ=r.ORDSEQ "
            + " left join OrderSourceConfig as O   "
            + " on r.ORDSRC collate   Chinese_PRC_CS_AS_WS = O.R6_Code "
            + " left join (select kind_id,short_name from p09m )OS on substring(f.COMMODX,1,3)=OS.kind_id "
            + "left join (select kind_id,short_name from p09mf )FS on substring(f.COMMODX,1,3)=fs.kind_id";


            DataTable dtReturn = new DataTable("Result");

            dtReturn.Columns.Add("SYSDATE").DefaultValue = DateTime.Now.ToString("yyyy/MM/dd");
            dtReturn.Columns.Add("SYSTIME").DefaultValue = DateTime.Now.ToString("HH:mm:ss");
            SqlDataAdapter adp;
            adp = new SqlDataAdapter(SqlCommand, conn);
            adp.Fill(dtReturn);

            dtData[0] = dtReturn.Clone();

            foreach (DataColumn dc in dtData[0].Columns)
            {
                dc.DataType = typeof(string);
            }

            foreach (DataRow dr in dtReturn.Rows)
            {
                DataRow drNew = dtData[0].NewRow();
                drNew["ORDNO"] = dr["ORDNO"].ToString();
                drNew["EXH"] = dr["EXH"].ToString();
                drNew["PS"] = dr["PS"].ToString();
                drNew["totalQTY"] = dr["totalQTY"].ToString();
                drNew["TRDDT"] = dr["TRDDT"].ToString();
                drNew["TRDTM"] = dr["TRDTM"].ToString();

                drNew["ProductInfo"] = dr["ProductInfo"].ToString();

                drNew["ENTCD"] = dr["ENTCD"].ToString();
                drNew["average"] = NumberTrim(dr["average"].ToString());

                dtData[0].Rows.Add(drNew);
            }
            BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + company + actno + comtype + date1 + date2);
            return dtData[0];

        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_getHistoryFBTDTR_List]" + ex.Message);
            DataTable dtError = new DataTable("result");
            dtError.Columns.Add("Error");
            dtError.Columns.Add("ErrorCode");
            dtError.Rows.Add(new object[] { "WSError:" + ex.Message.ToString(), "0005" });
            return dtError;
        }

    }


    /// <summary>
    /// added 20101203 歷史委託查詢
    /// </summary>
    /// <param name="SourceType"></param>
    /// <returns></returns>
    [WebMethod]
    public DataTable WS_getHistoryFOTORD_List(string company, string actno, string comtype, string date1, string date2)
    {
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + "[WS_getHistoryFOTORD_List]";

        if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["Transfer_BeginTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["Transfer_EndTime"].ToString()))
        {
            DataTable dtError = new DataTable("result");
            dtError.Columns.Add("Error");
            dtError.Columns.Add("ErrorCode");
            dtError.Rows.Add(new object[] { ErrorMessage.MSG0001, "0001" });
            BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + company + actno + comtype + date1 + date2);
            return dtError;
        }
        try
        {

            getActno(ref company, ref actno);
            bool isok = false;

            DataTable[] dtData = new DataTable[1] { new DataTable("result") };
            SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);

            string strComtype;

            if (comtype == "")
            {
                strComtype = " ";
            }
            else
            {
                //strComtype = "  and COMTYPE ='" + comtype + "' ";
                if (comtype == "0")
                {
                    strComtype = "  and PRDTYP ='F' ";
                }
                else
                {
                    strComtype = "  and PRDTYP ='O' ";
                }
            }


            //string SqlCommand = " select Qualified from userauthority where sourcetype = '" + SourceType + "'";
            string SqlCommand =


            //  "  select R.ORDTIME , R.ORDNO , R.LINESNO , R.PS , R.ORDTYPE , R.ProductName , R.ORDTIME , R.UTPRICE1 , R.ORDQTY , R.TRDQTY , R.TotalCancled , R.DTOVER ,R.ENTTYPE ,  "+
                //  "  case   when ( code ='0000' and R.ORDQTY=R.TotalCancled) then   '刪單成功'  "+
                //  "         when ( code='0000'  and R.ORDQTY=R.TRDQTY ) then '完全成交' "+
                //  "         when ( code ='0000' and R.TRDQTY > 0 ) then '部分成交' "+
                // "          else R.msgdata "+
                // "   end \"R.msgdata\" "+
                // "   from ( "+
                // "  select F.ORDNO , F.LINESNO , F.PS , F.ORDTYPE , (F.COMNO + F.COMYM + rtrim(convert(char,F.STKPRICE)) + F.CP) ProductName, F.ORDTIME ,  F.UTPRICE1 , F.ORDQTY , F.TRDQTY , (F.ORDQTY-F.QTY)TotalCancled , F.CODE , F.DTOVER  , F.ENTTYPE , B.msgcode , B.msgdata "+
                // "   from FOTORD F "+
                //"     left join VIPConfigDB.dbo.tblErrorMapping as B "+
                //"    on F.CODE = B.msgcode "+
                // "   where (F.ordtype = '1' or F.ordtype= '2') and F.company='"+company+"' and F.actno='"+actno+"' " +strComtype+" and F.writtendate between '"+date1+"' and '"+date2+"' " +
                //  "  )R " ;

            /////////////modified 20101213 by philip  補下單來源中文


    //        " select R.ORDTIME , R.ORDNO  , R.PS , R.ProductName ,case when R.OPENS='0' then'ROD' " +
                //   " when R.OPENS='1' then'IOC'   when R.OPENS='2' then'FOK' end OPENS " +
                // ", CONVERT( decimal(18,2) ,R.UTPRICE1 ) UTPRICE1, R.ORDQTY , R.TRDQTY , R.TotalCancled , O.Translation as ENTTYPE, R.ORDDT ,  " +
                //  " case   when ( code ='0000' and R.ORDQTY=R.TotalCancled) then  '刪單成功'  when ( code='0000'  and R.ORDQTY=R.TRDQTY ) then '完全成交' when ( code ='0000' and R.TRDQTY > 0 ) then '部分成交'  else R.msgdata  end  msgdata,case when R.DTOVER ='N' then '非當沖' else'當沖'end DTOVER " +
                // " from (  select F.ORDNO , F.LINESNO , F.PS , case when len(opens)=1 then opens else substring(opens,2,1) end OPENS , " +
                //" case COMTYPE   when '0'  then  rtrim(fbmcob.ABBR)+substring(COMYM ,5,2)  when '1'  then rtrim(fbmcob.ABBR)+ rtrim(cast(STKPRICE  as float )) +fbmcob.CALLPUT +substring(COMYM ,5,2) end  ProductName, " +
                //  " F.ORDDT, substring(F.ORDTIME,1,2)+':'+substring(F.ORDTIME,3,2)+':'+substring(F.ORDTIME,5,2)+'.'+substring(F.ORDTIME,7,3) " +
                // " ORDTIME ,  F.UTPRICE1 , F.ORDQTY , F.TRDQTY , (F.ORDQTY-F.QTY)TotalCancled , F.CODE , F.DTOVER  , F.ENTTYPE , B.msgcode , B.msgdata " +
                // " from FOTORD F  left join dbo.tblErrorMapping as B   on F.CODE = B.msgcode " +
                //" left join (select comno,abbr,callput from fbmcob)fbmcob on f.comno =fbmcob.comno and f.cp=fbmcob.callput " +
                //  " where (F.ordtype = '1' or F.ordtype= '2')  and F.company='" + company + "' and F.actno='" + actno + "' " + strComtype + " and F.writtendate between '" + date1 + "' and '" + date2 + "' " +
                //    " )R  , OrderSourceConfig as O   where R.ENTTYPE collate   Chinese_PRC_CS_AS_WS = O.R6_Code ";
            "select  substring(ORDTIME,1,2)+':'+substring(ORDTIME,3,2)+':'+substring(ORDTIME,5,2)+'.'+substring(ORDTIME,7,2) ORDTIME ,ORDNO,BSCODEX PS,"
+ "case PRDTYP   when 'F'  then  rtrim(fs.short_name)+substring(SETMTH ,5,2)  when 'O'  then rtrim(os.short_name)+ rtrim(cast(STKPRC  as float )) +CPCODE +substring(SETMTH ,5,2) end  ProductName,"
 + "case ORDCND when 'R'   then'ROD' when 'I'  then'IOC'   when  'F'  then'FOK' end OPENS ,"
+ "ORDPRC UTPRICE1,QUANTITY ORDQTY,MATQTY TRDQTY,DLTQTY TotalCancled,isnull(O.Translation,'') ENTTYPE,	TDATE ORDDT,"
+ "case   when ( STUCODE ='000' and QUANTITY=DLTQTY) then  '刪單成功'"
  + "when ( STUCODE='000'  and  QUANTITY= MATQTY ) then '完全成交'"
 + "when ( STUCODE ='000' and  MATQTY > 0 ) then '部分成交'  else '錯誤單('+STUCODE+')' end msgdata,"
+ "case when OPNOFF='2' then '當沖' else '非當沖' end DTOVER	"
 + "from (select * from forderm "
+ "where tdate  between '" + date1 + "' and '" + date2 + "' and  BROKER='" + company + "' and IVACNO='" + actno + "' " + strComtype + " )f left join OrderSourceConfig as O   "
+ "on f.ORDSRC collate   Chinese_PRC_CS_AS_WS = O.R6_Code "
+ " left join "
+ "(select kind_id,short_name from p09m )OS on substring(f.COMMODX,1,3)=OS.kind_id"
+ " left join "
+ " (select kind_id,short_name from p09mf )FS on substring(f.COMMODX,1,3)=fs.kind_id ";



            DataTable dtReturn = new DataTable("Result");

            dtReturn.Columns.Add("SYSDATE").DefaultValue = DateTime.Now.ToString("yyyy/MM/dd");
            dtReturn.Columns.Add("SYSTIME").DefaultValue = DateTime.Now.ToString("HH:mm:ss");
            SqlDataAdapter adp;
            adp = new SqlDataAdapter(SqlCommand, conn);
            adp.Fill(dtReturn);

            dtData[0] = dtReturn.Clone();

            foreach (DataColumn dc in dtData[0].Columns)
            {
                dc.DataType = typeof(string);
            }

            foreach (DataRow dr in dtReturn.Rows)
            {
                DataRow drNew = dtData[0].NewRow();
                drNew["ORDTIME"] = dr["ORDTIME"].ToString();
                drNew["ORDNO"] = dr["ORDNO"].ToString();
                drNew["PS"] = dr["PS"].ToString();
                drNew["ProductName"] = dr["ProductName"].ToString();
                drNew["OPENS"] = dr["OPENS"].ToString();
                drNew["ORDQTY"] = dr["ORDQTY"].ToString();

                drNew["TRDQTY"] = dr["TRDQTY"].ToString();
                drNew["TotalCancled"] = dr["TotalCancled"].ToString();
                drNew["ENTTYPE"] = dr["ENTTYPE"].ToString();
                drNew["ORDDT"] = dr["ORDDT"].ToString();
                drNew["UTPRICE1"] = NumberTrim(dr["UTPRICE1"].ToString());
                drNew["msgdata"] = dr["msgdata"].ToString();
                drNew["DTOVER"] = dr["DTOVER"].ToString();
                dtData[0].Rows.Add(drNew);
            }
            BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + company + actno + comtype + date1 + date2);
            return dtData[0];
        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_getHistoryFOTORD_List]" + ex.Message);
            DataTable dtError = new DataTable("result");
            dtError.Columns.Add("Error");
            dtError.Columns.Add("ErrorCode");
            dtError.Rows.Add(new object[] { "WSError:" + ex.Message.ToString(), "0005" });
            return dtError;
        }
    }
    /// <summary>
    /// 20110214 歷史保證金查詢 (for 群組帳務用)
    /// </summary>
    /// <param name="company"></param>
    /// <param name="actno"></param>
    /// <param name="tddt"></param>
    /// <param name="currency"></param>
    /// <returns></returns>
    [WebMethod]
    public DataTable WS_getLastHistoryMargin(string company, string actno, string tddt, string currency)
    {
        getActno(ref company, ref actno);
        string SqlCommand = "SELECT TOP (1) * FROM HistoryMarginPreQuery WHERE (TDDT <= '" + tddt + "') AND (Company = '" + company + "') AND (Actno = '" + actno + "') AND (Currency = '" + currency + "') ORDER BY TDDT DESC";
        SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);
        DataTable dtData = new DataTable("HistoryMargin");
        SqlDataAdapter SQLadp = new SqlDataAdapter(SqlCommand, conn);
        SQLadp.Fill(dtData);
        return dtData;
    }
    /// <summary>
    /// 未平倉查資料庫 
    /// </summary>
    /// <param name="company"></param>
    /// <param name="actno"></param>
    /// <param name="spread">空白(全部),Y(複式),N(單式),A(混合)</param>
    /// <returns></returns>
    public DataSet getUnLiquidation(string company, string actno, string spread, string currency)
    {



        string strDate = "convert(char(8),getdate(),112)";
        //判斷查今天或查前天
        // if (closeday || DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_OpenTime"].ToString()))
        {
            strDate = "(select max(tdate) from dbo.FTUD) ";
        }

        bool isok = false;
        DataSet dsData = new DataSet();
        DataTable dtDetail = new DataTable();
        DataTable dtSummary = new DataTable();
        dtDetail.Columns.Add("productKind").DefaultValue = "";


        dtDetail.Columns.Add("currency").DefaultValue = "";
        dtDetail.Columns.Add("tradedate").DefaultValue = "";
        dtDetail.Columns.Add("orderNo").DefaultValue = "";

        dtDetail.Columns.Add("BS").DefaultValue = "";
        dtDetail.Columns.Add("ProductId").DefaultValue = "";

        dtDetail.Columns.Add("productName").DefaultValue = "";
        dtDetail.Columns.Add("investoracno").DefaultValue = "";
        dtDetail.Columns.Add("MatchPrice", typeof(decimal)).DefaultValue = 0;
        dtDetail.Columns.Add("RefRealPrice").DefaultValue = "";
        dtDetail.Columns.Add("OTQTY", typeof(decimal)).DefaultValue = 0;
        dtDetail.Columns.Add("RefPL").DefaultValue = "";


        dtDetail.Columns.Add("DTOVER").DefaultValue = "";
        dtDetail.Columns.Add("multiplecomno").DefaultValue = "";
        dtDetail.Columns.Add("multipleBS").DefaultValue = "";
        dtDetail.Columns.Add("footMatchPrice").DefaultValue = "";
        dtDetail.Columns.Add("MKTCOMNO").DefaultValue = "";
        dtDetail.Columns.Add("COMYM").DefaultValue = "";
        dtDetail.Columns.Add("STKPRC").DefaultValue = "";
        dtDetail.Columns.Add("CALLPUT").DefaultValue = "";
        dtDetail.Columns.Add("IAMT").DefaultValue = "";
        dtDetail.Columns.Add("MAMT").DefaultValue = "";
        dtDetail.Columns.Add("multipleMatchPrice1").DefaultValue = "";
        dtDetail.Columns.Add("multipleMatchPrice2").DefaultValue = "";

        dtDetail.Columns.Add("matchTime").DefaultValue = "";
        dtDetail.Columns.Add("RefNowPrice").DefaultValue = "";
        dtDetail.Columns.Add("TAX").DefaultValue = "";
        dtDetail.Columns.Add("FEE").DefaultValue = "";
        dtDetail.Columns.Add("EQUITY").DefaultValue = "";


        dtDetail.Columns.Add("TatolMatchPrice", typeof(decimal));//成交價格
        dtDetail.Columns["TatolMatchPrice"].Expression = "MatchPrice*OTQTY";
        dtDetail.Columns.Add("matchseq").DefaultValue = "";




        dtSummary.Columns.Add("productKind").DefaultValue = "";
        dtSummary.Columns.Add("currency").DefaultValue = "";
        dtSummary.Columns.Add("BS").DefaultValue = "";

        dtSummary.Columns.Add("ProductId").DefaultValue = "";
        dtSummary.Columns.Add("MKTCOMNO").DefaultValue = "";
        dtSummary.Columns.Add("COMYM").DefaultValue = "";
        dtSummary.Columns.Add("STKPRC").DefaultValue = "";
        dtSummary.Columns.Add("CALLPUT").DefaultValue = "";
        dtSummary.Columns.Add("productName").DefaultValue = "";
        dtSummary.Columns.Add("investoracno").DefaultValue = "";
        dtSummary.Columns.Add("AvgMatchPrice", typeof(double)).DefaultValue = 0;
        dtSummary.Columns.Add("realPrice", typeof(double)).DefaultValue = 0;
        dtSummary.Columns.Add("TotalOTQTY").DefaultValue = "";
        dtSummary.Columns.Add("RefTotalPL").DefaultValue = "";
        dtSummary.Columns.Add("multiplecomno").DefaultValue = "";
        dtSummary.Columns.Add("multipleBS").DefaultValue = "";
        dtSummary.Columns.Add("footMatchPrice").DefaultValue = "";
        dtSummary.Columns.Add("RefTotalPrice").DefaultValue = "";
        dtSummary.Columns.Add("multipleMatchPrice1").DefaultValue = "";
        dtSummary.Columns.Add("multipleMatchPrice2").DefaultValue = "";

        dtSummary.Columns.Add("PriceDiff").DefaultValue = "";
        dtSummary.Columns.Add("MultiName").DefaultValue = "";

        dtSummary.Columns.Add("IAMT").DefaultValue = "";
        dtSummary.Columns.Add("MAMT").DefaultValue = "";


        dtSummary.Columns["PriceDiff"].Expression = "IIF(BS='B',realPrice-AvgMatchPrice ,AvgMatchPrice-realPrice) ";

        dtSummary.Columns.Add("TAX").DefaultValue = "";
        dtSummary.Columns.Add("FEE").DefaultValue = "";
        dtSummary.Columns.Add("EQUITY").DefaultValue = "";
        SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);

        string sqlcurrency = "";
        if (currency.Trim().Length > 0)
        {
            sqlcurrency = "  and t.currency='" + currency + "' ";
        }
        string SqlCommand = "";

        SqlDataAdapter adp;


        if (spread == "Y" || spread == "")
        {
            //            SqlCommand = "select op.*, tblcloseprice.closeprice RefRealPrice,case when bs='B' then (tblcloseprice.closeprice-MatchPrice) * OTQTY *cntsize "
            //+ " else (MatchPrice-tblcloseprice.closeprice) * OTQTY *cntsize end RefPL from ("
            //+ " select  (case when fowopt.comtype='0' then '1'   when fowopt.spread='N' then '2' else '3'   end )productKind,spread,fowopt.CURRENCY,TRDDT tradedate,ORDNO,PS bs,DTOVER ,TRDPRc1 MatchPrice,(OTQTY- OSQTY)OTQTY "
            // + ",  rtrim( fbmcob.MKTCOMNO)+ case when fowopt.comtype='1' then "
            // + " right( '00000'+rtrim(convert(char(5),cast( STKPRICE* (case when STRIKE_PRICE_DECIMAL_LOCATOR=0 "
            //+ " then 1 when  STRIKE_PRICE_DECIMAL_LOCATOR=1 then 10 when  STRIKE_PRICE_DECIMAL_LOCATOR=2 "
            //+ " then 100 when  STRIKE_PRICE_DECIMAL_LOCATOR=3 then 1000 end    )as float))),5)else '' "
            //+ " end +Mapping.code+Year_CODE as Commodity_Id ,fbmcob.cntsize,"
            //+ " case when fbmcob.comtype='0' then fbmcob.abbr+comym "
            //+ " else fbmcob.abbr +convert (varchar,convert(float,STKPRICE))+fowopt.cp+comym "
            //+ " end ProductName, fbmcob.abbr ProductDesc "
            //+ " from (select * from  fowopt where writtendate='" + DateTime.Now.ToString("yyyyMMdd") + "'  "
            //+ " and company ='" + company + "' and actno='" + actno + "'  and spread<>'N'  and (OTQTY > OSQTY) ) fowopt "
            // + " left join FBMCOB on fowopt.comno =FBMCOB.comno and fowopt.CP=FBMCOB.callput "
            // + " left join Decimalplace  on  FBMCOB.mktcomno =cm001020 "
            //+ " left join Year_Mapping on substring(fowopt.comym,1,4)=Represent_Year "
            //+ " left join Mapping on substring(fowopt.comym,5,2)=Settlement_month "
            //+ " and (case when fowopt.cp='N'then 'C' else  fowopt.cp end)=Mapping.cp) op"
            // + " left join \"172.16.204.205\".VIPMarketInfoDB.dbo.tblcloseprice"
            // + " on op.Commodity_Id=tblcloseprice.Commodity_Id "
            //+ " order by tradedate ,substring(ordno,1,6)+substring(ordno,8,1)+substring(ordno,7,1) ";

            //            SqlCommand = "select op.*, convert(decimal(18,2), OP.CLRPRC1) RefRealPrice,convert(decimal(18,2),case when bs='B' then (OP.CLRPRC1-MatchPrice) * OTQTY *cntsize "
            //+ " else (MatchPrice-OP.CLRPRC1) * OTQTY *cntsize end) RefPL from ("
            //+ " select  (case when fowopt.comtype='0' then '1'   when fowopt.spread='N' then '2' else '3'   end )productKind,spread,fowopt.CURRENCY,TRDDT tradedate,ORDNO,PS bs,DTOVER ,convert(decimal(18,2),TRDPRc1) MatchPrice, convert(decimal(18,2),CLRPRC1)CLRPRC1,QTY OTQTY "
            //+ ",  rtrim( fbmcob.MKTCOMNO)+ case when fowopt.comtype='1' then "
            //+ " right( '00000'+rtrim(convert(char(5),cast( STKPRC* (case when STRIKE_PRICE_DECIMAL_LOCATOR=0 "
            //+ " then 1 when  STRIKE_PRICE_DECIMAL_LOCATOR=1 then 10 when  STRIKE_PRICE_DECIMAL_LOCATOR=2 "
            //+ " then 100 when  STRIKE_PRICE_DECIMAL_LOCATOR=3 then 1000 end    )as float))),5)else '' "
            //+ " end +Mapping.code+Year_CODE as Commodity_Id ,convert(decimal(18,2),fbmcob.cntsize)cntsize,"
            //+ " case when fbmcob.comtype='0' then fbmcob.abbr+comym "
            //+ " else fbmcob.abbr +convert (varchar,convert(float,STKPRC))+fowopt.callput+substring(comym,5,2) "
            //+ " end ProductName, fbmcob.abbr ProductDesc,actno investoracno ,fbmcob.MKTCOMNO,fowopt.comym COMYM,convert(decimal(18,2),fowopt.STKPRC) STKPRC,fowopt.CALLPUT CALLPUT,convert(decimal(18,2),fowopt.IAMT)IAMT,convert(decimal(18,2),fowopt.MAMT)MAMT "
            //+ " from (select * from  FBTOPD where writtendate=" + strDate + "  "
            //+ " and company ='" + company + "' and actno='" + actno + "'  and spread<>'N'  and  QTY>0 ) fowopt "
            //+ " left join FBMCOB on fowopt.comno =FBMCOB.comno and fowopt.callput=FBMCOB.callput "
            //+ " left join Decimalplace  on  FBMCOB.mktcomno =cm001020 "
            //+ " left join Year_Mapping on substring(fowopt.comym,1,4)=Represent_Year "
            //+ " left join Mapping on substring(fowopt.comym,5,2)=Settlement_month "
            //+ " and (case when fowopt.callput='N'then 'C' else  fowopt.callput end)=Mapping.cp) op"

            //+ " order by tradedate ,substring(ordno,1,6)+substring(ordno,8,1)+substring(ordno,7,1)  ";

            SqlCommand = @"
      select 
(case when (T.comtype='F' and  isnull(T.spread,'')='') THEN '1'  when (T.comtype='O' and  isnull(T.spread,'')='') THEN '2' else '3' end )productKind
,T.spread
,T.CURRENCY
 ,T.TRDDT tradedate
 ,T.TRNNO ORDNO 
 ,T.BS
 ,T.DTRADE DTOVER
   , T.TRDPRC1 MatchPrice
  , T.RealPrice  RefRealPrice
  
 , case when bs='B' then ( T.RealPrice-T.TRDPRC1) * T.OTQTY *T.cntsize 
 else (T.TRDPRC1-T.RealPrice) * T.OTQTY *T.cntsize end  RefPL 
  
  ,T.OTQTY 
  ,T.CNTSIZE
  ,  rtrim( case when T.comtype='F' then F.KIND_ID ELSE  O.KIND_ID END)
  + case when T.comtype='O' then 
 right( '00000'+rtrim(convert(char(5),cast(
  T.STKPRC*
   (case when O.STRIKE_PRICE_DECIMAL_LOCATOR=0 then 1 when  O.STRIKE_PRICE_DECIMAL_LOCATOR=1 then 10 when  O.STRIKE_PRICE_DECIMAL_LOCATOR=2 then 100 when  O.STRIKE_PRICE_DECIMAL_LOCATOR=3 then 1000 end    )
  as float))),5)
 else '' 
 end 
 +  CASE WHEN  T.CALLPUT ='P'  THEN  CHAR(76+SUBSTRING(T.comym,5,2)) ELSE   CHAR(64+SUBSTRING(T.comym,5,2)) END
 +SUBSTRING(T.comym,4,1) as Commodity_Id 
  
  
  
 ,case when T.comtype='F' then rtrim(F.SHORT_NAME)+T.comym 
 else rtrim(O.SHORT_NAME) +convert (varchar,convert(float,STKPRC))+T.callput+substring(T.comym,5,2) 
 end ProductName
 , case when T.comtype='F' then rtrim(F.SHORT_NAME) ELSE  rtrim(O.SHORT_NAME) END  ProductDesc
 ,T.actno investoracno 
, case when T.comtype='F' then F.KIND_ID ELSE  O.KIND_ID END MKTCOMNO
 ,T.comym COMYM
 ,T.STKPRC
 
  ,CASE WHEN T.CALLPUT='' THEN 'N' ELSE T.CALLPUT END CALLPUT
 ,T.IAMT  
 ,T.MAMT  
  ,T.TAX
,T.FEE
,(T.PRTLOS-T.TAX-T.FEE)EQUITY
  , T.TRDPRC1 * T.OTQTY totalprice
 from 

[dbo].[FTUD] T  
left join [dbo].[P09MF] F on T.COMNO=F.commOdity
left join [dbo].[P09M] O on T.COMNO=O.commodity 
WHERE 
T.TDATE =" + strDate + " and t.FIRM='" + company + "' and t.actno='" + actno + "'  and t.SPREAD <>''  " + sqlcurrency + "  and t.OTQTY >0    order by T.TRDDT ,substring(T.TRNNO,1,6)+substring(T.TRNNO,8,1)+substring(T.TRNNO,7,1)  ";





            adp = new SqlDataAdapter(SqlCommand, conn);
            DataTable dtData = new DataTable();
            adp.Fill(dtData);


            //暫存第一隻腳平倉兩方資訊.
            string pretradedate = "";
            string preordno = "";
            string multiplecomno = "";
            string multipleBS = "";
            string productId = "";
            string BS = "";
            string footMatchPrice = "";
            string MatchPrice = "";
            string RefRealPrice = "";
            string RefPL = "";
            string productName = "";
            string MKTCOMNO = "";
            string COMYM = "";
            string STKPRC = "";
            string CALLPUT = "";
            string IAMT = "";
            string MAMT = "";
            string multipleMatchPrice1 = "";
            string multipleMatchPrice2 = "";
            string RefNowPrice = "";

            string TAX = "";
            string FEE = "";
            string EQUITY = "";

            DataRow preData = null;
            //將平倉明細有複式資料組合成一筆
            foreach (DataRow dr in dtData.Rows)
            {


                if (pretradedate != "" && preordno != "")
                {
                    if (pretradedate != dr["tradedate"].ToString().Trim() || preordno != dr["ORDNO"].ToString().Trim().Substring(0, 6) + dr["ORDNO"].ToString().Trim().Substring(7, 1))
                    {
                        string[] multiplrice = footMatchPrice.Split(new string[] { "\n" }, StringSplitOptions.None);
                        if (multiplrice.Length == 2)
                        {
                            multipleMatchPrice1 = multiplrice[0];
                            multipleMatchPrice2 = multiplrice[1];
                        }

                        dtDetail.Rows.Add(new object[] { preData["productKind"].ToString().Trim(),preData["currency"].ToString().Trim(),pretradedate, preData["ORDNO"].ToString().Trim()
                        ,BS,productId ,productName,preData["investoracno"].ToString() ,MatchPrice,RefRealPrice,preData["OTQTY"].ToString(),RefPL,preData["DTOVER"].ToString(),multiplecomno ,multipleBS ,footMatchPrice,MKTCOMNO,COMYM,STKPRC ,CALLPUT ,IAMT,MAMT, multipleMatchPrice1, multipleMatchPrice2 ,"",RefNowPrice,TAX,FEE,EQUITY});

                        multiplecomno = "";
                        multipleBS = "";
                        productId = "";
                        BS = "";
                        footMatchPrice = "";
                        MatchPrice = "";
                        RefRealPrice = "";
                        RefPL = "";
                        preData = null;
                        productName = "";
                        MKTCOMNO = "";
                        COMYM = "";
                        STKPRC = "";
                        CALLPUT = "";
                        IAMT = "";
                        MAMT = "";
                        RefNowPrice = "";

                        TAX = "";
                        FEE = "";
                        EQUITY = "";

                    }
                }


                pretradedate = dr["tradedate"].ToString().Trim();
                preordno = dr["ORDNO"].ToString().Trim().Substring(0, 6) + dr["ORDNO"].ToString().Trim().Substring(7, 1);

                string spreadKind = dr["spread"].ToString().Trim();

                if (dr["ORDNO"].ToString().Trim().Substring(6, 1) == "1")
                {
                    preData = dr;

                    footMatchPrice = dr["MatchPrice"].ToString();
                    productId = dr["Commodity_Id"].ToString().Trim();
                    BS = dr["BS"].ToString();


                    MKTCOMNO = dr["MKTCOMNO"].ToString();
                    COMYM = dr["COMYM"].ToString();
                    STKPRC = dr["STKPRC"].ToString();
                    CALLPUT = dr["CALLPUT"].ToString();

                    IAMT = dr["IAMT"].ToString();
                    MAMT = dr["MAMT"].ToString();

                    TAX = dr["TAX"].ToString();
                    FEE = dr["FEE"].ToString();
                    EQUITY = dr["EQUITY"].ToString();

                }
                else
                {
                    if (spreadKind == "1" || spreadKind == "2" || spreadKind == "3" || spreadKind == "4" || spreadKind == "5")
                    {
                        string[] strReturn = MultipleProductId("3", preData["Commodity_Id"].ToString().Trim(), dr["Commodity_Id"].ToString().Trim(), preData["BS"].ToString(), dr["BS"].ToString(), dr["ProductDesc"].ToString());
                        multiplecomno = strReturn[0];
                        productName = strReturn[2];
                        multipleBS = strReturn[6];

                        productId = strReturn[3] + "\n" + strReturn[4];
                        BS = strReturn[5] + "\n" + strReturn[6];


                        MKTCOMNO = strReturn[3].Substring(0, 3);
                        COMYM = strReturn[11] + "\n" + strReturn[12];
                        STKPRC = strReturn[9] + "\n" + strReturn[10];
                        CALLPUT = strReturn[7] + "\n" + strReturn[8];


                        if (dr["BS"].ToString() == strReturn[6])
                        {

                            footMatchPrice += "\n" + dr["MatchPrice"].ToString();
                            MatchPrice = getMultiplePrice(spreadKind, multipleBS, preData["BS"].ToString(), dr["BS"].ToString(), Convert.ToDecimal(preData["MatchPrice"].ToString()), Convert.ToDecimal(dr["MatchPrice"].ToString())).ToString();
                            RefRealPrice = getMultiplePrice(spreadKind, multipleBS, preData["BS"].ToString(), dr["BS"].ToString(), Convert.ToDecimal(preData["RefRealPrice"].ToString()), Convert.ToDecimal(dr["RefRealPrice"].ToString())).ToString();

                        }
                        else
                        {
                            footMatchPrice = dr["MatchPrice"] + "\n" + preData["MatchPrice"].ToString();
                            MatchPrice = getMultiplePrice(spreadKind, multipleBS, dr["BS"].ToString(), preData["BS"].ToString(), Convert.ToDecimal(dr["MatchPrice"].ToString()), Convert.ToDecimal(preData["MatchPrice"].ToString())).ToString();
                            RefRealPrice = getMultiplePrice(spreadKind, multipleBS, dr["BS"].ToString(), preData["BS"].ToString(), Convert.ToDecimal(dr["RefRealPrice"].ToString()), Convert.ToDecimal(preData["RefRealPrice"].ToString())).ToString();



                        }


                        if (multipleBS.ToString() == "B")
                        {
                            RefPL = ((decimal.Parse(RefRealPrice) - decimal.Parse(MatchPrice)) * int.Parse(dr["OTQTY"].ToString()) * decimal.Parse(dr["cntsize"].ToString())).ToString("#,##0.##");
                        }
                        else
                        {
                            RefPL = ((decimal.Parse(MatchPrice) - decimal.Parse(RefRealPrice)) * int.Parse(dr["OTQTY"].ToString()) * decimal.Parse(dr["cntsize"].ToString())).ToString("#,##0.##");
                        }
                        RefNowPrice = (decimal.Parse(MatchPrice) * int.Parse(dr["OTQTY"].ToString()) * decimal.Parse(dr["cntsize"].ToString())).ToString("#,##0.##");


                    }
                    else
                    {
                        multipleBS = dr["BS"].ToString();

                        MatchPrice = "0";
                        RefRealPrice = "0";
                        RefNowPrice = "0";
                        RefPL = "0";
                        productName = preData["productName"].ToString() + " " + dr["productName"].ToString();
                        footMatchPrice += "\n" + dr["MatchPrice"].ToString();
                        productId += "\n" + dr["Commodity_Id"].ToString().Trim();
                        BS += "\n" + dr["BS"].ToString();


                        MKTCOMNO += "\n" + dr["MKTCOMNO"].ToString();
                        COMYM += "\n" + dr["COMYM"].ToString();
                        STKPRC += "\n" + dr["STKPRC"].ToString();
                        CALLPUT += "\n" + dr["CALLPUT"].ToString();
                    }

                    IAMT = (decimal.Parse(IAMT) + decimal.Parse(dr["IAMT"].ToString())).ToString();
                    MAMT = (decimal.Parse(MAMT) + decimal.Parse(dr["MAMT"].ToString())).ToString();

                    TAX = (decimal.Parse(TAX) + decimal.Parse(dr["TAX"].ToString())).ToString();
                    FEE = (decimal.Parse(FEE) + decimal.Parse(dr["FEE"].ToString())).ToString();
                    EQUITY = (decimal.Parse(EQUITY) + decimal.Parse(dr["EQUITY"].ToString())).ToString();
                }

            }
            if (preData != null)
            {
                if (pretradedate != "" && preordno != "")
                {
                    string[] multiplrice = footMatchPrice.Split(new string[] { "\n" }, StringSplitOptions.None);
                    if (multiplrice.Length == 2)
                    {
                        multipleMatchPrice1 = multiplrice[0];
                        multipleMatchPrice2 = multiplrice[1];
                    }

                    dtDetail.Rows.Add(new object[] {preData["productKind"].ToString().Trim(), preData["currency"].ToString().Trim(),pretradedate, preData["ORDNO"].ToString().Trim() 
                        ,BS,productId,productName ,preData["investoracno"].ToString(),MatchPrice,RefRealPrice,preData["OTQTY"].ToString(),RefPL,preData["DTOVER"].ToString(),multiplecomno ,multipleBS ,footMatchPrice ,MKTCOMNO,COMYM,STKPRC ,CALLPUT ,IAMT,MAMT,multipleMatchPrice1,multipleMatchPrice2,"",RefNowPrice,TAX,FEE,EQUITY});

                }
            }
            DataView unliquidationDetail = new DataView(dtDetail);
            DataTable dtTarget = unliquidationDetail.Table.DefaultView.ToTable(true, new string[] { "BS", "productId", "currency" });

            if (dtTarget.Rows.Count != 0)
            {
                foreach (DataRow dr in dtTarget.Rows)
                {

                    int tempOTQTY = 0;
                    double tempTRDPRC1 = 0;
                    double tempCurrentBalance = 0;
                    double tempRefTotalPrice = 0;
                    double tempIAMT = 0;
                    double tempMAMT = 0;
                    double tempTAX = 0;
                    double tempFEE = 0;
                    double tempEQUITY = 0;
                    DataRow drrResult = dtSummary.NewRow();
                    string command = "BS='" + dr["BS"] + "' and productId = '" + dr["productId"] + "' and currency = '" + dr["currency"] + "' ";
                    DataRow[] rCount = dtDetail.Select(command);
                    Dictionary<int, decimal> dcFootPrice = new Dictionary<int, decimal>();
                    foreach (DataRow drr in rCount)
                    {
                        if (drr["footMatchPrice"].ToString() != "")
                        {
                            int idx = 0;
                            foreach (string foot in drr["footMatchPrice"].ToString().Split(new Char[] { }))
                            {

                                if (dcFootPrice.ContainsKey(idx))
                                {
                                    dcFootPrice[idx] += decimal.Parse(foot) * decimal.Parse(drr["OTQTY"].ToString());
                                }
                                else
                                {
                                    dcFootPrice.Add(idx, decimal.Parse(foot) * decimal.Parse(drr["OTQTY"].ToString()));
                                }
                                idx++;
                            }

                        }
                        tempOTQTY += Convert.ToInt16(drr["OTQTY"].ToString());

                        if (drr["MatchPrice"].ToString() != "")
                        {
                            tempTRDPRC1 += double.Parse(drr["MatchPrice"].ToString()) * Convert.ToInt16(drr["OTQTY"].ToString());
                        }

                        //if (drr["CurrentBalance"].ToString() == "NA")
                        if (drr["RefPL"].ToString() == "NA")
                        {
                            tempCurrentBalance += 0;
                        }
                        else
                        {
                            tempCurrentBalance += double.Parse(drr["RefPL"].ToString());   //
                        }

                        if (drr["RefRealPrice"].ToString() == "NA")
                        {
                            tempRefTotalPrice += 0;
                        }
                        else
                        {
                            tempRefTotalPrice += double.Parse(drr["RefRealPrice"].ToString());
                        }
                        if (drr["RefRealPrice"].ToString() == "NA")
                        {
                            drrResult["realprice"] = "0";
                        }
                        else
                        {
                            drrResult["realprice"] = drr["RefRealPrice"].ToString().Trim();
                        }

                        tempIAMT += double.Parse(drr["IAMT"].ToString());

                        tempMAMT += double.Parse(drr["MAMT"].ToString());
                        tempTAX += double.Parse(drr["TAX"].ToString());

                        tempFEE += double.Parse(drr["FEE"].ToString());
                        tempEQUITY += double.Parse(drr["EQUITY"].ToString());
                        drrResult["BS"] = drr["BS"].ToString().Trim();

                        drrResult["ProductId"] = drr["ProductId"].ToString().Trim();

                        drrResult["productName"] = drr["productName"].ToString().Trim();

                        drrResult["currency"] = drr["currency"].ToString().Trim();

                        drrResult["multiplecomno"] = drr["multiplecomno"].ToString().Trim();

                        drrResult["multipleBS"] = drr["multipleBS"].ToString().Trim();

                        drrResult["productKind"] = drr["productKind"].ToString().Trim();




                        drrResult["investoracno"] = drr["investoracno"].ToString();
                        drrResult["MKTCOMNO"] = drr["MKTCOMNO"].ToString().Trim();
                        drrResult["COMYM"] = drr["COMYM"].ToString().Trim();
                        drrResult["STKPRC"] = drr["STKPRC"].ToString().Trim();
                        drrResult["CALLPUT"] = drr["CALLPUT"].ToString().Trim();
                        MobDataParse obj_mob = new MobDataParse();

                        //added by philip 20100505 新增彙總複式商品組成類別
                        if ((drrResult["productKind"].ToString() == "3" | drrResult["productKind"].ToString() == "4") & drrResult["multipleBS"].ToString() != "" & drrResult["multiplecomno"].ToString() != "")
                        {
                            drrResult["MultiName"] = obj_mob.MultiProductParser(drrResult["productKind"].ToString(), drrResult["multipleBS"].ToString(), drrResult["multiplecomno"].ToString(), drrResult["BS"].ToString().Split('\n')[0].ToString().Trim())[0];
                        }
                        if ((drrResult["productKind"].ToString() == "3" | drrResult["productKind"].ToString() == "4") & drrResult["multiplecomno"].ToString() == "")
                        {
                            drrResult["MultiName"] = "0";
                            drrResult["multiplecomno"] = drrResult["productId"].ToString();
                            drrResult["multipleBS"] = drrResult["BS"].ToString();
                        }


                    }


                    drrResult["TotalOTQTY"] = tempOTQTY.ToString();


                    if (tempOTQTY == 0)
                    {

                        //added 20100414 
                        drrResult["RefTotalPrice"] = "0";
                    }
                    else
                    {
                        double TRDPRC1 = tempTRDPRC1 / tempOTQTY;
                        //added 20100326 四捨五入
                        double roundoff_TRDPRC1 = Math.Round(TRDPRC1, 2, MidpointRounding.AwayFromZero);

                        drrResult["AvgMatchPrice"] = roundoff_TRDPRC1.ToString("#,##0.##");
                        double roundoff_tempRefTotalPrice = Math.Round(tempRefTotalPrice, 2, MidpointRounding.AwayFromZero);
                        drrResult["RefTotalPrice"] = roundoff_tempRefTotalPrice.ToString("#,##0.##");

                        if (drrResult["realprice"] == System.DBNull.Value)
                        {

                            drrResult["RefTotalPL"] = "0";
                        }
                        else
                        {
                            //added 20100326 四捨五入
                            double roundoff_tempCurrentBalance = Math.Round(tempCurrentBalance, 2, MidpointRounding.AwayFromZero);

                            drrResult["RefTotalPL"] = roundoff_tempCurrentBalance.ToString("#,##0.##");


                        }
                        if (dcFootPrice.Keys.Count > 0)
                        {

                            foreach (int key in dcFootPrice.Keys)
                            {
                                if (key == 0)
                                {
                                    drrResult["footMatchPrice"] = (dcFootPrice[key] / tempOTQTY).ToString("#,##0.##");
                                }
                                else
                                {
                                    drrResult["footMatchPrice"] += "\n" + (dcFootPrice[key] / tempOTQTY).ToString("#,##0.##");
                                }
                            }
                            string[] multiplrice = drrResult["footMatchPrice"].ToString().Split(new string[] { "\n" }, StringSplitOptions.None);
                            if (multiplrice.Length == 2)
                            {
                                drrResult["multipleMatchPrice1"] = multiplrice[0];
                                drrResult["multipleMatchPrice2"] = multiplrice[1];
                            }
                        }
                    }
                    drrResult["IAMT"] = tempIAMT.ToString("#,##0.##");
                    drrResult["MAMT"] = tempMAMT.ToString("#,##0.##");
                    drrResult["TAX"] = tempTAX.ToString("#,##0.##");
                    drrResult["FEE"] = tempFEE.ToString("#,##0.##");

                    drrResult["EQUITY"] = tempEQUITY.ToString("#,##0.##");
                    //added by philip 20100505 新增彙總複式商品組成類別


                    drrResult["multiplecomno"] = drrResult["multiplecomno"].ToString();
                    drrResult["multipleBS"] = drrResult["multipleBS"].ToString();



                    dtSummary.Rows.Add(drrResult);

                }

            }

        }
        if (spread == "N" || spread == "" || spread == "A")
        {
            string spreadcondition = "";
            if (spread == "N" || spread == "")
            {
                spreadcondition = " and spread='' ";
            }
            SqlCommand = @"select 
(case when (T.comtype='F' and  isnull(T.spread,'')='') THEN '1'  when (T.comtype='O' and  isnull(T.spread,'')='') THEN '2' else '3' end )productKind
,T.spread
,T.CURRENCY
 ,T.TRDDT tradedate
 ,T.TRNNO orderNo 
 ,T.BS
 ,T.DTRADE DTOVER
   , T.TRDPRC1 MatchPrice
  , T.RealPrice  RefRealPrice
  
 , case when bs='B' then ( T.RealPrice-T.TRDPRC1) * T.OTQTY *T.cntsize 
 else (T.TRDPRC1-T.RealPrice) * T.OTQTY *T.cntsize end  RefPL 
  
  ,T.OTQTY 
  ,T.CNTSIZE
  ,  rtrim( case when T.comtype='F' then F.KIND_ID ELSE  O.KIND_ID END)
  + case when T.comtype='O' then 
 right( '00000'+rtrim(convert(char(5),cast(
  T.STKPRC*
   (case when O.STRIKE_PRICE_DECIMAL_LOCATOR=0 then 1 when  O.STRIKE_PRICE_DECIMAL_LOCATOR=1 then 10 when  O.STRIKE_PRICE_DECIMAL_LOCATOR=2 then 100 when  O.STRIKE_PRICE_DECIMAL_LOCATOR=3 then 1000 end    )
  as float))),5)
 else '' 
 end 
 +  CASE WHEN  T.CALLPUT ='P'  THEN  CHAR(76+SUBSTRING(T.comym,5,2)) ELSE   CHAR(64+SUBSTRING(T.comym,5,2)) END
 +SUBSTRING(T.comym,4,1) as ProductId 
  
  
  
 ,case when T.comtype='F' then rtrim(F.SHORT_NAME)+T.comym 
 else rtrim(O.SHORT_NAME) +convert (varchar,convert(float,STKPRC))+T.callput+substring(T.comym,5,2) 
 end ProductName
 , case when T.comtype='F' then rtrim(F.SHORT_NAME) ELSE  rtrim(O.SHORT_NAME) END  ProductDesc
 ,T.actno investoracno 
, case when T.comtype='F' then F.KIND_ID ELSE  O.KIND_ID END MKTCOMNO
 ,T.comym COMYM
 ,T.STKPRC
 
   ,CASE WHEN T.CALLPUT='' THEN 'N' ELSE T.CALLPUT END CALLPUT
 ,T.IAMT  
 ,T.MAMT  
  ,T.TAX
,T.FEE
,(T.PRTLOS-T.TAX-T.FEE)EQUITY
  , T.TRDPRC1 * T.OTQTY totalprice
  
 from 

[dbo].[FTUD] T  
left join [dbo].[P09MF] F on T.COMNO=F.commOdity
left join [dbo].[P09M] O on T.COMNO=O.commodity 
WHERE 
T.TDATE =" + strDate + " and t.FIRM='" + company + "' and t.actno='" + actno + "'   " + spreadcondition + " " + sqlcurrency + "   and t.OTQTY >0     ";




            adp = new SqlDataAdapter(SqlCommand, conn);

            adp.Fill(dtDetail);

            SqlCommand = @" select productKind,BS,ProductId,productName,MKTCOMNO,COMYM,STKPRC,CALLPUT,currency,convert(decimal(18,4),RefRealPrice)realPrice,investoracno , convert(decimal(18,2),sum( totalprice)/sum(OTQTY)) AvgMatchPrice, sum( OTQTY)TotalOTQTY,convert(decimal(18,2), sum(RefPL))RefTotalPL ,convert(decimal(18,2),sum(iamt))iamt,convert(decimal(18,2),sum(mamt ))mamt,SUM(TAX)TAX,SUM(FEE)FEE ,sum(EQUITY)EQUITY from (" + SqlCommand + ")detail "
 + " group by productKind,BS,ProductId,ProductName,MKTCOMNO,COMYM,STKPRC,CALLPUT,currency,refrealPrice,investoracno   ";
            adp = new SqlDataAdapter(SqlCommand, conn);

            adp.Fill(dtSummary);
        }
        DataTable dt1 = new DataTable();
        foreach (DataColumn dc in dtSummary.Columns)
        {
            dt1.Columns.Add(dc.ColumnName);
        }
        DataRow[] drs1 = dtSummary.Select("", " productKind, MKTCOMNO, COMYM, STKPRC,CALLPUT");
        for (int i = 0; i < drs1.Length; i++)
        {
            DataRow drNew = dt1.NewRow();
            drNew.ItemArray = drs1[i].ItemArray;
            drNew["AvgMatchPrice"] = NumberTrim(drNew["AvgMatchPrice"].ToString());
            drNew["realPrice"] = NumberTrim(drNew["realPrice"].ToString());
            drNew["RefTotalPL"] = NumberTrim(drNew["RefTotalPL"].ToString());
            drNew["RefTotalPrice"] = NumberTrim(drNew["RefTotalPrice"].ToString());
            drNew["multipleMatchPrice1"] = NumberTrim(drNew["multipleMatchPrice1"].ToString());
            drNew["multipleMatchPrice2"] = NumberTrim(drNew["multipleMatchPrice2"].ToString());
            drNew["PriceDiff"] = NumberTrim(drNew["PriceDiff"].ToString());
            drNew["IAMT"] = NumberTrim(drNew["IAMT"].ToString());
            drNew["MAMT"] = NumberTrim(drNew["MAMT"].ToString());
            drNew["TAX"] = NumberTrim(drNew["TAX"].ToString());

            drNew["FEE"] = NumberTrim(drNew["FEE"].ToString());


            dt1.Rows.Add(drNew);
        }


        DataTable dt2 = new DataTable();
        foreach (DataColumn dc in dtDetail.Columns)
        {
            dt2.Columns.Add(dc.ColumnName);
        }
        DataRow[] drs2 = dtDetail.Select("", " productKind, MKTCOMNO, COMYM, STKPRC,CALLPUT");
        for (int i = 0; i < drs2.Length; i++)
        {
            DataRow drNew = dt2.NewRow();
            drNew.ItemArray = drs2[i].ItemArray;

            drNew["MatchPrice"] = NumberTrim(drNew["MatchPrice"].ToString());
            drNew["RefRealPrice"] = NumberTrim(drNew["RefRealPrice"].ToString());
            drNew["RefNowPrice"] = NumberTrim(drNew["RefNowPrice"].ToString());
            drNew["RefPL"] = NumberTrim(drNew["RefPL"].ToString());
            drNew["TatolMatchPrice"] = NumberTrim(drNew["TatolMatchPrice"].ToString());
            drNew["multipleMatchPrice1"] = NumberTrim(drNew["multipleMatchPrice1"].ToString());
            drNew["multipleMatchPrice2"] = NumberTrim(drNew["multipleMatchPrice2"].ToString());
            drNew["IAMT"] = NumberTrim(drNew["IAMT"].ToString());
            drNew["MAMT"] = NumberTrim(drNew["MAMT"].ToString());
            drNew["TAX"] = NumberTrim(drNew["TAX"].ToString());

            drNew["FEE"] = NumberTrim(drNew["FEE"].ToString());

            dt2.Rows.Add(drNew);
        }



        dsData.Tables.Add(dt2);
        dsData.Tables.Add(dt1);


        return dsData;
    }


    //V1.0.0.17 Added by peter on 20140616 月份(週選先), 買賣權(先CALL後PUT), 履約價(由小到大)
    public DataSet getUnLiquidationSortByCP(string company, string actno, string spread, string currency)
    {


        string strDate = "convert(char(8),getdate(),112)";
        //判斷查今天或查前天
        //  if (closeday || DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_OpenTime"].ToString()))
        {
            strDate = "(select max(tdate) from dbo.FTUD) ";
        }

        bool isok = false;
        DataSet dsData = new DataSet();
        DataTable dtDetail = new DataTable();
        DataTable dtSummary = new DataTable();
        dtDetail.Columns.Add("productKind").DefaultValue = "";


        dtDetail.Columns.Add("currency").DefaultValue = "";
        dtDetail.Columns.Add("tradedate").DefaultValue = "";
        dtDetail.Columns.Add("orderNo").DefaultValue = "";

        dtDetail.Columns.Add("BS").DefaultValue = "";
        dtDetail.Columns.Add("ProductId").DefaultValue = "";

        dtDetail.Columns.Add("productName").DefaultValue = "";
        dtDetail.Columns.Add("investoracno").DefaultValue = "";
        dtDetail.Columns.Add("MatchPrice", typeof(decimal)).DefaultValue = 0;
        dtDetail.Columns.Add("RefRealPrice").DefaultValue = "";
        dtDetail.Columns.Add("OTQTY", typeof(decimal)).DefaultValue = 0;
        dtDetail.Columns.Add("RefPL").DefaultValue = "";


        dtDetail.Columns.Add("DTOVER").DefaultValue = "";
        dtDetail.Columns.Add("multiplecomno").DefaultValue = "";
        dtDetail.Columns.Add("multipleBS").DefaultValue = "";
        dtDetail.Columns.Add("footMatchPrice").DefaultValue = "";
        dtDetail.Columns.Add("MKTCOMNO").DefaultValue = "";
        dtDetail.Columns.Add("COMYM").DefaultValue = "";
        dtDetail.Columns.Add("STKPRC").DefaultValue = "";
        dtDetail.Columns.Add("CALLPUT").DefaultValue = "";
        dtDetail.Columns.Add("IAMT").DefaultValue = "";
        dtDetail.Columns.Add("MAMT").DefaultValue = "";
        dtDetail.Columns.Add("multipleMatchPrice1").DefaultValue = "";
        dtDetail.Columns.Add("multipleMatchPrice2").DefaultValue = "";

        dtDetail.Columns.Add("matchTime").DefaultValue = "";
        dtDetail.Columns.Add("RefNowPrice").DefaultValue = "";
        dtDetail.Columns.Add("TAX").DefaultValue = "";
        dtDetail.Columns.Add("FEE").DefaultValue = "";
        dtDetail.Columns.Add("EQUITY").DefaultValue = "";


        dtDetail.Columns.Add("TatolMatchPrice", typeof(decimal));//成交價格
        dtDetail.Columns["TatolMatchPrice"].Expression = "MatchPrice*OTQTY";
        dtDetail.Columns.Add("matchseq").DefaultValue = "";




        dtSummary.Columns.Add("productKind").DefaultValue = "";
        dtSummary.Columns.Add("currency").DefaultValue = "";
        dtSummary.Columns.Add("BS").DefaultValue = "";

        dtSummary.Columns.Add("ProductId").DefaultValue = "";
        dtSummary.Columns.Add("MKTCOMNO").DefaultValue = "";
        dtSummary.Columns.Add("COMYM").DefaultValue = "";
        dtSummary.Columns.Add("STKPRC").DefaultValue = "";
        dtSummary.Columns.Add("CALLPUT").DefaultValue = "";
        dtSummary.Columns.Add("productName").DefaultValue = "";
        dtSummary.Columns.Add("investoracno").DefaultValue = "";
        dtSummary.Columns.Add("AvgMatchPrice", typeof(double)).DefaultValue = 0;
        dtSummary.Columns.Add("realPrice", typeof(double)).DefaultValue = 0;
        dtSummary.Columns.Add("TotalOTQTY").DefaultValue = "";
        dtSummary.Columns.Add("RefTotalPL").DefaultValue = "";
        dtSummary.Columns.Add("multiplecomno").DefaultValue = "";
        dtSummary.Columns.Add("multipleBS").DefaultValue = "";
        dtSummary.Columns.Add("footMatchPrice").DefaultValue = "";
        dtSummary.Columns.Add("RefTotalPrice").DefaultValue = "";
        dtSummary.Columns.Add("multipleMatchPrice1").DefaultValue = "";
        dtSummary.Columns.Add("multipleMatchPrice2").DefaultValue = "";

        dtSummary.Columns.Add("PriceDiff").DefaultValue = "";
        dtSummary.Columns.Add("MultiName").DefaultValue = "";

        dtSummary.Columns.Add("IAMT").DefaultValue = "";
        dtSummary.Columns.Add("MAMT").DefaultValue = "";


        dtSummary.Columns["PriceDiff"].Expression = "IIF(BS='B',realPrice-AvgMatchPrice ,AvgMatchPrice-realPrice) ";

        dtSummary.Columns.Add("TAX").DefaultValue = "";
        dtSummary.Columns.Add("FEE").DefaultValue = "";
        dtSummary.Columns.Add("EQUITY").DefaultValue = "";
        SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);

        string sqlcurrency = "";
        if (currency.Trim().Length > 0)
        {
            sqlcurrency = "  and t.currency='" + currency + "' ";
        }

        string SqlCommand = "";

        SqlDataAdapter adp;


        if (spread == "Y" || spread == "")
        {
            //            SqlCommand = "select op.*, tblcloseprice.closeprice RefRealPrice,case when bs='B' then (tblcloseprice.closeprice-MatchPrice) * OTQTY *cntsize "
            //+ " else (MatchPrice-tblcloseprice.closeprice) * OTQTY *cntsize end RefPL from ("
            //+ " select  (case when fowopt.comtype='0' then '1'   when fowopt.spread='N' then '2' else '3'   end )productKind,spread,fowopt.CURRENCY,TRDDT tradedate,ORDNO,PS bs,DTOVER ,TRDPRc1 MatchPrice,(OTQTY- OSQTY)OTQTY "
            // + ",  rtrim( fbmcob.MKTCOMNO)+ case when fowopt.comtype='1' then "
            // + " right( '00000'+rtrim(convert(char(5),cast( STKPRICE* (case when STRIKE_PRICE_DECIMAL_LOCATOR=0 "
            //+ " then 1 when  STRIKE_PRICE_DECIMAL_LOCATOR=1 then 10 when  STRIKE_PRICE_DECIMAL_LOCATOR=2 "
            //+ " then 100 when  STRIKE_PRICE_DECIMAL_LOCATOR=3 then 1000 end    )as float))),5)else '' "
            //+ " end +Mapping.code+Year_CODE as Commodity_Id ,fbmcob.cntsize,"
            //+ " case when fbmcob.comtype='0' then fbmcob.abbr+comym "
            //+ " else fbmcob.abbr +convert (varchar,convert(float,STKPRICE))+fowopt.cp+comym "
            //+ " end ProductName, fbmcob.abbr ProductDesc "
            //+ " from (select * from  fowopt where writtendate='" + DateTime.Now.ToString("yyyyMMdd") + "'  "
            //+ " and company ='" + company + "' and actno='" + actno + "'  and spread<>'N'  and (OTQTY > OSQTY) ) fowopt "
            // + " left join FBMCOB on fowopt.comno =FBMCOB.comno and fowopt.CP=FBMCOB.callput "
            // + " left join Decimalplace  on  FBMCOB.mktcomno =cm001020 "
            //+ " left join Year_Mapping on substring(fowopt.comym,1,4)=Represent_Year "
            //+ " left join Mapping on substring(fowopt.comym,5,2)=Settlement_month "
            //+ " and (case when fowopt.cp='N'then 'C' else  fowopt.cp end)=Mapping.cp) op"
            // + " left join \"172.16.204.205\".VIPMarketInfoDB.dbo.tblcloseprice"
            // + " on op.Commodity_Id=tblcloseprice.Commodity_Id "
            //+ " order by tradedate ,substring(ordno,1,6)+substring(ordno,8,1)+substring(ordno,7,1) ";

            //            SqlCommand = "select op.*, convert(decimal(18,2), OP.CLRPRC1) RefRealPrice,convert(decimal(18,2),case when bs='B' then (OP.CLRPRC1-MatchPrice) * OTQTY *cntsize "
            //+ " else (MatchPrice-OP.CLRPRC1) * OTQTY *cntsize end) RefPL from ("
            //+ " select  (case when fowopt.comtype='0' then '1'   when fowopt.spread='N' then '2' else '3'   end )productKind,spread,fowopt.CURRENCY,TRDDT tradedate,ORDNO,PS bs,DTOVER ,convert(decimal(18,2),TRDPRc1) MatchPrice, convert(decimal(18,2),CLRPRC1)CLRPRC1,QTY OTQTY "
            //+ ",  rtrim( fbmcob.MKTCOMNO)+ case when fowopt.comtype='1' then "
            //+ " right( '00000'+rtrim(convert(char(5),cast( STKPRC* (case when STRIKE_PRICE_DECIMAL_LOCATOR=0 "
            //+ " then 1 when  STRIKE_PRICE_DECIMAL_LOCATOR=1 then 10 when  STRIKE_PRICE_DECIMAL_LOCATOR=2 "
            //+ " then 100 when  STRIKE_PRICE_DECIMAL_LOCATOR=3 then 1000 end    )as float))),5)else '' "
            //+ " end +Mapping.code+Year_CODE as Commodity_Id ,convert(decimal(18,2),fbmcob.cntsize)cntsize,"
            //+ " case when fbmcob.comtype='0' then fbmcob.abbr+comym "
            //+ " else fbmcob.abbr +convert (varchar,convert(float,STKPRC))+fowopt.callput+substring(comym,5,2) "
            //+ " end ProductName, fbmcob.abbr ProductDesc,actno investoracno ,fbmcob.MKTCOMNO,fowopt.comym COMYM,convert(decimal(18,2),fowopt.STKPRC) STKPRC,fowopt.CALLPUT CALLPUT,convert(decimal(18,2),fowopt.IAMT)IAMT,convert(decimal(18,2),fowopt.MAMT)MAMT "
            //+ " from (select * from  FBTOPD where writtendate=" + strDate + "  "
            //+ " and company ='" + company + "' and actno='" + actno + "'  and spread<>'N'  and  QTY>0 ) fowopt "
            //+ " left join FBMCOB on fowopt.comno =FBMCOB.comno and fowopt.callput=FBMCOB.callput "
            //+ " left join Decimalplace  on  FBMCOB.mktcomno =cm001020 "
            //+ " left join Year_Mapping on substring(fowopt.comym,1,4)=Represent_Year "
            //+ " left join Mapping on substring(fowopt.comym,5,2)=Settlement_month "
            //+ " and (case when fowopt.callput='N'then 'C' else  fowopt.callput end)=Mapping.cp) op"

            //+ " order by tradedate ,substring(ordno,1,6)+substring(ordno,8,1)+substring(ordno,7,1)  ";

            SqlCommand = @"
      select 
(case when (T.comtype='F' and  isnull(T.spread,'')='') THEN '1'  when (T.comtype='O' and  isnull(T.spread,'')='') THEN '2' else '3' end )productKind
,T.spread
,T.CURRENCY
 ,T.TRDDT tradedate
 ,T.TRNNO ORDNO 
 ,T.BS
 ,T.DTRADE DTOVER
   , T.TRDPRC1 MatchPrice
  , T.RealPrice  RefRealPrice
  
 , case when bs='B' then ( T.RealPrice-T.TRDPRC1) * T.OTQTY *T.cntsize 
 else (T.TRDPRC1-T.RealPrice) * T.OTQTY *T.cntsize end  RefPL 
  
  ,T.OTQTY 
  ,T.CNTSIZE
  ,  rtrim( case when T.comtype='F' then F.KIND_ID ELSE  O.KIND_ID END)
  + case when T.comtype='O' then 
 right( '00000'+rtrim(convert(char(5),cast(
  T.STKPRC*
   (case when O.STRIKE_PRICE_DECIMAL_LOCATOR=0 then 1 when  O.STRIKE_PRICE_DECIMAL_LOCATOR=1 then 10 when  O.STRIKE_PRICE_DECIMAL_LOCATOR=2 then 100 when  O.STRIKE_PRICE_DECIMAL_LOCATOR=3 then 1000 end    )
  as float))),5)
 else '' 
 end 
 +  CASE WHEN  T.CALLPUT ='P'  THEN  CHAR(76+SUBSTRING(T.comym,5,2)) ELSE   CHAR(64+SUBSTRING(T.comym,5,2)) END
 +SUBSTRING(T.comym,4,1) as Commodity_Id 
  
  
  
 ,case when T.comtype='F' then rtrim(F.SHORT_NAME)+T.comym 
 else rtrim(O.SHORT_NAME) +convert (varchar,convert(float,STKPRC))+T.callput+substring(T.comym,5,2) 
 end ProductName
 , case when T.comtype='F' then rtrim(F.SHORT_NAME) ELSE  rtrim(O.SHORT_NAME) END  ProductDesc
 ,T.actno investoracno 
, case when T.comtype='F' then F.KIND_ID ELSE  O.KIND_ID END MKTCOMNO
 ,T.comym COMYM
 ,T.STKPRC
 
  ,CASE WHEN T.CALLPUT='' THEN 'N' ELSE T.CALLPUT END CALLPUT
 ,T.IAMT  
 ,T.MAMT  
  ,T.TAX
,T.FEE
,(T.PRTLOS-T.TAX-T.FEE)EQUITY
  , T.TRDPRC1 * T.OTQTY totalprice
 from 

[dbo].[FTUD] T  
left join [dbo].[P09MF] F on T.COMNO=F.commOdity
left join [dbo].[P09M] O on T.COMNO=O.commodity 
WHERE 
T.TDATE =" + strDate + " and t.FIRM='" + company + "' and t.actno='" + actno + "'  and t.SPREAD <>'' and t.OTQTY >0 " + sqlcurrency + "   order by T.TRDDT ,substring(T.TRNNO,1,6)+substring(T.TRNNO,8,1)+substring(T.TRNNO,7,1)  ";





            adp = new SqlDataAdapter(SqlCommand, conn);
            DataTable dtData = new DataTable();
            adp.Fill(dtData);


            //暫存第一隻腳平倉兩方資訊.
            string pretradedate = "";
            string preordno = "";
            string multiplecomno = "";
            string multipleBS = "";
            string productId = "";
            string BS = "";
            string footMatchPrice = "";
            string MatchPrice = "";
            string RefRealPrice = "";
            string RefPL = "";
            string productName = "";
            string MKTCOMNO = "";
            string COMYM = "";
            string STKPRC = "";
            string CALLPUT = "";
            string IAMT = "";
            string MAMT = "";
            string multipleMatchPrice1 = "";
            string multipleMatchPrice2 = "";
            string RefNowPrice = "";

            string TAX = "";
            string FEE = "";
            string EQUITY = "";

            DataRow preData = null;
            //將平倉明細有複式資料組合成一筆
            foreach (DataRow dr in dtData.Rows)
            {


                if (pretradedate != "" && preordno != "")
                {
                    if (pretradedate != dr["tradedate"].ToString().Trim() || preordno != dr["ORDNO"].ToString().Trim().Substring(0, 6) + dr["ORDNO"].ToString().Trim().Substring(7, 1))
                    {
                        string[] multiplrice = footMatchPrice.Split(new string[] { "\n" }, StringSplitOptions.None);
                        if (multiplrice.Length == 2)
                        {
                            multipleMatchPrice1 = multiplrice[0];
                            multipleMatchPrice2 = multiplrice[1];
                        }

                        dtDetail.Rows.Add(new object[] { preData["productKind"].ToString().Trim(),preData["currency"].ToString().Trim(),pretradedate, preData["ORDNO"].ToString().Trim()
                        ,BS,productId ,productName,preData["investoracno"].ToString() ,MatchPrice,RefRealPrice,preData["OTQTY"].ToString(),RefPL,preData["DTOVER"].ToString(),multiplecomno ,multipleBS ,footMatchPrice,MKTCOMNO,COMYM,STKPRC ,CALLPUT ,IAMT,MAMT, multipleMatchPrice1, multipleMatchPrice2 ,"",RefNowPrice,TAX,FEE,EQUITY});

                        multiplecomno = "";
                        multipleBS = "";
                        productId = "";
                        BS = "";
                        footMatchPrice = "";
                        MatchPrice = "";
                        RefRealPrice = "";
                        RefPL = "";
                        preData = null;
                        productName = "";
                        MKTCOMNO = "";
                        COMYM = "";
                        STKPRC = "";
                        CALLPUT = "";
                        IAMT = "";
                        MAMT = "";
                        RefNowPrice = "";

                        TAX = "";
                        FEE = "";
                        EQUITY = "";

                    }
                }


                pretradedate = dr["tradedate"].ToString().Trim();
                preordno = dr["ORDNO"].ToString().Trim().Substring(0, 6) + dr["ORDNO"].ToString().Trim().Substring(7, 1);

                string spreadKind = dr["spread"].ToString().Trim();

                if (dr["ORDNO"].ToString().Trim().Substring(6, 1) == "1")
                {
                    preData = dr;

                    footMatchPrice = dr["MatchPrice"].ToString();
                    productId = dr["Commodity_Id"].ToString().Trim();
                    BS = dr["BS"].ToString();


                    MKTCOMNO = dr["MKTCOMNO"].ToString();
                    COMYM = dr["COMYM"].ToString();
                    STKPRC = dr["STKPRC"].ToString();
                    CALLPUT = dr["CALLPUT"].ToString();

                    IAMT = dr["IAMT"].ToString();
                    MAMT = dr["MAMT"].ToString();

                    TAX = dr["TAX"].ToString();
                    FEE = dr["FEE"].ToString();
                    EQUITY = dr["EQUITY"].ToString();

                }
                else
                {
                    if (spreadKind == "1" || spreadKind == "2" || spreadKind == "3" || spreadKind == "4" || spreadKind == "5")
                    {
                        string[] strReturn = MultipleProductId("3", preData["Commodity_Id"].ToString().Trim(), dr["Commodity_Id"].ToString().Trim(), preData["BS"].ToString(), dr["BS"].ToString(), dr["ProductDesc"].ToString());
                        multiplecomno = strReturn[0];
                        productName = strReturn[2];
                        multipleBS = strReturn[6];

                        productId = strReturn[3] + "\n" + strReturn[4];
                        BS = strReturn[5] + "\n" + strReturn[6];


                        MKTCOMNO = strReturn[3].Substring(0, 3);
                        COMYM = strReturn[11] + "\n" + strReturn[12];
                        STKPRC = strReturn[9] + "\n" + strReturn[10];
                        CALLPUT = strReturn[7] + "\n" + strReturn[8];


                        if (dr["BS"].ToString() == strReturn[6])
                        {

                            footMatchPrice += "\n" + dr["MatchPrice"].ToString();
                            MatchPrice = getMultiplePrice(spreadKind, multipleBS, preData["BS"].ToString(), dr["BS"].ToString(), Convert.ToDecimal(preData["MatchPrice"].ToString()), Convert.ToDecimal(dr["MatchPrice"].ToString())).ToString();
                            RefRealPrice = getMultiplePrice(spreadKind, multipleBS, preData["BS"].ToString(), dr["BS"].ToString(), Convert.ToDecimal(preData["RefRealPrice"].ToString()), Convert.ToDecimal(dr["RefRealPrice"].ToString())).ToString();

                        }
                        else
                        {
                            footMatchPrice = dr["MatchPrice"] + "\n" + preData["MatchPrice"].ToString();
                            MatchPrice = getMultiplePrice(spreadKind, multipleBS, dr["BS"].ToString(), preData["BS"].ToString(), Convert.ToDecimal(dr["MatchPrice"].ToString()), Convert.ToDecimal(preData["MatchPrice"].ToString())).ToString();
                            RefRealPrice = getMultiplePrice(spreadKind, multipleBS, dr["BS"].ToString(), preData["BS"].ToString(), Convert.ToDecimal(dr["RefRealPrice"].ToString()), Convert.ToDecimal(preData["RefRealPrice"].ToString())).ToString();



                        }


                        if (multipleBS.ToString() == "B")
                        {
                            RefPL = ((decimal.Parse(RefRealPrice) - decimal.Parse(MatchPrice)) * int.Parse(dr["OTQTY"].ToString()) * decimal.Parse(dr["cntsize"].ToString())).ToString("#,##0.##");
                        }
                        else
                        {
                            RefPL = ((decimal.Parse(MatchPrice) - decimal.Parse(RefRealPrice)) * int.Parse(dr["OTQTY"].ToString()) * decimal.Parse(dr["cntsize"].ToString())).ToString("#,##0.##");
                        }
                        RefNowPrice = (decimal.Parse(MatchPrice) * int.Parse(dr["OTQTY"].ToString()) * decimal.Parse(dr["cntsize"].ToString())).ToString("#,##0.##");


                    }
                    else
                    {
                        multipleBS = dr["BS"].ToString();

                        MatchPrice = "0";
                        RefRealPrice = "0";
                        RefNowPrice = "0";
                        RefPL = "0";
                        productName = preData["productName"].ToString() + " " + dr["productName"].ToString();
                        footMatchPrice += "\n" + dr["MatchPrice"].ToString();
                        productId += "\n" + dr["Commodity_Id"].ToString().Trim();
                        BS += "\n" + dr["BS"].ToString();


                        MKTCOMNO += "\n" + dr["MKTCOMNO"].ToString();
                        COMYM += "\n" + dr["COMYM"].ToString();
                        STKPRC += "\n" + dr["STKPRC"].ToString();
                        CALLPUT += "\n" + dr["CALLPUT"].ToString();
                    }

                    IAMT = (decimal.Parse(IAMT) + decimal.Parse(dr["IAMT"].ToString())).ToString();
                    MAMT = (decimal.Parse(MAMT) + decimal.Parse(dr["MAMT"].ToString())).ToString();

                    TAX = (decimal.Parse(TAX) + decimal.Parse(dr["TAX"].ToString())).ToString();
                    FEE = (decimal.Parse(FEE) + decimal.Parse(dr["FEE"].ToString())).ToString();
                    EQUITY = (decimal.Parse(EQUITY) + decimal.Parse(dr["EQUITY"].ToString())).ToString();
                }

            }
            if (preData != null)
            {
                if (pretradedate != "" && preordno != "")
                {
                    string[] multiplrice = footMatchPrice.Split(new string[] { "\n" }, StringSplitOptions.None);
                    if (multiplrice.Length == 2)
                    {
                        multipleMatchPrice1 = multiplrice[0];
                        multipleMatchPrice2 = multiplrice[1];
                    }

                    dtDetail.Rows.Add(new object[] {preData["productKind"].ToString().Trim(), preData["currency"].ToString().Trim(),pretradedate, preData["ORDNO"].ToString().Trim() 
                        ,BS,productId,productName ,preData["investoracno"].ToString(),MatchPrice,RefRealPrice,preData["OTQTY"].ToString(),RefPL,preData["DTOVER"].ToString(),multiplecomno ,multipleBS ,footMatchPrice ,MKTCOMNO,COMYM,STKPRC ,CALLPUT ,IAMT,MAMT,multipleMatchPrice1,multipleMatchPrice2,"",RefNowPrice,TAX,FEE,EQUITY});

                }
            }
            DataView unliquidationDetail = new DataView(dtDetail);
            DataTable dtTarget = unliquidationDetail.Table.DefaultView.ToTable(true, new string[] { "BS", "productId", "currency" });

            if (dtTarget.Rows.Count != 0)
            {
                foreach (DataRow dr in dtTarget.Rows)
                {

                    int tempOTQTY = 0;
                    double tempTRDPRC1 = 0;
                    double tempCurrentBalance = 0;
                    double tempRefTotalPrice = 0;
                    double tempIAMT = 0;
                    double tempMAMT = 0;
                    double tempTAX = 0;
                    double tempFEE = 0;
                    double tempEQUITY = 0;
                    DataRow drrResult = dtSummary.NewRow();
                    string command = "BS='" + dr["BS"] + "' and productId = '" + dr["productId"] + "' and currency = '" + dr["currency"] + "' ";
                    DataRow[] rCount = dtDetail.Select(command);
                    Dictionary<int, decimal> dcFootPrice = new Dictionary<int, decimal>();
                    foreach (DataRow drr in rCount)
                    {
                        if (drr["footMatchPrice"].ToString() != "")
                        {
                            int idx = 0;
                            foreach (string foot in drr["footMatchPrice"].ToString().Split(new Char[] { }))
                            {

                                if (dcFootPrice.ContainsKey(idx))
                                {
                                    dcFootPrice[idx] += decimal.Parse(foot) * decimal.Parse(drr["OTQTY"].ToString());
                                }
                                else
                                {
                                    dcFootPrice.Add(idx, decimal.Parse(foot) * decimal.Parse(drr["OTQTY"].ToString()));
                                }
                                idx++;
                            }

                        }
                        tempOTQTY += Convert.ToInt16(drr["OTQTY"].ToString());

                        if (drr["MatchPrice"].ToString() != "")
                        {
                            tempTRDPRC1 += double.Parse(drr["MatchPrice"].ToString()) * Convert.ToInt16(drr["OTQTY"].ToString());
                        }

                        //if (drr["CurrentBalance"].ToString() == "NA")
                        if (drr["RefPL"].ToString() == "NA")
                        {
                            tempCurrentBalance += 0;
                        }
                        else
                        {
                            tempCurrentBalance += double.Parse(drr["RefPL"].ToString());   //
                        }

                        if (drr["RefRealPrice"].ToString() == "NA")
                        {
                            tempRefTotalPrice += 0;
                        }
                        else
                        {
                            tempRefTotalPrice += double.Parse(drr["RefRealPrice"].ToString());
                        }
                        if (drr["RefRealPrice"].ToString() == "NA")
                        {
                            drrResult["realprice"] = "0";
                        }
                        else
                        {
                            drrResult["realprice"] = drr["RefRealPrice"].ToString().Trim();
                        }

                        tempIAMT += double.Parse(drr["IAMT"].ToString());

                        tempMAMT += double.Parse(drr["MAMT"].ToString());
                        tempTAX += double.Parse(drr["TAX"].ToString());

                        tempFEE += double.Parse(drr["FEE"].ToString());
                        tempEQUITY += double.Parse(drr["EQUITY"].ToString());
                        drrResult["BS"] = drr["BS"].ToString().Trim();

                        drrResult["ProductId"] = drr["ProductId"].ToString().Trim();

                        drrResult["productName"] = drr["productName"].ToString().Trim();

                        drrResult["currency"] = drr["currency"].ToString().Trim();

                        drrResult["multiplecomno"] = drr["multiplecomno"].ToString().Trim();

                        drrResult["multipleBS"] = drr["multipleBS"].ToString().Trim();

                        drrResult["productKind"] = drr["productKind"].ToString().Trim();




                        drrResult["investoracno"] = drr["investoracno"].ToString();
                        drrResult["MKTCOMNO"] = drr["MKTCOMNO"].ToString().Trim();
                        drrResult["COMYM"] = drr["COMYM"].ToString().Trim();
                        drrResult["STKPRC"] = drr["STKPRC"].ToString().Trim();
                        drrResult["CALLPUT"] = drr["CALLPUT"].ToString().Trim();
                        MobDataParse obj_mob = new MobDataParse();

                        //added by philip 20100505 新增彙總複式商品組成類別
                        if ((drrResult["productKind"].ToString() == "3" | drrResult["productKind"].ToString() == "4") & drrResult["multipleBS"].ToString() != "" & drrResult["multiplecomno"].ToString() != "")
                        {
                            drrResult["MultiName"] = obj_mob.MultiProductParser(drrResult["productKind"].ToString(), drrResult["multipleBS"].ToString(), drrResult["multiplecomno"].ToString(), drrResult["BS"].ToString().Split('\n')[0].ToString().Trim())[0];
                        }
                        if ((drrResult["productKind"].ToString() == "3" | drrResult["productKind"].ToString() == "4") & drrResult["multiplecomno"].ToString() == "")
                        {
                            drrResult["MultiName"] = "0";
                            drrResult["multiplecomno"] = drrResult["productId"].ToString();
                            drrResult["multipleBS"] = drrResult["BS"].ToString();
                        }


                    }


                    drrResult["TotalOTQTY"] = tempOTQTY.ToString();


                    if (tempOTQTY == 0)
                    {

                        //added 20100414 
                        drrResult["RefTotalPrice"] = "0";
                    }
                    else
                    {
                        double TRDPRC1 = tempTRDPRC1 / tempOTQTY;
                        //added 20100326 四捨五入
                        double roundoff_TRDPRC1 = Math.Round(TRDPRC1, 2, MidpointRounding.AwayFromZero);

                        drrResult["AvgMatchPrice"] = roundoff_TRDPRC1.ToString("#,##0.##");
                        double roundoff_tempRefTotalPrice = Math.Round(tempRefTotalPrice, 2, MidpointRounding.AwayFromZero);
                        drrResult["RefTotalPrice"] = roundoff_tempRefTotalPrice.ToString("#,##0.##");

                        if (drrResult["realprice"] == System.DBNull.Value)
                        {

                            drrResult["RefTotalPL"] = "0";
                        }
                        else
                        {
                            //added 20100326 四捨五入
                            double roundoff_tempCurrentBalance = Math.Round(tempCurrentBalance, 2, MidpointRounding.AwayFromZero);

                            drrResult["RefTotalPL"] = roundoff_tempCurrentBalance.ToString("#,##0.##");


                        }
                        if (dcFootPrice.Keys.Count > 0)
                        {

                            foreach (int key in dcFootPrice.Keys)
                            {
                                if (key == 0)
                                {
                                    drrResult["footMatchPrice"] = (dcFootPrice[key] / tempOTQTY).ToString("#,##0.##");
                                }
                                else
                                {
                                    drrResult["footMatchPrice"] += "\n" + (dcFootPrice[key] / tempOTQTY).ToString("#,##0.##");
                                }
                            }
                            string[] multiplrice = drrResult["footMatchPrice"].ToString().Split(new string[] { "\n" }, StringSplitOptions.None);
                            if (multiplrice.Length == 2)
                            {
                                drrResult["multipleMatchPrice1"] = multiplrice[0];
                                drrResult["multipleMatchPrice2"] = multiplrice[1];
                            }
                        }
                    }
                    drrResult["IAMT"] = tempIAMT.ToString("#,##0.##");
                    drrResult["MAMT"] = tempMAMT.ToString("#,##0.##");
                    drrResult["TAX"] = tempTAX.ToString("#,##0.##");
                    drrResult["FEE"] = tempFEE.ToString("#,##0.##");

                    drrResult["EQUITY"] = tempEQUITY.ToString("#,##0.##");
                    //added by philip 20100505 新增彙總複式商品組成類別


                    drrResult["multiplecomno"] = drrResult["multiplecomno"].ToString();
                    drrResult["multipleBS"] = drrResult["multipleBS"].ToString();



                    dtSummary.Rows.Add(drrResult);

                }

            }

        }
        if (spread == "N" || spread == "" || spread == "A")
        {
            string spreadcondition = "";
            if (spread == "N" || spread == "")
            {
                spreadcondition = " and spread='' ";
            }
            SqlCommand = @"select 
(case when (T.comtype='F' and  isnull(T.spread,'')='') THEN '1'  when (T.comtype='O' and  isnull(T.spread,'')='') THEN '2' else '3' end )productKind
,T.spread
,T.CURRENCY
 ,T.TRDDT tradedate
 ,T.TRNNO orderNo 
 ,T.BS
 ,T.DTRADE DTOVER
   , T.TRDPRC1 MatchPrice
  , T.RealPrice  RefRealPrice
  
 , case when bs='B' then ( T.RealPrice-T.TRDPRC1) * T.OTQTY *T.cntsize 
 else (T.TRDPRC1-T.RealPrice) * T.OTQTY *T.cntsize end  RefPL 
  
  ,T.OTQTY 
  ,T.CNTSIZE
  ,  rtrim( case when T.comtype='F' then F.KIND_ID ELSE  O.KIND_ID END)
  + case when T.comtype='O' then 
 right( '00000'+rtrim(convert(char(5),cast(
  T.STKPRC*
   (case when O.STRIKE_PRICE_DECIMAL_LOCATOR=0 then 1 when  O.STRIKE_PRICE_DECIMAL_LOCATOR=1 then 10 when  O.STRIKE_PRICE_DECIMAL_LOCATOR=2 then 100 when  O.STRIKE_PRICE_DECIMAL_LOCATOR=3 then 1000 end    )
  as float))),5)
 else '' 
 end 
 +  CASE WHEN  T.CALLPUT ='P'  THEN  CHAR(76+SUBSTRING(T.comym,5,2)) ELSE   CHAR(64+SUBSTRING(T.comym,5,2)) END
 +SUBSTRING(T.comym,4,1) as ProductId 
  
  
  
 ,case when T.comtype='F' then rtrim(F.SHORT_NAME)+T.comym 
 else rtrim(O.SHORT_NAME) +convert (varchar,convert(float,STKPRC))+T.callput+substring(T.comym,5,2) 
 end ProductName
 , case when T.comtype='F' then rtrim(F.SHORT_NAME) ELSE  rtrim(O.SHORT_NAME) END  ProductDesc
 ,T.actno investoracno 
, case when T.comtype='F' then F.KIND_ID ELSE  O.KIND_ID END MKTCOMNO
 ,T.comym COMYM
 ,T.STKPRC
 
   ,CASE WHEN T.CALLPUT='' THEN 'N' ELSE T.CALLPUT END CALLPUT
 ,T.IAMT  
 ,T.MAMT  
  ,T.TAX
,T.FEE
,(T.PRTLOS-T.TAX-T.FEE)EQUITY
  , T.TRDPRC1 * T.OTQTY totalprice
  
 from 

[dbo].[FTUD] T  
left join [dbo].[P09MF] F on T.COMNO=F.commOdity
left join [dbo].[P09M] O on T.COMNO=O.commodity 
WHERE 
T.TDATE =" + strDate + " and t.FIRM='" + company + "' and t.actno='" + actno + "'   " + spreadcondition + "  " + sqlcurrency + "  and t.OTQTY >0     ";




            adp = new SqlDataAdapter(SqlCommand, conn);

            adp.Fill(dtDetail);

            SqlCommand = @" select productKind,BS,ProductId,productName,MKTCOMNO,COMYM,STKPRC,CALLPUT,currency,convert(decimal(18,4),RefRealPrice)realPrice,investoracno , convert(decimal(18,2),sum( totalprice)/sum(OTQTY)) AvgMatchPrice, sum( OTQTY)TotalOTQTY,convert(decimal(18,2), sum(RefPL))RefTotalPL ,convert(decimal(18,2),sum(iamt))iamt,convert(decimal(18,2),sum(mamt ))mamt,SUM(TAX)TAX,SUM(FEE)FEE ,sum(EQUITY)EQUITY from (" + SqlCommand + ")detail "
 + " group by productKind,BS,ProductId,ProductName,MKTCOMNO,COMYM,STKPRC,CALLPUT,currency,refrealPrice,investoracno   ";
            adp = new SqlDataAdapter(SqlCommand, conn);

            adp.Fill(dtSummary);
        }
        DataTable dt1 = new DataTable();
        foreach (DataColumn dc in dtSummary.Columns)
        {
            dt1.Columns.Add(dc.ColumnName);
        }
        DataRow[] drs1 = dtSummary.Select("", " productKind, MKTCOMNO, COMYM,CALLPUT, STKPRC");
        for (int i = 0; i < drs1.Length; i++)
        {
            DataRow drNew = dt1.NewRow();
            drNew.ItemArray = drs1[i].ItemArray;
            drNew["AvgMatchPrice"] = NumberTrim(drNew["AvgMatchPrice"].ToString());
            drNew["realPrice"] = NumberTrim(drNew["realPrice"].ToString());
            drNew["RefTotalPL"] = NumberTrim(drNew["RefTotalPL"].ToString());
            drNew["RefTotalPrice"] = NumberTrim(drNew["RefTotalPrice"].ToString());
            drNew["multipleMatchPrice1"] = NumberTrim(drNew["multipleMatchPrice1"].ToString());
            drNew["multipleMatchPrice2"] = NumberTrim(drNew["multipleMatchPrice2"].ToString());
            drNew["PriceDiff"] = NumberTrim(drNew["PriceDiff"].ToString());
            drNew["IAMT"] = NumberTrim(drNew["IAMT"].ToString());
            drNew["MAMT"] = NumberTrim(drNew["MAMT"].ToString());
            drNew["TAX"] = NumberTrim(drNew["TAX"].ToString());

            drNew["FEE"] = NumberTrim(drNew["FEE"].ToString());


            dt1.Rows.Add(drNew);
        }


        DataTable dt2 = new DataTable();
        foreach (DataColumn dc in dtDetail.Columns)
        {
            dt2.Columns.Add(dc.ColumnName);
        }
        DataRow[] drs2 = dtDetail.Select("", " productKind, MKTCOMNO, COMYM,CALLPUT, STKPRC");
        for (int i = 0; i < drs2.Length; i++)
        {
            DataRow drNew = dt2.NewRow();
            drNew.ItemArray = drs2[i].ItemArray;

            drNew["MatchPrice"] = NumberTrim(drNew["MatchPrice"].ToString());
            drNew["RefRealPrice"] = NumberTrim(drNew["RefRealPrice"].ToString());
            drNew["RefNowPrice"] = NumberTrim(drNew["RefNowPrice"].ToString());
            drNew["RefPL"] = NumberTrim(drNew["RefPL"].ToString());
            drNew["TatolMatchPrice"] = NumberTrim(drNew["TatolMatchPrice"].ToString());
            drNew["multipleMatchPrice1"] = NumberTrim(drNew["multipleMatchPrice1"].ToString());
            drNew["multipleMatchPrice2"] = NumberTrim(drNew["multipleMatchPrice2"].ToString());
            drNew["IAMT"] = NumberTrim(drNew["IAMT"].ToString());
            drNew["MAMT"] = NumberTrim(drNew["MAMT"].ToString());
            drNew["TAX"] = NumberTrim(drNew["TAX"].ToString());

            drNew["FEE"] = NumberTrim(drNew["FEE"].ToString());

            dt2.Rows.Add(drNew);
        }



        dsData.Tables.Add(dt2);
        dsData.Tables.Add(dt1);


        return dsData;
    }

    public DataTable getMargin(string company, string actno, string currency)
    {
        string strDate = "convert(char(8),getdate(),112)";
        //判斷查今天或查前天
        // if (closeday || DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_OpenTime"].ToString()))
        {
            strDate = "(select max(tdate) from dbo.FDTFM) ";
        }


        DataTable dt = new DataTable();

        DataTable dtReturn = new DataTable("Margin");
        dtReturn.Columns.Add("EXRATE").DefaultValue = "0";//匯率
        dtReturn.Columns.Add("LCTDAB").DefaultValue = "0";//昨日權益數

        dtReturn.Columns.Add("LTDAB").DefaultValue = "0";//昨日餘額 
        dtReturn.Columns.Add("DWAMT").DefaultValue = "0";//出入金

        dtReturn.Columns.Add("OSPRTLOS").DefaultValue = "0";//期貨平倉損益


        dtReturn.Columns.Add("PRTLOS").DefaultValue = "0";//期貨未平倉損益

        dtReturn.Columns.Add("OPTOSPRTLOS").DefaultValue = "0";//選擇權平倉損益

        dtReturn.Columns.Add("OPTPRTLOS").DefaultValue = "0";//選擇權未平倉損益 
        dtReturn.Columns.Add("TPREMIUM").DefaultValue = "0";//當日權利金支出收入

        dtReturn.Columns.Add("ORIGNFEE").DefaultValue = "0";//成交手續費


        dtReturn.Columns.Add("CTAXAMT").DefaultValue = "0";//成交期交稅

        dtReturn.Columns.Add("ORDPREMIUM").DefaultValue = "0";//委託預扣權利金

        dtReturn.Columns.Add("CTDAB").DefaultValue = "0";//權益數

        dtReturn.Columns.Add("ORDIAMT").DefaultValue = "0";//委託預扣原始保證金

        dtReturn.Columns.Add("IAMT").DefaultValue = "0";//原始保證金


        dtReturn.Columns.Add("MAMT").DefaultValue = "0";//維持保證金

        dtReturn.Columns.Add("ORDCEXCESS").DefaultValue = "0";//下單可用保證金

        dtReturn.Columns.Add("BPREMIUM").DefaultValue = "0";//買方權利金市值

        dtReturn.Columns.Add("SPREMIUM").DefaultValue = "0";//賣方權利金市值

        dtReturn.Columns.Add("QPTEQUITY").DefaultValue = "0";//權益總值


        dtReturn.Columns.Add("INIRATE").DefaultValue = "0";//原始比率
        dtReturn.Columns.Add("MATRATE").DefaultValue = "0";//維持比率
        dtReturn.Columns.Add("OPTRATE").DefaultValue = "0";//清算比率
        dtReturn.Columns.Add("TWDOPTEQUITY").DefaultValue = "0";//台幣權益總值

        dtReturn.Columns.Add("TWDINIRATE").DefaultValue = "0";//台幣原始比率

        dtReturn.Columns.Add("TWDORDEXCESS").DefaultValue = "0";//台幣下單可用保證金


        dtReturn.Columns.Add("SYSDATE").DefaultValue = DateTime.Now.ToString("yyyy/MM/dd"); ;//資料更新日期
        dtReturn.Columns.Add("SYSTIME").DefaultValue = DateTime.Now.ToString("HH:mm:ss");//回傳資料時間
        //-----自訂的欄位--------
        dtReturn.Columns.Add("DATA_TITLE").DefaultValue = "0";//回傳資料時間
        dtReturn.Columns.Add("AIMT").DefaultValue = "0";//追繳金額
        dtReturn.Columns.Add("TOTAL_DAMT").DefaultValue = "0";//有價證券抵繳總額.DefaultValue="0";
        dtReturn.Columns.Add("STOCKPRICE_VALUE").DefaultValue = "0";//有價證券抵繳價值.DefaultValue="0";

        dtReturn.Columns.Add("TMP1PRICE").DefaultValue = "0";// 依「加收保證金指標」所加收之保證金
        dtReturn.Columns.Add("EXCERCISEPRICE").DefaultValue = "0";//到期履約損益
        dtReturn.Columns.Add("TMP2PRICE").DefaultValue = "0";//風險指標
        dt = dtReturn.Clone();
        string error = "";
        try
        {
            getActno(ref company, ref actno);
            string sql = @"SELECT [TDATE],[MTYPE]
      ,[FIRM]
      ,[ACTNO]
      ,[TDDT]
      ,[CCY]
      ,[EXRATE]
      ,[LCTDAB]
      ,[LTDAB]
      ,[DWAMT]
      ,[OSPRTLOS]
      ,[PRTLOS]
      ,[OPTRL]
      ,[OPTPRTLOS]
      ,[TPREMIUM]
      ,[ORIGNFEE]
      ,[CTAXAMT]
      ,[ORDPREMUM]
      ,[CTDAB]
      ,[ORDIAMT]
      ,[IAMT]
      ,[MAMT]
      ,[ORDEXCESS]
      ,[BPREMIUM]
      ,[SPREMIUM]
      ,[OPTEQUITY]
      ,[INIRATE]
      ,[MATRATE]
      ,[OPTRATE]
      ,[TWDEQU]
      ,[TWDIRATE]
      ,[TWDOEX]
      ,[FU1975]
      ,[FU1974]
      ,[FU19102]
      ,[FU19103]
      ,[FU1921] 
  FROM  [dbo].[FDTFM] where [TDATE]= " + strDate + " ";
            sql += " and [FIRM] ='" + company + "' and  ACTNO='" + actno + "' and [CCY]='" + currency + "' ";


            SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);
            SqlDataAdapter adp;
            adp = new SqlDataAdapter(sql, conn);
            adp.Fill(dtReturn);

            foreach (DataRow drSource in dtReturn.Rows)
            {
                DataRow dr = dt.NewRow();

                dr["EXRATE"] = NumberTrim(drSource["EXRATE"].ToString());//匯率
                dr["LCTDAB"] = NumberTrim(drSource["LCTDAB"].ToString());//昨日權益數

                dr["LTDAB"] = NumberTrim(drSource["LTDAB"].ToString());//昨日餘額 
                dr["DWAMT"] = NumberTrim(drSource["DWAMT"].ToString());//出入金

                dr["OSPRTLOS"] = NumberTrim(drSource["OSPRTLOS"].ToString());//期貨平倉損益

                dr["PRTLOS"] = NumberTrim(drSource["PRTLOS"].ToString());//期貨未平倉損益

                dr["OPTOSPRTLOS"] = NumberTrim(drSource["OPTRL"].ToString());//選擇權平倉損益

                dr["OPTPRTLOS"] = NumberTrim(drSource["OPTPRTLOS"].ToString());//選擇權未平倉損益 
                dr["TPREMIUM"] = NumberTrim(drSource["TPREMIUM"].ToString());//當日權利金支出收入

                dr["ORIGNFEE"] = NumberTrim(drSource["ORIGNFEE"].ToString());//成交手續費

                dr["CTAXAMT"] = NumberTrim(drSource["CTAXAMT"].ToString());//成交期交稅

                dr["ORDPREMIUM"] = NumberTrim(drSource["ORDPREMIUM"].ToString());//委託預扣權利金

                dr["CTDAB"] = NumberTrim(drSource["CTDAB"].ToString());//權益數

                dr["ORDIAMT"] = NumberTrim(drSource["ORDIAMT"].ToString());//委託預扣原始保證金

                dr["IAMT"] = NumberTrim(drSource["IAMT"].ToString());//原始保證金

                dr["MAMT"] = NumberTrim(drSource["MAMT"].ToString());//維持保證金


                dr["ORDCEXCESS"] = NumberTrim(drSource["ORDEXCESS"].ToString());//下單可用保證金

                dr["BPREMIUM"] = NumberTrim(drSource["BPREMIUM"].ToString());//買方權利金市值

                dr["SPREMIUM"] = NumberTrim(drSource["SPREMIUM"].ToString());//賣方權利金市值

                dr["QPTEQUITY"] = NumberTrim(drSource["OPTEQUITY"].ToString());//權益總值

                dr["INIRATE"] = NumberTrim(drSource["INIRATE"].ToString()) + "%";//原始比率
                dr["MATRATE"] = NumberTrim(drSource["MATRATE"].ToString()) + "%";//維持比率
                dr["OPTRATE"] = NumberTrim(drSource["OPTRATE"].ToString()) + "%";//清算比率
                dr["TWDOPTEQUITY"] = NumberTrim(drSource["TWDEQU"].ToString());//台幣權益總值

                dr["TWDINIRATE"] = NumberTrim(drSource["TWDIRATE"].ToString()) + "%";//台幣原始比率
                dr["TWDORDEXCESS"] = NumberTrim(drSource["TWDOEX"].ToString());//台幣下單可用保證金

                dr["DATA_TITLE"] = "本日手續費及稅";
                //追繳金額 = 原始保證金 - 權益數  , 其結果為正才顯示
                decimal recover = Convert.ToDecimal(dr["IAMT"].ToString()) - Convert.ToDecimal(dr["CTDAB"].ToString());
                if (decimal.Parse(NumberTrim(drSource["MATRATE"].ToString())) >= 100 || decimal.Parse(NumberTrim(drSource["MATRATE"].ToString())) == 0)
                {
                    dr["AIMT"] = "無追繳金額";
                }
                else
                {
                    if (recover > 0)
                    {
                        dr["AIMT"] = recover.ToString("#,##0.##");          //追繳金額
                    }
                }
                dr["TOTAL_DAMT"] = NumberTrim(drSource["FU1975"].ToString());//有價證券抵繳總額
                dr["STOCKPRICE_VALUE"] = NumberTrim(drSource["FU1974"].ToString());//有價證券抵繳價值

                dr["TMP1PRICE"] = NumberTrim(drSource["FU19102"].ToString());//// 依「加收保證金指標」所加收之保證金

                dr["EXCERCISEPRICE"] = NumberTrim(drSource["FU1921"].ToString());// 到期履約損益
                dr["TMP2PRICE"] = NumberTrim(drSource["FU19103"].ToString());// 風險指標

                dt.Rows.Add(dr);
            }




        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[getMargin]" + ex.Message);
            throw ex;
        }

        return dt;

    }

    public DataTable getPosition(string company, string actno, string type)
    {



        string strDate = "convert(char(8),getdate(),112)";
        //判斷查今天或查前天
        // if (closeday || DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_OpenTime"].ToString()))
        {
            strDate = "(select max(tdate) from dbo.FPOS) ";
        }

        //透過type參數1表示只查單式2表示混合全部
        string spread = "";
        if (type == "1")
        {
            spread = " and  spread='N' ";
        }
        DataTable RealPart = new DataTable("CurrentPosition");

        RealPart.Columns.Add("investorAcno", typeof(string)).DefaultValue = "";    //帳號   
        RealPart.Columns.Add("ProductId", typeof(string)).DefaultValue = "";     //商品碼  
        RealPart.Columns.Add("productKind", typeof(string)).DefaultValue = "";    //商品類別 
        RealPart.Columns.Add("BS", typeof(string)).DefaultValue = "";//買賣別

        RealPart.Columns.Add("OTQtyB", typeof(string)).DefaultValue = "";    //昨日留倉買
        RealPart.Columns.Add("OTQtyS", typeof(string)).DefaultValue = "";    //昨日留倉賣
        RealPart.Columns.Add("NowOrderQtyB", typeof(string)).DefaultValue = "0";    //本日委託買

        RealPart.Columns.Add("NowOrderQtyS", typeof(string)).DefaultValue = "0";    //本日委託賣

        RealPart.Columns.Add("NowMatchQtyB", typeof(string)).DefaultValue = "0";    //目前成交買

        RealPart.Columns.Add("NowMatchQtyS", typeof(string)).DefaultValue = "0";    //目前成交賣

        RealPart.Columns.Add("TodayEnd", typeof(string)).DefaultValue = "0";    //本日了結
        RealPart.Columns.Add("LiquidationPL", typeof(decimal)).DefaultValue = "0";    //平倉損益

        RealPart.Columns["LiquidationPL"].DefaultValue = 0;
        RealPart.Columns.Add("NowOTQtyB", typeof(string)).DefaultValue = "";    //目前留倉買
        RealPart.Columns.Add("NowOTQtyS", typeof(string)).DefaultValue = "";    //目前留倉賣
        RealPart.Columns.Add("RealPrice", typeof(string)).DefaultValue = "";    //即時價位
        RealPart.Columns.Add("AvgCostB", typeof(string)).DefaultValue = "0";    //平均成本買

        RealPart.Columns.Add("AvgCostS", typeof(string)).DefaultValue = "0";    //平均成本賣

        RealPart.Columns.Add("PriceDiffB", typeof(string)).DefaultValue = "0";    //價差買

        RealPart.Columns.Add("PriceDiffS", typeof(string)).DefaultValue = "0";    //價差賣

        RealPart.Columns.Add("PricePL", typeof(string)).DefaultValue = "0";    //浮動損益
        RealPart.Columns.Add("Currency", typeof(string)).DefaultValue = "";    //幣別
        RealPart.Columns.Add("originalCost", typeof(decimal)).DefaultValue = "0";       //原始投入金額
        RealPart.Columns.Add("ROI", typeof(string)).DefaultValue = "";                 //報酬率
        RealPart.Columns.Add("productName").DefaultValue = "";
        RealPart.Columns.Add("MKTCOMNO").DefaultValue = "";
        RealPart.Columns.Add("COMYM").DefaultValue = "";
        RealPart.Columns.Add("CALLPUT").DefaultValue = "";
        RealPart.Columns.Add("STKPRC").DefaultValue = "";


        DataTable dtFBTOPD = new DataTable();


        SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);
        string sql = @"select
  T.actno investoracno 
   ,  rtrim( case when T.CALLPUT='' then F.KIND_ID ELSE  O.KIND_ID END)
  + case when T.CALLPUT='' then  '' 
   else 
 right( '00000'+rtrim(convert(char(5),cast(
  T.STKPRC*
   (case when O.STRIKE_PRICE_DECIMAL_LOCATOR=0 then 1 when  O.STRIKE_PRICE_DECIMAL_LOCATOR=1 then 10 when  O.STRIKE_PRICE_DECIMAL_LOCATOR=2 then 100 when  O.STRIKE_PRICE_DECIMAL_LOCATOR=3 then 1000 end    )
  as float))),5)

 end 
 +  CASE WHEN  T.CALLPUT ='P'  THEN  CHAR(76+SUBSTRING(T.comym,5,2)) ELSE   CHAR(64+SUBSTRING(T.comym,5,2)) END
 +SUBSTRING(T.comym,4,1) as Commodity_Id 
 
  ,case when T.CALLPUT='' then rtrim(F.SHORT_NAME)+T.comym 
 else rtrim(O.SHORT_NAME) +convert (varchar,convert(float,STKPRC))+T.callput+substring(T.comym,5,2) 
 end ProductName
 , case when T.CALLPUT='' then F.KIND_ID ELSE  O.KIND_ID END MKTCOMNO
 ,T.comym COMYM
  ,CASE WHEN T.CALLPUT='' THEN 'N' ELSE T.CALLPUT END CALLPUT
 ,T.STKPRC
 ,T.OBQTY
 ,T.OSQTY
 ,T.RBQTY
 ,T.RSQTY
 ,T.MBQTY
 ,T.MSQTY
 ,T.OFFQTY
 ,T.NBQTY
 ,T.NSQTY
 ,T.COMBQTY
 ,T.COMSQTY
 ,T.BPRICE
 ,T.SPRICE
 ,T.BIAMT
 ,T.SIAMT
 ,T.BMAMT
 ,T.SMAMT
 ,T.CNTSIZE
 ,T.REALPRICE
 ,T.TRDSPL
 ,T.CURRENCY
from
[dbo].[FPOS] T  
left join [dbo].[P09MF] F on T.COMNO=F.commOdity
left join [dbo].[P09M] O on T.COMNO=O.commodity where T.TDATE =" + strDate + " and t.FIRM='" + company + "' and t.actno='" + actno + "'   ";


        SqlDataAdapter adp;
        adp = new SqlDataAdapter(sql, conn);
        adp.Fill(dtFBTOPD);




        foreach (DataRow dr in dtFBTOPD.Rows)
        {
            DataRow drNew = RealPart.NewRow();


            drNew["investorAcno"] = actno;                                                    //帳號    

            drNew["ProductId"] = dr["Commodity_Id"].ToString().Trim();

            if (drNew["ProductId"].ToString().Length > 5)
            {

                drNew["productKind"] = "2";
            }
            else
            {
                drNew["productKind"] = "1";
            }


            drNew["productName"] = dr["ProductName"].ToString();
            drNew["MKTCOMNO"] = dr["MKTCOMNO"].ToString();
            drNew["COMYM"] = dr["COMYM"].ToString();
            drNew["CALLPUT"] = dr["CALLPUT"].ToString();
            drNew["STKPRC"] = decimal.Parse(dr["STKPRC"].ToString()).ToString("#,##0.##");

            //買賣別由目前買進留倉 目前賣出留倉判別 
            drNew["BS"] = "";
            drNew["OTQtyB"] = dr["OBQTY"].ToString();                                                  //昨日留倉買
            drNew["OTQtyS"] = dr["OSQTY"].ToString();                                                  //昨日留倉賣

            drNew["NowOrderQtyB"] = dr["RBQTY"].ToString();                                     //本日委託買
            drNew["NowOrderQtyS"] = dr["RSQTY"].ToString();                                 //本日委託賣



            drNew["NowMatchQtyB"] = dr["MBQTY"].ToString();                                       //本日MATCH買
            drNew["NowMatchQtyS"] = dr["MSQTY"].ToString();                                        //本日MATCH賣



            drNew["TodayEnd"] = dr["OFFQTY"].ToString();                                       //本日委託買
            drNew["LiquidationPL"] = dr["TRDSPL"].ToString();                                        //本日委託賣


            drNew["NowOTQtyB"] = dr["NBQTY"].ToString();                                             //目前留倉買
            drNew["NowOTQtyS"] = dr["NSQTY"].ToString();                                           //目前留倉買



            drNew["RealPrice"] = (decimal.Parse(dr["REALPRICE"].ToString())).ToString("#,##0.####");

            if (int.Parse(dr["NBQTY"].ToString()) > 0)
            {
                //平均成本買  
                drNew["AvgCostB"] = (decimal.Parse(dr["BPRICE"].ToString())).ToString("#,##0.##");
                drNew["PriceDiffB"] = (decimal.Parse(dr["REALPRICE"].ToString()) - decimal.Parse(dr["BPRICE"].ToString())).ToString("#,##0.##");                                           //價差買 

            }
            if (int.Parse(dr["NSQTY"].ToString()) > 0)
            {
                drNew["AvgCostS"] = (decimal.Parse(dr["SPRICE"].ToString())).ToString("#,##0.##");                                          //平均成本賣
                drNew["PriceDiffS"] = (decimal.Parse(dr["SPRICE"].ToString()) - decimal.Parse(dr["REALPRICE"].ToString())).ToString("#,##0.##");                                            //價差賣

            }


            decimal PricePL = decimal.Parse(drNew["PriceDiffS"].ToString()) * decimal.Parse(dr["CNTSIZE"].ToString()) * decimal.Parse(dr["NSQTY"].ToString()) + decimal.Parse(drNew["PriceDiffB"].ToString()) * decimal.Parse(dr["CNTSIZE"].ToString()) * decimal.Parse(dr["NBQTY"].ToString());


            drNew["PricePL"] = PricePL.ToString("#,##0.##");                                                 //浮動損益
            drNew["Currency"] = dr["CURRENCY"].ToString();                                                        //幣別

            //原始投入金額
            //選擇權買方 : ex. TXO買方顯示該筆均價*口數*50；
            //選擇權賣方 : ex. TXO賣方顯示該筆所需保證金；
            //期貨 : ex. 大台顯示該筆所需保證金
            decimal originalCost = 0;
            if (drNew["CALLPUT"].ToString() == "N") //future
            {
                originalCost = decimal.Parse(dr["BIAMT"].ToString()) + decimal.Parse(dr["SIAMT"].ToString());
            }
            else  // option
            {
                originalCost = decimal.Parse(drNew["AvgCostB"].ToString()) * decimal.Parse(drNew["NowOTQtyB"].ToString()) * decimal.Parse(dr["cntsize"].ToString()) + decimal.Parse(dr["SIAMT"].ToString());

            }
            drNew["originalCost"] = NumberTrim(originalCost.ToString());
            if (drNew["PricePL"].ToString() != "" && drNew["PricePL"].ToString() != "0" && ((decimal)drNew["originalCost"]) != 0)
            {
                decimal ROI = (PricePL / decimal.Parse(drNew["originalCost"].ToString())) * 100;
                drNew["ROI"] = ROI.ToString("#,##0.##") + "%";                                                    //報酬率
            }
            else
            {

                drNew["ROI"] = "0%";
            }
            RealPart.Rows.Add(drNew);
        }

        DataTable dt = new DataTable("CurrentPosition");
        foreach (DataColumn dc in RealPart.Columns)
        {
            dt.Columns.Add(dc.ColumnName);
        }
        DataRow[] drs = RealPart.Select("", " productKind, MKTCOMNO, COMYM, STKPRC,CALLPUT");
        for (int i = 0; i < drs.Length; i++)
        {
            DataRow drNew = dt.NewRow();
            drNew.ItemArray = drs[i].ItemArray;
            dt.Rows.Add(drNew);
        }
        return dt;
    }


    public DataTable getPositionSortByCP(string company, string actno, string type)
    {



        string strDate = "convert(char(8),getdate(),112)";
        //判斷查今天或查前天
        //if (closeday || DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_OpenTime"].ToString()))
        {
            strDate = "(select max(tdate) from dbo.FPOS) ";
        }

        //透過type參數1表示只查單式2表示混合全部
        string spread = "";
        if (type == "1")
        {
            spread = " and  spread='N' ";
        }
        DataTable RealPart = new DataTable("CurrentPosition");

        RealPart.Columns.Add("investorAcno", typeof(string)).DefaultValue = "";    //帳號   
        RealPart.Columns.Add("ProductId", typeof(string)).DefaultValue = "";     //商品碼  
        RealPart.Columns.Add("productKind", typeof(string)).DefaultValue = "";    //商品類別 
        RealPart.Columns.Add("BS", typeof(string)).DefaultValue = "";//買賣別

        RealPart.Columns.Add("OTQtyB", typeof(string)).DefaultValue = "";    //昨日留倉買
        RealPart.Columns.Add("OTQtyS", typeof(string)).DefaultValue = "";    //昨日留倉賣
        RealPart.Columns.Add("NowOrderQtyB", typeof(string)).DefaultValue = "0";    //本日委託買

        RealPart.Columns.Add("NowOrderQtyS", typeof(string)).DefaultValue = "0";    //本日委託賣

        RealPart.Columns.Add("NowMatchQtyB", typeof(string)).DefaultValue = "0";    //目前成交買

        RealPart.Columns.Add("NowMatchQtyS", typeof(string)).DefaultValue = "0";    //目前成交賣

        RealPart.Columns.Add("TodayEnd", typeof(string)).DefaultValue = "0";    //本日了結
        RealPart.Columns.Add("LiquidationPL", typeof(decimal)).DefaultValue = "0";    //平倉損益

        RealPart.Columns["LiquidationPL"].DefaultValue = 0;
        RealPart.Columns.Add("NowOTQtyB", typeof(string)).DefaultValue = "";    //目前留倉買
        RealPart.Columns.Add("NowOTQtyS", typeof(string)).DefaultValue = "";    //目前留倉賣
        RealPart.Columns.Add("RealPrice", typeof(string)).DefaultValue = "";    //即時價位
        RealPart.Columns.Add("AvgCostB", typeof(string)).DefaultValue = "0";    //平均成本買

        RealPart.Columns.Add("AvgCostS", typeof(string)).DefaultValue = "0";    //平均成本賣

        RealPart.Columns.Add("PriceDiffB", typeof(string)).DefaultValue = "0";    //價差買

        RealPart.Columns.Add("PriceDiffS", typeof(string)).DefaultValue = "0";    //價差賣

        RealPart.Columns.Add("PricePL", typeof(string)).DefaultValue = "0";    //浮動損益
        RealPart.Columns.Add("Currency", typeof(string)).DefaultValue = "";    //幣別
        RealPart.Columns.Add("originalCost", typeof(decimal)).DefaultValue = "0";       //原始投入金額
        RealPart.Columns.Add("ROI", typeof(string)).DefaultValue = "";                 //報酬率
        RealPart.Columns.Add("productName").DefaultValue = "";
        RealPart.Columns.Add("MKTCOMNO").DefaultValue = "";
        RealPart.Columns.Add("COMYM").DefaultValue = "";
        RealPart.Columns.Add("CALLPUT").DefaultValue = "";
        RealPart.Columns.Add("STKPRC").DefaultValue = "";


        DataTable dtFBTOPD = new DataTable();


        SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);
        string sql = @"select
  T.actno investoracno 
   ,  rtrim( case when T.CALLPUT='' then F.KIND_ID ELSE  O.KIND_ID END)
  + case when T.CALLPUT='' then  '' 
   else 
 right( '00000'+rtrim(convert(char(5),cast(
  T.STKPRC*
   (case when O.STRIKE_PRICE_DECIMAL_LOCATOR=0 then 1 when  O.STRIKE_PRICE_DECIMAL_LOCATOR=1 then 10 when  O.STRIKE_PRICE_DECIMAL_LOCATOR=2 then 100 when  O.STRIKE_PRICE_DECIMAL_LOCATOR=3 then 1000 end    )
  as float))),5)

 end 
 +  CASE WHEN  T.CALLPUT ='P'  THEN  CHAR(76+SUBSTRING(T.comym,5,2)) ELSE   CHAR(64+SUBSTRING(T.comym,5,2)) END
 +SUBSTRING(T.comym,4,1) as Commodity_Id 
 
  ,case when T.CALLPUT='' then rtrim(F.SHORT_NAME)+T.comym 
 else rtrim(O.SHORT_NAME) +convert (varchar,convert(float,STKPRC))+T.callput+substring(T.comym,5,2) 
 end ProductName
 , case when T.CALLPUT='' then F.KIND_ID ELSE  O.KIND_ID END MKTCOMNO
 ,T.comym COMYM
  ,CASE WHEN T.CALLPUT='' THEN 'N' ELSE T.CALLPUT END CALLPUT
 ,T.STKPRC
 ,T.OBQTY
 ,T.OSQTY
 ,T.RBQTY
 ,T.RSQTY
 ,T.MBQTY
 ,T.MSQTY
 ,T.OFFQTY
 ,T.NBQTY
 ,T.NSQTY
 ,T.COMBQTY
 ,T.COMSQTY
 ,T.BPRICE
 ,T.SPRICE
 ,T.BIAMT
 ,T.SIAMT
 ,T.BMAMT
 ,T.SMAMT
 ,T.CNTSIZE
 ,T.REALPRICE
 ,T.TRDSPL
 ,T.CURRENCY
from
[dbo].[FPOS] T  
left join [dbo].[P09MF] F on T.COMNO=F.commOdity
left join [dbo].[P09M] O on T.COMNO=O.commodity where T.TDATE =" + strDate + " and t.FIRM='" + company + "' and t.actno='" + actno + "'   ";


        SqlDataAdapter adp;
        adp = new SqlDataAdapter(sql, conn);
        adp.Fill(dtFBTOPD);




        foreach (DataRow dr in dtFBTOPD.Rows)
        {
            DataRow drNew = RealPart.NewRow();


            drNew["investorAcno"] = actno;                                                    //帳號    

            drNew["ProductId"] = dr["Commodity_Id"].ToString().Trim();

            if (drNew["ProductId"].ToString().Length > 5)
            {

                drNew["productKind"] = "2";
            }
            else
            {
                drNew["productKind"] = "1";
            }


            drNew["productName"] = dr["ProductName"].ToString();
            drNew["MKTCOMNO"] = dr["MKTCOMNO"].ToString();
            drNew["COMYM"] = dr["COMYM"].ToString();
            drNew["CALLPUT"] = dr["CALLPUT"].ToString();
            drNew["STKPRC"] = decimal.Parse(dr["STKPRC"].ToString()).ToString("#,##0.##");

            //買賣別由目前買進留倉 目前賣出留倉判別 
            drNew["BS"] = "";
            drNew["OTQtyB"] = dr["OBQTY"].ToString();                                                  //昨日留倉買
            drNew["OTQtyS"] = dr["OSQTY"].ToString();                                                  //昨日留倉賣

            drNew["NowOrderQtyB"] = dr["RBQTY"].ToString();                                     //本日委託買
            drNew["NowOrderQtyS"] = dr["RSQTY"].ToString();                                 //本日委託賣



            drNew["NowMatchQtyB"] = dr["MBQTY"].ToString();                                       //本日MATCH買
            drNew["NowMatchQtyS"] = dr["MSQTY"].ToString();                                        //本日MATCH賣



            drNew["TodayEnd"] = dr["OFFQTY"].ToString();                                       //本日委託買
            drNew["LiquidationPL"] = dr["TRDSPL"].ToString();                                        //本日委託賣


            drNew["NowOTQtyB"] = dr["NBQTY"].ToString();                                             //目前留倉買
            drNew["NowOTQtyS"] = dr["NSQTY"].ToString();                                           //目前留倉買



            drNew["RealPrice"] = (decimal.Parse(dr["REALPRICE"].ToString())).ToString("#,##0.####");

            if (int.Parse(dr["NBQTY"].ToString()) > 0)
            {
                //平均成本買  
                drNew["AvgCostB"] = (decimal.Parse(dr["BPRICE"].ToString())).ToString("#,##0.##");
                drNew["PriceDiffB"] = (decimal.Parse(dr["REALPRICE"].ToString()) - decimal.Parse(dr["BPRICE"].ToString())).ToString("#,##0.##");                                           //價差買 

            }
            if (int.Parse(dr["NSQTY"].ToString()) > 0)
            {
                drNew["AvgCostS"] = (decimal.Parse(dr["SPRICE"].ToString())).ToString("#,##0.##");                                          //平均成本賣
                drNew["PriceDiffS"] = (decimal.Parse(dr["SPRICE"].ToString()) - decimal.Parse(dr["REALPRICE"].ToString())).ToString("#,##0.##");                                            //價差賣

            }


            decimal PricePL = decimal.Parse(drNew["PriceDiffS"].ToString()) * decimal.Parse(dr["CNTSIZE"].ToString()) * decimal.Parse(dr["NSQTY"].ToString()) + decimal.Parse(drNew["PriceDiffB"].ToString()) * decimal.Parse(dr["CNTSIZE"].ToString()) * decimal.Parse(dr["NBQTY"].ToString());


            drNew["PricePL"] = PricePL.ToString("#,##0.##");                                                 //浮動損益
            drNew["Currency"] = dr["CURRENCY"].ToString();                                                        //幣別

            //原始投入金額
            //選擇權買方 : ex. TXO買方顯示該筆均價*口數*50；
            //選擇權賣方 : ex. TXO賣方顯示該筆所需保證金；
            //期貨 : ex. 大台顯示該筆所需保證金
            decimal originalCost = 0;
            if (drNew["CALLPUT"].ToString() == "N") //future
            {
                originalCost = decimal.Parse(dr["BIAMT"].ToString()) + decimal.Parse(dr["SIAMT"].ToString());
            }
            else  // option
            {
                originalCost = decimal.Parse(drNew["AvgCostB"].ToString()) * decimal.Parse(drNew["NowOTQtyB"].ToString()) * decimal.Parse(dr["cntsize"].ToString()) + decimal.Parse(dr["SIAMT"].ToString());

            }
            drNew["originalCost"] = NumberTrim(originalCost.ToString());
            if (drNew["PricePL"].ToString() != "" && drNew["PricePL"].ToString() != "0" && ((decimal)drNew["originalCost"]) != 0)
            {
                decimal ROI = (PricePL / decimal.Parse(drNew["originalCost"].ToString())) * 100;
                drNew["ROI"] = ROI.ToString("#,##0.##") + "%";                                                    //報酬率
            }
            else
            {

                drNew["ROI"] = "0%";
            }
            RealPart.Rows.Add(drNew);
        }

        DataTable dt = new DataTable("CurrentPosition");
        foreach (DataColumn dc in RealPart.Columns)
        {
            dt.Columns.Add(dc.ColumnName);
        }
        DataRow[] drs = RealPart.Select("", " productKind, MKTCOMNO, COMYM,CALLPUT, STKPRC");
        for (int i = 0; i < drs.Length; i++)
        {
            DataRow drNew = dt.NewRow();
            drNew.ItemArray = drs[i].ItemArray;
            dt.Rows.Add(drNew);
        }
        return dt;
    }

    private string NumberTrim(string value)
    {

        //if (value == "+nan")
        //{
        //    return "N/A";
        //}

        //modified by philip 20100326 數字四捨五入至小數第二位 
        // 將 decimal 都改成 type , 以利於轉型

        // 2010
        double dblValue = 0;
        Double.TryParse(value, out dblValue);


        // return string.Format("{0:#,#0.##}", Math.Round(dblValue, 2, MidpointRounding.AwayFromZero));
        return string.Format("{0:#,#0.####}", dblValue);



    }

    private string[] MultipleProductId(string type, string ID_1st, string ID_2nd, string bs1, string bs2, string productdesc)
    {


        string[] strReturn = new string[13];//第一個id,第二個策略
        //預設串英文
        strReturn[2] = ID_1st + "  " + ID_2nd;

        string classid = ID_1st.Substring(0, 3);
        string period1 = ID_1st.Substring(ID_1st.Length - 2, 2);
        string period2 = ID_2nd.Substring(ID_2nd.Length - 2, 2);
        int yearmonth1 = int.Parse("201" + period1.Substring(1, 1) + getOptionPeriod(period1.Substring(0, 1)).ToString().PadLeft(2, '0'));
        int yearmonth2 = int.Parse("201" + period2.Substring(1, 1) + getOptionPeriod(period2.Substring(0, 1)).ToString().PadLeft(2, '0'));

        if (type == "3")
        {

            string strikeprice1 = ID_1st.Substring(3, 5);
            string strikeprice2 = ID_2nd.Substring(3, 5);
            string cp1 = getOptionCP(period1.Substring(0, 1));
            string cp2 = getOptionCP(period2.Substring(0, 1));

            //判斷買賣別如果相同為跨式\勒式組合
            if (bs1 == bs2)
            {
                if (yearmonth1 == yearmonth2)
                {
                    if (cp1 != cp2)
                    {
                        if (cp1 == "P")
                        {
                            changeOptionFoot(ref  ID_1st, ref  ID_2nd, ref  bs1, ref  bs2, ref  period1, ref period2, ref strikeprice1, ref strikeprice2, ref cp1, ref cp2);
                        }
                        //跨式,價位相同
                        if (strikeprice1 == strikeprice2)
                        {
                            strReturn[0] = classid + strikeprice1 + period1 + ":" + period2;
                            strReturn[1] = "3";

                            strReturn[2] = productdesc + decimal.Parse(strikeprice1).ToString("#0.#") + cp1 + ":" + cp2 + getOptionPeriod(period2.Substring(0, 1));

                        }
                        else
                        {
                            //勒式
                            strReturn[0] = classid + strikeprice1 + period1 + ":" + strikeprice2 + period2;
                            strReturn[1] = "4";

                            strReturn[2] = productdesc + decimal.Parse(strikeprice1).ToString("#0.#") + cp1 + ":" + decimal.Parse(strikeprice2).ToString("#0.#") + cp2 + getOptionPeriod(period1.Substring(0, 1));
                        }
                    }
                }
            }
            else
            {
                //價格價差,價位不同
                if (strikeprice1 != strikeprice2)
                {
                    if (yearmonth1 == yearmonth2)
                    {
                        if (cp1 == cp2)
                        {


                            if ((cp1 == "C" && int.Parse(strikeprice1) < int.Parse(strikeprice2)) || (cp1 == "P" && int.Parse(strikeprice1) > int.Parse(strikeprice2)))
                            {
                                changeOptionFoot(ref  ID_1st, ref  ID_2nd, ref  bs1, ref  bs2, ref  period1, ref period2, ref strikeprice1, ref strikeprice2, ref cp1, ref cp2);
                            }


                            strReturn[0] = classid + strikeprice1 + "/" + strikeprice2 + period2;
                            strReturn[1] = "1";
                            strReturn[2] = productdesc + decimal.Parse(strikeprice1).ToString("#0.#") + "/" + decimal.Parse(strikeprice2).ToString("#0.#") + cp1 + getOptionPeriod(period2.Substring(0, 1));
                        }
                    }

                }
                else
                {
                    //判斷月份如不相同為跨月價差                    
                    if (yearmonth1 != yearmonth2)
                    {

                        if (cp1 == cp2)
                        {


                            if (yearmonth1 > yearmonth2)
                            {
                                changeOptionFoot(ref  ID_1st, ref  ID_2nd, ref  bs1, ref  bs2, ref  period1, ref period2, ref strikeprice1, ref strikeprice2, ref cp1, ref cp2);

                            }

                            strReturn[0] = classid + strikeprice1 + period1 + "/" + period2;
                            strReturn[1] = "2";
                            strReturn[2] = productdesc + decimal.Parse(strikeprice1).ToString("#0.#") + cp1 + getOptionPeriod(period1.Substring(0, 1)) + "/" + getOptionPeriod(period2.Substring(0, 1));
                        }
                    }
                    else if (yearmonth1 == yearmonth2)
                    {
                        if (cp1 != cp2)
                        {


                            if (cp1 == "P")
                            {
                                changeOptionFoot(ref  ID_1st, ref  ID_2nd, ref  bs1, ref  bs2, ref  period1, ref period2, ref strikeprice1, ref strikeprice2, ref cp1, ref cp2);

                            }
                            strReturn[0] = classid + strikeprice1 + period1 + "-" + period2;
                            strReturn[1] = "5";
                            strReturn[2] = productdesc + decimal.Parse(strikeprice1).ToString("#0.#") + cp1 + "-" + cp2 + getOptionPeriod(period1.Substring(0, 1));
                        }
                    }
                }
            }
            strReturn[7] = cp1;
            strReturn[8] = cp2;
            strReturn[9] = decimal.Parse(strikeprice1).ToString("#0.#");
            strReturn[10] = decimal.Parse(strikeprice2).ToString("#0.#");
        }
        else if (type == "4")
        {


            if (yearmonth1 != yearmonth2)
            {


                if (yearmonth1 > yearmonth2)
                {
                    changeFutureFoot(ref  ID_1st, ref  ID_2nd, ref  bs1, ref  bs2, ref  period1, ref period2);

                }

                strReturn[0] = classid + period1 + "/" + period2;
                strReturn[1] = "0";
                strReturn[2] = productdesc + getOptionPeriod(period1.Substring(0, 1)) + "/" + getOptionPeriod(period2.Substring(0, 1));
            }
        }
        strReturn[3] = ID_1st;
        strReturn[4] = ID_2nd;
        strReturn[5] = bs1;
        strReturn[6] = bs2;
        strReturn[11] = "201" + period1.Substring(1, 1) + getOptionPeriod(period1.Substring(0, 1)).ToString().PadLeft(2, '0');
        strReturn[12] = "201" + period2.Substring(1, 1) + getOptionPeriod(period2.Substring(0, 1)).ToString().PadLeft(2, '0');

        return strReturn;
    }
    public decimal getMultiplePrice(string multiplekind, string multipleId, string bs1, string bs2, decimal price1, decimal price2)
    {
        try
        {
            decimal multiplePrice = 0;
            //更新不考慮買賣別
            if ((multiplekind == "1" || multiplekind == "2" || multiplekind == "5" || multiplekind == "0") || (multiplekind == "價格價差" || multiplekind == "2" || multiplekind == "轉換/逆轉換" || multiplekind == "期貨價差"))
            {
                multiplePrice = price2 - price1;
            }
            else if ((multiplekind == "3" || multiplekind == "4") || (multiplekind == "跨式組合" || multiplekind == "勒式組合"))
            {
                multiplePrice = price1 + price2;
            }
            return multiplePrice;
        }
        catch (Exception ex)
        {
            //frmMain.AOBJ_ErrLog.WriteError(ex.Source, ex.StackTrace.ToString(), ex.Message, System.Diagnostics.EventLogEntryType.Error);
            return 0;
        }
    }
    // from 3.0.0.8
    private string getOptionCP(string period)
    {
        period = period.ToUpper();
        string[] cperiod = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L" };
        string[] pperiod = { "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X" };
        string cp = "";
        if (Array.IndexOf<string>(cperiod, period) != -1)
        {
            cp = "C";
        }
        else if (Array.IndexOf<string>(pperiod, period) != -1)
        {
            cp = "P";
        }

        return cp;
    }
    // from 3.0.0.8
    private int getOptionPeriod(string period)
    {
        period = period.ToUpper();
        string[] cperiod = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L" };
        string[] pperiod = { "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X" };
        int returnperiod = 0;
        if (Array.IndexOf<string>(cperiod, period) != -1)
        {
            returnperiod = (Array.IndexOf<string>(cperiod, period) + 1);
        }
        else if (Array.IndexOf<string>(pperiod, period) != -1)
        {
            returnperiod = (Array.IndexOf<string>(pperiod, period) + 1);
        }

        return returnperiod;
    }
    private void changeOptionFoot(ref string productid1, ref string productid2, ref string bs1, ref string bs2, ref string period1, ref string period2, ref string strikeprice1, ref string strikeprice2, ref string cp1, ref string cp2)
    {
        string tempPeriod = "";
        string tempstrikeprice = "";
        string tempcp = "";
        string tempbs = "";
        string tempproductid = "";

        tempPeriod = period1;
        tempstrikeprice = strikeprice1;
        tempcp = cp1;
        tempbs = bs1;
        tempproductid = productid1;

        period1 = period2;
        strikeprice1 = strikeprice2;
        cp1 = cp2;
        bs1 = bs2;
        productid1 = productid2;

        period2 = tempPeriod;
        strikeprice2 = tempstrikeprice;
        cp2 = tempcp;
        bs2 = tempbs;
        productid2 = tempproductid;

    }
    private void changeFutureFoot(ref string productid1, ref string productid2, ref string bs1, ref string bs2, ref string period1, ref string period2)
    {
        string tempPeriod = "";
        string tempbs = "";
        string tempproductid = "";

        tempPeriod = period1;
        tempbs = bs1;
        tempproductid = productid1;

        period1 = period2;
        bs1 = bs2;
        productid1 = productid2;


        period2 = tempPeriod;
        bs2 = tempbs;
        productid2 = tempproductid;
    }
    [WebMethod]
    public string WS_getMatchPrice(string productId)
    {
        // HttpContext.Current.Request.UserHostAddress



        string price = "";
        //判斷目前時間是否超過MOBGW啟動時間
        //並且超過小於MOBGW關閉時間,才可以查MOBGW,其餘透過DB查
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getMatchPrice]";

        // if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_OpenTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_CloseTime"].ToString()))
        if (!chkDBTime())
        {


            FunctionHandler fh = new FunctionHandler();
            string[] OriginalstrData = fh.getMOB_MatchPrice(productId);
            if (OriginalstrData != null)
            {
                if (OriginalstrData[0] == "0")
                {

                }
                else
                    price = OriginalstrData[0].Split('@')[2];
            }

        }
        else
        {

            DataTable dtData = new DataTable();
            SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["MarketInfoSqlConnectionString"].ToString());
            SqlDataAdapter adp;
            string SqlCommand = "";
            if (productId.Contains("/"))
            {
                string foot1 = productId.Substring(0, 5);
                string foot2 = productId.Substring(0, 3) + productId.Substring(6, 2);
                SqlCommand = "select closeprice,Commodity_Id from tblClosePrice where  Commodity_Id in ('" + foot1 + "','" + foot2 + "' ) order by period";

            }
            else
            {
                SqlCommand = "select closeprice,Commodity_Id from tblClosePrice where  Commodity_Id='" + productId.Trim() + "'  ";

            }
            adp = new SqlDataAdapter(SqlCommand, conn);
            adp.Fill(dtData);

            if (productId.Contains("/"))
            {
                if (dtData.Rows.Count == 2)
                {
                    string price1 = dtData.Rows[0]["closeprice"].ToString();
                    string price2 = dtData.Rows[1]["closeprice"].ToString();
                    if (price1 != "" && price2 != "")
                    {
                        price = String.Format("{0:####0.####}", (decimal.Parse(price2) - decimal.Parse(price1)));
                    }

                }
            }
            else
            {
                if (dtData.Rows.Count == 1)
                {

                    price = String.Format("{0:####0.####}", decimal.Parse(dtData.Rows[0]["closeprice"].ToString()));
                }
            }

        }
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + productId);
        return price;

    }


    [WebMethod]
    public string WS_getOrderPrice(string productId)
    {
        string price = "";
        //判斷目前時間是否超過MOBGW啟動時間
        //並且超過小於MOBGW關閉時間,才可以查MOBGW,其餘透過DB查
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getOrderPrice]";

        // if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_OpenTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_CloseTime"].ToString()))
        if (!chkDBTime())
        {


            FunctionHandler fh = new FunctionHandler();
            string[] OriginalstrData = fh.getOrderPrice(productId);
            if (OriginalstrData != null)
            {
                if (OriginalstrData[0] == "0")
                {

                }
                else
                    price = OriginalstrData[0];
            }

        }

        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + productId);
        return price;

    }
    [WebMethod]
    public System.Xml.XmlDocument WS_getMatchReply(string FIRM, string ACTNO, string comtype, string begindate, string enddate)
    {
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getMatchReply]";


        DataSet dsReturn = new DataSet("Return");
        dsReturn.Tables.Add(WS_getHistoryFBTDTR_List(FIRM, ACTNO, comtype, begindate, enddate));
        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();

        doc.InnerXml = dsReturn.GetXml();
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + FIRM + ACTNO + comtype + begindate + enddate);
        return doc;
    }
    [WebMethod]
    public System.Xml.XmlDocument WS_getOrderReply(string FIRM, string ACTNO, string comtype, string begindate, string enddate)
    {
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getOrderReply]";

        DataSet dsReturn = new DataSet("Return");
        dsReturn.Tables.Add(WS_getHistoryFOTORD_List(FIRM, ACTNO, comtype, begindate, enddate));
        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();

        doc.InnerXml = dsReturn.GetXml();
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + FIRM + ACTNO + comtype + begindate + enddate);
        return doc;
    }
    [WebMethod]
    public System.Xml.XmlDocument WS_getHistoryEquityDetail(string FIRM, string ACTNO, string begindate, string enddate, string CURRENCY)
    {
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getHistoryEquityDetail]";

        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();

        doc.InnerXml = WS_getHistoryEquity("DDSC", FIRM, ACTNO, begindate, enddate, CURRENCY)[0];
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + FIRM + ACTNO + begindate + enddate + CURRENCY);
        return doc;
    }
    [WebMethod]
    public System.Xml.XmlDocument WS_getHistoryEquityMain(string FIRM, string ACTNO, string begindate, string enddate, string currency, string comtype, string comym, string min_price, string max_price, string CP)
    {
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getHistoryEquityMain]";
        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();

        doc.InnerXml = WS_getHistoryEquityCollect("DDSC", FIRM, ACTNO, begindate, enddate, currency, comtype, comym, min_price, max_price, CP)[0];
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + FIRM + ACTNO + begindate + enddate + currency + comtype + comym + min_price + max_price + CP);
        return doc;
    }
    [WebMethod]
    public System.Xml.XmlDocument WS_getRealEquityDetail(string FIRM, string ACTNO, string CURRENCY)
    {
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getRealEquityDetail]";

        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();

        doc.InnerXml = WS_getCurrentEquity("DDSC", FIRM, ACTNO, CURRENCY)[0];
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + FIRM + ACTNO + CURRENCY);

        return doc;
    }
    [WebMethod]
    public System.Xml.XmlDocument WS_getRealEquityMain(string FIRM, string ACTNO, string currency, string comtype, string comym, string min_price, string max_price, string CP)
    {
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getRealEquityMain]";
        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();

        doc.InnerXml = WS_getCurrentEquityCollect("DDSC", FIRM, ACTNO, currency, comtype, comym, min_price, max_price, CP)[0];
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + FIRM + ACTNO + currency + comtype + comym + min_price + max_price + CP);

        return doc;
    }


    [WebMethod]
    public System.Xml.XmlDocument WS_getReal_Margin(string FIRM, string ACTNO, string CURRENCY)
    {
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getReal_Margin]";
        DataSet dsReturn = new DataSet("Return");
        try
        {

            getActno(ref FIRM, ref ACTNO);
            MobDataParse mobData = new MobDataParse();
            //判斷目前時間是否超過MOBGW啟動時間
            //並且超過小於MOBGW關閉時間,才可以查MOBGW,其餘透過DB查

            //if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_OpenTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_CloseTime"].ToString()))
            if (!chkDBTime())
            {

                FunctionHandler fh = new FunctionHandler();

                string[] OriginalstrData = fh.getMOB_CurrentMargin(ACTNO, CURRENCY, FIRM);
                if (OriginalstrData != null)
                {

                    mobData.parseMobInfoData(OriginalstrData);

                    string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
                    for (int idx = 0; idx < OriginalstrData.Length; idx++)
                    {

                    }
                }
                if (mobData.mdt_MOBCurrentMargin != null)
                {
                    mobData.mdt_MOBCurrentMargin.TableName = "Margin";
                    dsReturn.Tables.Add(mobData.mdt_MOBCurrentMargin);
                }

            }
            else
            {
                if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["Transfer_BeginTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["Transfer_EndTime"].ToString()))
                {
                    DataTable dtError = new DataTable("result");
                    dtError.Columns.Add("Error");
                    dtError.Columns.Add("ErrorCode");
                    dtError.Rows.Add(new object[] { ErrorMessage.MSG0001, "0001" });
                    dsReturn.Tables.Add(dtError);

                }
                else
                {

                    if (CURRENCY == "TWD")
                    {
                        CURRENCY = "NTT";
                    }
                    mobData.mdt_MOBCurrentMargin = getMargin(FIRM, ACTNO, CURRENCY);
                    if (mobData.mdt_MOBCurrentMargin != null)
                    {
                        mobData.mdt_MOBCurrentMargin.TableName = "Margin";
                        dsReturn.Tables.Add(mobData.mdt_MOBCurrentMargin);
                    }

                }

            }
            mobData.mdt_MOBCurrentMargin = mobData.GetMOBCurrentMarginDT(FIRM, ACTNO, CURRENCY);





        }
        catch (Exception ex)
        {

            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_getReal_Margin]" + ex.Message);
            DataTable dtError = new DataTable("result");
            dtError.Columns.Add("Error");
            dtError.Columns.Add("ErrorCode");
            dtError.Rows.Add(new object[] { "WSError:" + ex.Message, "0005" });
            dsReturn.Tables.Add(dtError);
        }
        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();

        doc.InnerXml = dsReturn.GetXml();
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + FIRM + ACTNO + CURRENCY);

        return doc;

    }
    [WebMethod]
    public System.Xml.XmlDocument WS_getReal_UnLiquidation(string FIRM, string ACTNO, string CURRENCY)
    {
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getReal_UnLiquidation]";

        FunctionHandler fh = new FunctionHandler();
        DataSet dsReturn = new DataSet("Return");

        try
        {

            getActno(ref FIRM, ref ACTNO);
            MobDataParse mobData = new MobDataParse();

            //合計
            DataTable UnLiquidationMain = null;
            //明細
            DataTable UnLiquidationDetail = null;
            //-----加入log記錄元件----
            //------------------------
            //判斷目前時間是否超過MOBGW啟動時間
            //並且超過小於MOBGW關閉時間,才可以查MOBGW,其餘透過DB查

            //  if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_OpenTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_CloseTime"].ToString()))
            if (!chkDBTime())
            {
                string[] OriginalstrData = fh.getMOB_UnLiquidation(ACTNO, FIRM, CURRENCY);
                if (OriginalstrData != null)
                {
                    mobData.parseMobInfoData(OriginalstrData);
                    string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
                    Int32 idx = 0;
                    for (idx = 0; idx < OriginalstrData.Length; idx++)
                    {

                    }
                }
                UnLiquidationMain = mobData.GetUnLiquidationMainDT();
                UnLiquidationDetail = mobData.GetUnLiquidationDetailDT();
                UnLiquidationMain.TableName = "UnLiquidationMain";
                UnLiquidationDetail.TableName = "UnLiquidationDetail";
                dsReturn.Tables.Add(UnLiquidationMain);
                dsReturn.Tables.Add(UnLiquidationDetail);
            }
            else
            {
                if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["Transfer_BeginTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["Transfer_EndTime"].ToString()))
                {
                    UnLiquidationMain = new DataTable("result");
                    UnLiquidationMain.Columns.Add("Error");
                    UnLiquidationMain.Columns.Add("ErrorCode");
                    UnLiquidationMain.Rows.Add(new object[] { ErrorMessage.MSG0001, "0001" });
                    dsReturn.Tables.Add(UnLiquidationMain);
                }
                else
                {

                    DataSet ds = getUnLiquidation(FIRM, ACTNO, "", CURRENCY);
                    UnLiquidationMain = ds.Tables[1].Copy();
                    UnLiquidationDetail = ds.Tables[0].Copy();
                    UnLiquidationMain.TableName = "UnLiquidationMain";
                    UnLiquidationDetail.TableName = "UnLiquidationDetail";
                    dsReturn.Tables.Add(UnLiquidationMain);
                    dsReturn.Tables.Add(UnLiquidationDetail);
                }
            }







        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_getReal_UnLiquidation]" + ex.Message);

            DataTable dtError = new DataTable("result");
            dtError.Columns.Add("Error");
            dtError.Columns.Add("ErrorCode");
            dtError.Rows.Add(new object[] { "WSError:" + ex.Message, "0005" });
            dsReturn.Tables.Add(dtError);
        }
        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();
        doc.InnerXml = dsReturn.GetXml();
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + FIRM + ACTNO + CURRENCY);
        return doc;
    }


    //V1.0.0.17 Added by peter on 20140616 月份(週選先), 買賣權(先CALL後PUT), 履約價(由小到大)
    [WebMethod]
    public System.Xml.XmlDocument WS_getReal_UnLiquidationSortByCP(string FIRM, string ACTNO, string currency)
    {
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getReal_UnLiquidationSortByCP]";

        FunctionHandler fh = new FunctionHandler();
        DataSet dsReturn = new DataSet("Return");

        try
        {

            getActno(ref FIRM, ref ACTNO);
            MobDataParse mobData = new MobDataParse();

            //合計
            DataTable UnLiquidationMain = null;
            //明細
            DataTable UnLiquidationDetail = null;
            //-----加入log記錄元件----
            //------------------------
            //判斷目前時間是否超過MOBGW啟動時間
            //並且超過小於MOBGW關閉時間,才可以查MOBGW,其餘透過DB查

            //if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_OpenTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_CloseTime"].ToString()))
            if (!chkDBTime())
            {
                string[] OriginalstrData = fh.getMOB_UnLiquidation(ACTNO, FIRM, currency);
                if (OriginalstrData != null)
                {
                    mobData.parseMobInfoData(OriginalstrData);
                    string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
                    Int32 idx = 0;
                    for (idx = 0; idx < OriginalstrData.Length; idx++)
                    {

                    }
                }
                UnLiquidationMain = mobData.GetUnLiquidationMainDTSortByCP();
                UnLiquidationDetail = mobData.GetUnLiquidationDetailDTSortByCP();
                UnLiquidationMain.TableName = "UnLiquidationMain";
                UnLiquidationDetail.TableName = "UnLiquidationDetail";
                dsReturn.Tables.Add(UnLiquidationMain);
                dsReturn.Tables.Add(UnLiquidationDetail);
            }
            else
            {
                if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["Transfer_BeginTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["Transfer_EndTime"].ToString()))
                {
                    UnLiquidationMain = new DataTable("result");
                    UnLiquidationMain.Columns.Add("Error");
                    UnLiquidationMain.Columns.Add("ErrorCode");
                    UnLiquidationMain.Rows.Add(new object[] { ErrorMessage.MSG0001, "0001" });
                    dsReturn.Tables.Add(UnLiquidationMain);
                }
                else
                {


                    DataSet ds = getUnLiquidationSortByCP(FIRM, ACTNO, "", currency);
                    UnLiquidationMain = ds.Tables[1].Copy();
                    UnLiquidationDetail = ds.Tables[0].Copy();
                    UnLiquidationMain.TableName = "UnLiquidationMain";
                    UnLiquidationDetail.TableName = "UnLiquidationDetail";
                    dsReturn.Tables.Add(UnLiquidationMain);
                    dsReturn.Tables.Add(UnLiquidationDetail);
                }
            }







        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_getReal_UnLiquidationSortByCP]" + ex.Message);
            DataTable dtError = new DataTable("result");
            dtError.Columns.Add("Error");
            dtError.Columns.Add("ErrorCode");
            dtError.Rows.Add(new object[] { "WSError:" + ex.Message, "0005" });
            dsReturn.Tables.Add(dtError);
        }
        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();
        doc.InnerXml = dsReturn.GetXml();
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + FIRM + ACTNO + currency);
        return doc;
    }


    [WebMethod]
    public System.Xml.XmlDocument WS_getReal_CombineUnLiquidation(string FIRM, string ACTNO, string CURRENCY)
    {
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getReal_CombineUnLiquidation]";

        FunctionHandler fh = new FunctionHandler();
        DataSet dsReturn = new DataSet("Return");

        try
        {

            getActno(ref FIRM, ref ACTNO);
            MobDataParse mobData = new MobDataParse();
            //設定為複式拆單式
            mobData.bolCombine = true;

            //合計
            DataTable UnLiquidationMain = null;
            //明細
            DataTable UnLiquidationDetail = null;
            //-----加入log記錄元件----
            //------------------------
            //判斷目前時間是否超過MOBGW啟動時間
            //並且超過小於MOBGW關閉時間,才可以查MOBGW,其餘透過DB查

            //if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_OpenTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_CloseTime"].ToString()))
            if (!chkDBTime())
            {
                string[] OriginalstrData = fh.getMOB_UnLiquidation(ACTNO, FIRM, CURRENCY);
                if (OriginalstrData != null)
                {
                    mobData.parseMobInfoData(OriginalstrData);
                    string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
                    Int32 idx = 0;
                    for (idx = 0; idx < OriginalstrData.Length; idx++)
                    {

                    }
                }
                UnLiquidationMain = mobData.GetUnLiquidationMainDT();
                UnLiquidationDetail = mobData.GetUnLiquidationDetailDT();
                UnLiquidationMain.TableName = "UnLiquidationMain";
                UnLiquidationDetail.TableName = "UnLiquidationDetail";
                dsReturn.Tables.Add(UnLiquidationMain);
                dsReturn.Tables.Add(UnLiquidationDetail);
            }
            else
            {
                if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["Transfer_BeginTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["Transfer_EndTime"].ToString()))
                {
                    UnLiquidationMain = new DataTable("result");
                    UnLiquidationMain.Columns.Add("Error");
                    UnLiquidationMain.Columns.Add("ErrorCode");
                    UnLiquidationMain.Rows.Add(new object[] { ErrorMessage.MSG0001, "0001" });
                    dsReturn.Tables.Add(UnLiquidationMain);
                }
                else
                {


                    DataSet ds = getUnLiquidation(FIRM, ACTNO, "A", CURRENCY);
                    UnLiquidationMain = ds.Tables[1].Copy();
                    UnLiquidationDetail = ds.Tables[0].Copy();
                    UnLiquidationMain.TableName = "UnLiquidationMain";
                    UnLiquidationDetail.TableName = "UnLiquidationDetail";
                    dsReturn.Tables.Add(UnLiquidationMain);
                    dsReturn.Tables.Add(UnLiquidationDetail);
                }
            }







        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_getReal_CombineUnLiquidation]" + ex.Message);
            DataTable dtError = new DataTable("result");
            dtError.Columns.Add("Error");
            dtError.Columns.Add("ErrorCode");
            dtError.Rows.Add(new object[] { "WSError:" + ex.Message, "0005" });
            dsReturn.Tables.Add(dtError);
        }
        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();
        doc.InnerXml = dsReturn.GetXml();
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + FIRM + ACTNO + CURRENCY);
        return doc;
    }

    //V1.0.0.17 Added by peter on 20140616 月份(週選先), 買賣權(先CALL後PUT), 履約價(由小到大)
    [WebMethod]
    public System.Xml.XmlDocument WS_getReal_CombineUnLiquidationSortByCP(string FIRM, string ACTNO, string currency)
    {
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getReal_CombineUnLiquidationSortByCP]";
        FunctionHandler fh = new FunctionHandler();
        DataSet dsReturn = new DataSet("Return");

        try
        {

            getActno(ref FIRM, ref ACTNO);
            MobDataParse mobData = new MobDataParse();
            //設定為複式拆單式
            mobData.bolCombine = true;

            //合計
            DataTable UnLiquidationMain = null;
            //明細
            DataTable UnLiquidationDetail = null;
            //-----加入log記錄元件----
            //------------------------
            //判斷目前時間是否超過MOBGW啟動時間
            //並且超過小於MOBGW關閉時間,才可以查MOBGW,其餘透過DB查

            //if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_OpenTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_CloseTime"].ToString()))
            if (!chkDBTime())
            {
                string[] OriginalstrData = fh.getMOB_UnLiquidation(ACTNO, FIRM, currency);
                if (OriginalstrData != null)
                {
                    mobData.parseMobInfoData(OriginalstrData);
                    string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
                    Int32 idx = 0;
                    for (idx = 0; idx < OriginalstrData.Length; idx++)
                    {

                    }
                }
                UnLiquidationMain = mobData.GetUnLiquidationMainDTSortByCP();
                UnLiquidationDetail = mobData.GetUnLiquidationDetailDTSortByCP();
                UnLiquidationMain.TableName = "UnLiquidationMain";
                UnLiquidationDetail.TableName = "UnLiquidationDetail";
                dsReturn.Tables.Add(UnLiquidationMain);
                dsReturn.Tables.Add(UnLiquidationDetail);
            }
            else
            {
                if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["Transfer_BeginTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["Transfer_EndTime"].ToString()))
                {
                    UnLiquidationMain = new DataTable("result");
                    UnLiquidationMain.Columns.Add("Error");
                    UnLiquidationMain.Columns.Add("ErrorCode");
                    UnLiquidationMain.Rows.Add(new object[] { ErrorMessage.MSG0001, "0001" });
                    dsReturn.Tables.Add(UnLiquidationMain);
                }
                else
                {


                    DataSet ds = getUnLiquidationSortByCP(FIRM, ACTNO, "A", currency);
                    UnLiquidationMain = ds.Tables[1].Copy();
                    UnLiquidationDetail = ds.Tables[0].Copy();
                    UnLiquidationMain.TableName = "UnLiquidationMain";
                    UnLiquidationDetail.TableName = "UnLiquidationDetail";
                    dsReturn.Tables.Add(UnLiquidationMain);
                    dsReturn.Tables.Add(UnLiquidationDetail);
                }
            }







        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_getReal_CombineUnLiquidationSortByCP]" + ex.Message);
            DataTable dtError = new DataTable("result");
            dtError.Columns.Add("Error");
            dtError.Columns.Add("ErrorCode");
            dtError.Rows.Add(new object[] { "WSError:" + ex.Message, "0005" });
            dsReturn.Tables.Add(dtError);
        }
        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();
        doc.InnerXml = dsReturn.GetXml();
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + FIRM + ACTNO + currency);
        return doc;
    }


    [WebMethod]
    public System.Xml.XmlDocument WS_getReal_TotalUnLiquidation(string FIRM, string ACTNO, string ACTION, string CURRENCY, string SORT)
    {
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getReal_TotalUnLiquidation]";

        FunctionHandler fh = new FunctionHandler();
        DataSet dsReturn = new DataSet("Return");
        try
        {

            getActno(ref FIRM, ref ACTNO);
            MobDataParse mobData = new MobDataParse();

            //合計
            DataTable UnLiquidationMain = null;
            //明細
            DataTable UnLiquidationDetail = null;
            //------------------------
            //判斷目前時間是否超過MOBGW啟動時間
            //並且超過小於MOBGW關閉時間,才可以查MOBGW,其餘透過DB查

            //if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_OpenTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_CloseTime"].ToString()))
            if (!chkDBTime())
            {
                string[] OriginalstrData = fh.getMOB_TotalUnLiquidation(ACTNO, FIRM, CURRENCY, ACTION);
                if (OriginalstrData != null)
                {
                    mobData.parseMobInfoData(OriginalstrData);
                    string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
                    Int32 idx = 0;
                    for (idx = 0; idx < OriginalstrData.Length; idx++)
                    {

                    }
                }
                UnLiquidationMain = mobData.GetTotalUnLiquidationMainDT(SORT);

                UnLiquidationMain.TableName = "UnLiquidationMain";

                dsReturn.Tables.Add(UnLiquidationMain);

            }
            else
            {
                if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["Transfer_BeginTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["Transfer_EndTime"].ToString()))
                {
                    UnLiquidationMain = new DataTable("result");
                    UnLiquidationMain.Columns.Add("Error");
                    UnLiquidationMain.Columns.Add("ErrorCode");
                    UnLiquidationMain.Rows.Add(new object[] { ErrorMessage.MSG0001, "0001" });
                    dsReturn.Tables.Add(UnLiquidationMain);
                }
                else
                {

                    DataSet ds;
                    if (SORT == "CP")
                    {
                        if (ACTION == "3")//混合
                            ds = getUnLiquidationSortByCP(FIRM, ACTNO, "A", CURRENCY);
                        else
                            ds = getUnLiquidationSortByCP(FIRM, ACTNO, "", CURRENCY);
                    }
                    else
                    {
                        if (ACTION == "3")//混合
                            ds = getUnLiquidation(FIRM, ACTNO, "A", CURRENCY);
                        else
                            ds = getUnLiquidation(FIRM, ACTNO, "", CURRENCY);
                    }


                    UnLiquidationMain = ds.Tables[1].Copy();
                    UnLiquidationDetail = ds.Tables[0].Copy();
                    UnLiquidationMain.TableName = "UnLiquidationMain";
                    UnLiquidationDetail.TableName = "UnLiquidationDetail";
                    dsReturn.Tables.Add(UnLiquidationMain);
                    dsReturn.Tables.Add(UnLiquidationDetail);
                }
            }







        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_getReal_TotalUnLiquidation]" + ex.Message);
            DataTable dtError = new DataTable("result");
            dtError.Columns.Add("Error");
            dtError.Columns.Add("ErrorCode");
            dtError.Rows.Add(new object[] { "WSError:" + ex.Message, "0005" });
            dsReturn.Tables.Add(dtError);
        }
        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();
        doc.InnerXml = dsReturn.GetXml();
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + FIRM + ACTNO + ACTION + CURRENCY + SORT);
        return doc;
    }



    [WebMethod]
    public System.Xml.XmlDocument WS_getReal_Position(string TYPE, string FIRM, string ACTNO)
    {

        FunctionHandler fh = new FunctionHandler();
        DataSet dsReturn = new DataSet("Return");
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getReal_Position]";

        try
        {

            getActno(ref FIRM, ref ACTNO);
            MobDataParse mobData = new MobDataParse();
            DataTable RealPart = null;
            //-----加入log記錄元件----

            //------------------------
            //判斷目前時間是否超過MOBGW啟動時間
            //並且超過小於MOBGW關閉時間,才可以查MOBGW,其餘透過DB查
            //判斷當天MOBGW是否關閉

            // if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_OpenTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_CloseTime"].ToString()))
            if (!chkDBTime())
            {
                string[] OriginalstrData = fh.getMOB_CurrentPosition(ACTNO, "1", FIRM);
                if (OriginalstrData != null)
                {
                    mobData.parseMobInfoData(OriginalstrData);
                    string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
                    Int32 idx = 0;
                    for (idx = 0; idx < OriginalstrData.Length; idx++)
                    {

                    }
                }

                RealPart = mobData.GetRealPartDT();
            }
            else
            {
                if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["Transfer_BeginTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["Transfer_EndTime"].ToString()))
                {
                    RealPart = new DataTable("result");
                    RealPart.Columns.Add("Error");
                    RealPart.Columns.Add("ErrorCode");
                    RealPart.Rows.Add(new object[] { ErrorMessage.MSG0001, "0001" });


                }
                else
                {


                    RealPart = getPosition(FIRM, ACTNO, TYPE);

                }
            }

            RealPart.TableName = "CurrentPosition";
            dsReturn.Tables.Add(RealPart);
        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_getReal_Position]" + ex.Message);
            DataTable dtError = new DataTable("result");
            dtError.Columns.Add("Error");
            dtError.Columns.Add("ErrorCode");
            dtError.Rows.Add(new object[] { "WSError:" + ex.Message, "0005" });
            dsReturn.Tables.Add(dtError);
        }

        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();
        doc.InnerXml = dsReturn.GetXml();
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + TYPE + FIRM + ACTNO);
        return doc;
    }



    [WebMethod]
    public System.Xml.XmlDocument WS_getReal_PositionSortByCP(string TYPE, string FIRM, string ACTNO)
    {
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getReal_PositionSortByCP]";
        FunctionHandler fh = new FunctionHandler();
        DataSet dsReturn = new DataSet("Return");
        try
        {

            getActno(ref FIRM, ref ACTNO);
            MobDataParse mobData = new MobDataParse();
            DataTable RealPart = null;
            //-----加入log記錄元件----
            //------------------------
            //判斷目前時間是否超過MOBGW啟動時間
            //並且超過小於MOBGW關閉時間,才可以查MOBGW,其餘透過DB查
            //判斷當天MOBGW是否關閉

            // if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_OpenTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_CloseTime"].ToString()))
            if (!chkDBTime())
            {
                string[] OriginalstrData = fh.getMOB_CurrentPosition(ACTNO, "1", FIRM);
                if (OriginalstrData != null)
                {
                    mobData.parseMobInfoData(OriginalstrData);
                    string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
                    Int32 idx = 0;
                    for (idx = 0; idx < OriginalstrData.Length; idx++)
                    {
                    }
                }

                RealPart = mobData.GetRealPartDTSortByCP();
            }
            else
            {
                if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["Transfer_BeginTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["Transfer_EndTime"].ToString()))
                {
                    RealPart = new DataTable("result");
                    RealPart.Columns.Add("Error");
                    RealPart.Columns.Add("ErrorCode");
                    RealPart.Rows.Add(new object[] { ErrorMessage.MSG0001, "0001" });


                }
                else
                {


                    RealPart = getPosition(FIRM, ACTNO, TYPE);

                }
            }
            ;
            RealPart.TableName = "CurrentPosition";
            dsReturn.Tables.Add(RealPart);
        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_getReal_PositionSortByCP]" + ex.Message);
            DataTable dtError = new DataTable("result");
            dtError.Columns.Add("Error");
            dtError.Columns.Add("ErrorCode");
            dtError.Rows.Add(new object[] { "WSError:" + ex.Message, "0005" });
            dsReturn.Tables.Add(dtError);
        }

        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();
        doc.InnerXml = dsReturn.GetXml();
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + TYPE + FIRM + ACTNO);
        return doc;
    }


    [WebMethod]
    public string[] WS_getHighLowPrice(string productId)
    {

        string[] returnprice = new string[2] { "", "" };
        //判斷目前時間是否超過MOBGW啟動時間
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getHighLowPrice]";

        if (DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["ClosePriceTransfer_EndTime"].ToString()))
        {


            FunctionHandler fh = new FunctionHandler();
            string[] OriginalstrData = fh.getMOB_HighLowPrice(productId);
            if (OriginalstrData != null)
            {

                //TXFH7@09545810@10317@10268

                if (OriginalstrData.Length > 0)
                {
                    if (OriginalstrData[0] == "0")
                    {
                        returnprice[0] = "";

                        returnprice[1] = "";
                    }
                    else
                    {
                        returnprice[0] = OriginalstrData[0].Split('@')[2];

                        returnprice[1] = OriginalstrData[0].Split('@')[3];
                    }
                }
            }
        }
        else
        {

            DataTable dtData = new DataTable();
            SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["MarketInfoSqlConnectionString"].ToString());
            SqlDataAdapter adp;
            string SqlCommand = "";

            SqlCommand = "select highprice,lowprice,showtime from tblClosePrice where  Commodity_Id='" + productId.Trim() + "'  ";

            adp = new SqlDataAdapter(SqlCommand, conn);
            adp.Fill(dtData);
            if (dtData.Rows.Count > 0)
            {
                returnprice[0] = dtData.Rows[0]["highprice"].ToString();
                returnprice[1] = dtData.Rows[0]["lowprice"].ToString();
            }

        }
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + productId);
        return returnprice;

    }

    [WebMethod]
    public System.Xml.XmlDocument WS_getReal_CurrentBalance(string FIRM, string ACTNO, string CURRENCY)
    {

        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getReal_CurrentBalance]";

        DataSet dsReturn = new DataSet("Return");
        try
        {

            getActno(ref FIRM, ref ACTNO);
            MobDataParse mobData = new MobDataParse();
            //判斷目前時間是否超過MOBGW啟動時間
            //並且超過小於MOBGW關閉時間,才可以查MOBGW,其餘透過DB查

            // if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_OpenTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_CloseTime"].ToString()))
            if (!chkDBTime())
            {

                FunctionHandler fh = new FunctionHandler();

                string[] OriginalstrData = fh.getMOB_CurrentBalance(ACTNO, CURRENCY, FIRM);
                if (OriginalstrData != null)
                {

                    mobData.parseMobInfoData(OriginalstrData);

                    string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
                    for (int idx = 0; idx < OriginalstrData.Length; idx++)
                    {

                    }
                }
                if (mobData.mdt_MOBCurrentBalance != null)
                {
                    mobData.mdt_MOBCurrentBalance.TableName = "CurrentBalance";
                    dsReturn.Tables.Add(mobData.mdt_MOBCurrentBalance);
                }

            }
            else
            {
                //mobj_T1Log.WriteEntryData("bos currency=" + CURRENCY + " Actno=" + ACTNO + " company=" + FIRM);
                //if (CURRENCY == "TWD")
                //{
                //    CURRENCY = "NTT";
                //}
                //mobData.mdt_MOBCurrentMargin = WS_getMargin(FIRM, ACTNO, CURRENCY);

                //mobj_T4Log.WriteEntryData("count" + mobData.mdt_MOBCurrentMargin.Rows.Count.ToString());
                DataTable dtError = new DataTable("result");
                dtError.Columns.Add("Error");
                dtError.Columns.Add("ErrorCode");
                dtError.Rows.Add(new object[] { ErrorMessage.MSG0006, "0008" });
                dsReturn.Tables.Add(dtError);
            }



        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_getReal_CurrentBalance]" + ex.Message);
            DataTable dtError = new DataTable("result");
            dtError.Columns.Add("Error");
            dtError.Columns.Add("ErrorCode");
            dtError.Rows.Add(new object[] { "WSError:" + ex.Message, "0005" });
            dsReturn.Tables.Add(dtError);
        }
        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();

        doc.InnerXml = dsReturn.GetXml();
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + FIRM + ACTNO + CURRENCY);
        return doc;

    }

    [WebMethod]
    public System.Xml.XmlDocument WS_getMOB_Combine(string FIRM, string ACTNO, string[] combineData)
    {

        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getMOB_Combine]";

        DataSet dsReturn = new DataSet("Return");
        try
        {
            getActno(ref FIRM, ref ACTNO);

            MobDataParse mobData = new MobDataParse();
            //判斷目前時間是否超過MOBGW啟動時間
            //並且超過小於MOBGW關閉時間,才可以查MOBGW,其餘透過DB查

            // if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_OpenTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_CloseTime"].ToString()))
            if (!chkDBTime())
            {

                FunctionHandler fh = new FunctionHandler();

                string[] OriginalstrData = fh.getMOB_Combine(ACTNO, FIRM, combineData);
                if (OriginalstrData != null)
                {

                    mobData.parseMobInfoData(OriginalstrData);

                    string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
                    for (int idx = 0; idx < OriginalstrData.Length; idx++)
                    {

                    }
                }

                DataTable MOBCombineData = mobData.GetMOBCombineDT();





                if (MOBCombineData != null)
                {
                    MOBCombineData.TableName = "CombineData";
                    dsReturn.Tables.Add(MOBCombineData);
                }

            }
            else
            {
                //mobj_T1Log.WriteEntryData("bos currency=" + CURRENCY + " Actno=" + ACTNO + " company=" + FIRM);
                //if (CURRENCY == "TWD")
                //{
                //    CURRENCY = "NTT";
                //}
                //mobData.mdt_MOBCurrentMargin = WS_getMargin(FIRM, ACTNO, CURRENCY);

                //mobj_T4Log.WriteEntryData("count" + mobData.mdt_MOBCurrentMargin.Rows.Count.ToString());
                DataTable dtError = new DataTable("result");
                dtError.Columns.Add("Error");
                dtError.Columns.Add("ErrorCode");
                dtError.Rows.Add(new object[] { ErrorMessage.MSG0006, "0004" });
                dsReturn.Tables.Add(dtError);
            }




        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_getMOB_Combine]" + ex.Message);
            DataTable dtError = new DataTable("result");
            dtError.Columns.Add("Error");
            dtError.Columns.Add("ErrorCode");
            dtError.Rows.Add(new object[] { "WSError:" + ex.Message, "0005" });
            dsReturn.Tables.Add(dtError);
        }
        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();

        doc.InnerXml = dsReturn.GetXml();
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + FIRM + ACTNO);
        return doc;

    }


    [WebMethod]
    public System.Xml.XmlDocument WS_getMOB_Net(string FIRM, string ACTNO, string[] combineData)
    {

        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getMOB_Net]";

        DataSet dsReturn = new DataSet("Return");
        try
        {
            getActno(ref FIRM, ref ACTNO);
            MobDataParse mobData = new MobDataParse();

            //判斷目前時間是否超過MOBGW啟動時間
            //並且超過小於MOBGW關閉時間,才可以查MOBGW,其餘透過DB查

            // if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_OpenTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_CloseTime"].ToString()))
            if (!chkDBTime())
            {

                FunctionHandler fh = new FunctionHandler();

                string[] OriginalstrData = fh.getMOB_Net(ACTNO, FIRM, combineData);
                if (OriginalstrData != null)
                {

                    mobData.parseMobInfoData(OriginalstrData);

                    string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
                    for (int idx = 0; idx < OriginalstrData.Length; idx++)
                    {
                    }
                }
                DataTable MOBCombineData = mobData.GetMOBCombineDT();





                if (MOBCombineData != null)
                {
                    MOBCombineData.TableName = "NetData";
                    dsReturn.Tables.Add(MOBCombineData);
                }

            }
            else
            {
                //mobj_T1Log.WriteEntryData("bos currency=" + CURRENCY + " Actno=" + ACTNO + " company=" + FIRM);
                //if (CURRENCY == "TWD")
                //{
                //    CURRENCY = "NTT";
                //}
                //mobData.mdt_MOBCurrentMargin = WS_getMargin(FIRM, ACTNO, CURRENCY);

                //mobj_T4Log.WriteEntryData("count" + mobData.mdt_MOBCurrentMargin.Rows.Count.ToString());

                DataTable dtError = new DataTable("result");
                dtError.Columns.Add("Error");
                dtError.Columns.Add("ErrorCode");
                dtError.Rows.Add(new object[] { ErrorMessage.MSG0006, "0004" });
                dsReturn.Tables.Add(dtError);
            }





        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_getMOB_Net]" + ex.Message);
            DataTable dtError = new DataTable("result");
            dtError.Columns.Add("Error");
            dtError.Columns.Add("ErrorCode");
            dtError.Rows.Add(new object[] { "WSError:" + ex.Message, "0005" });
            dsReturn.Tables.Add(dtError);
        }

        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();

        doc.InnerXml = dsReturn.GetXml();
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + FIRM + ACTNO);
        return doc;

    }



    public DataTable getBank()
    {



        DataTable RealPart = new DataTable("BANK");



        DataTable dtBANK = new DataTable();


        SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);
        string sql = @"select * from dbo.BANK  ";


        SqlDataAdapter adp;
        adp = new SqlDataAdapter(sql, conn);
        adp.Fill(dtBANK);

        dtBANK.PrimaryKey = new DataColumn[] { dtBANK.Columns["bankno"] };

        return dtBANK;
    }



    public DataTable getWITHDRAWERRORCODE()
    {



        DataTable RealPart = new DataTable("WITHDRAWERRORCODE");



        DataTable dt = new DataTable();


        SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);
        string sql = @"select * from dbo.WITHDRAWERRORCODE  ";


        SqlDataAdapter adp;
        adp = new SqlDataAdapter(sql, conn);
        adp.Fill(dt);

        dt.PrimaryKey = new DataColumn[] { dt.Columns["CODE"] };

        return dt;
    }





    [WebMethod]
    public System.Xml.XmlDocument WS_getWithdraw(string FIRM, string ACTNO, String CURRENCY, String STRDATE, String ENDDATE
        , String STRTIME, String ENDTIME)
    {

        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getWithdraw]";
        DataSet dsReturn = new DataSet("Return");
        try
        {

            getActno(ref FIRM, ref ACTNO);
            MobDataParse mobData = new MobDataParse();
            //判斷目前時間是否超過MOBGW啟動時間
            //並且超過小於MOBGW關閉時間,才可以查MOBGW,其餘透過DB查

            // if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_OpenTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_CloseTime"].ToString()))
            if (!chkDBTime())
            {

                FunctionHandler fh = new FunctionHandler();

                string[] OriginalstrData = fh.getCurrentWithdraw(FIRM, ACTNO, CURRENCY, STRDATE, ENDDATE, STRTIME, ENDTIME);
                if (OriginalstrData != null)
                {

                    mobData.parseMobInfoData(OriginalstrData);



                    string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
                    for (int idx = 0; idx < OriginalstrData.Length; idx++)
                    {

                    }
                }
                if (mobData.mdt_Withdraw != null)
                {
                    DataTable dtBank = getBank();
                    DataRow dr = null;
                    DataRow drFind = null;
                    for (int i = 0; i < mobData.mdt_Withdraw.Rows.Count; i++)
                    {
                        dr = mobData.mdt_Withdraw.Rows[i];
                        drFind = dtBank.Rows.Find(dr["BANKNO"].ToString());
                        if (drFind != null)
                            dr["BANKNAME"] = drFind["BANKNAME"].ToString();
                        else
                            dr["BANKNAME"] = "";
                    }
                    mobData.mdt_Withdraw.TableName = "Withdraw";
                    dsReturn.Tables.Add(mobData.mdt_Withdraw);
                }

            }
            else
            {
                DataTable dtError = new DataTable("result");
                dtError.Columns.Add("Error");
                dtError.Columns.Add("ErrorCode");
                dtError.Rows.Add(new object[] { ErrorMessage.MSG0006, "0004" });
                dsReturn.Tables.Add(dtError);

            }



        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_getWithdraw]" + ex.Message);
            DataTable dtError = new DataTable("result");
            dtError.Columns.Add("Error");
            dtError.Columns.Add("ErrorCode");
            dtError.Rows.Add(new object[] { "WSError:" + ex.Message, "0005" });
            dsReturn.Tables.Add(dtError);
        }
        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();

        doc.InnerXml = dsReturn.GetXml();
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + FIRM + ACTNO + CURRENCY + STRDATE + ENDDATE
+ STRTIME + ENDTIME);
        return doc;

    }



    [WebMethod]
    public System.Xml.XmlDocument WS_getHWithdraw(string FIRM, string ACTNO, String CURRENCY, String STRDATE, String ENDDATE
        , String STRTIME, String ENDTIME
       )
    {
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getHWithdraw]";

        DataSet dsReturn = new DataSet("Return");
        try
        {

            getActno(ref FIRM, ref ACTNO);
            MobDataParse mobData = new MobDataParse();
            //判斷目前時間是否超過MOBGW啟動時間
            //並且超過小於MOBGW關閉時間,才可以查MOBGW,其餘透過DB查
            DataTable dtWithdraw = new DataTable();
            //if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_OpenTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_CloseTime"].ToString()))



            SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);
            string sql = @"SELECT  [TDATE]
      ,[FIRM]
      ,[ACTNO]
      ,[BANKNO]
      ,(SELECT [BANKNAME] FROM  dbo.BANK WHERE [BANKNO]=A.[BANKNO]) BANKNAME
      ,[BANKACTNO]
      ,[TRDDT]
      ,[CODE]
	  ,CASE WHEN [CODE]='1' THEN '入金' ELSE '出金' END  CODE_NAME
      ,[CURRENCY]
      ,[AMT]
      ,[MDATE]
      ,[MTIME]
   FROM  [dbo].[FDIO] A";

            sql += @"  where  FIRM='" + FIRM + "' AND ACTNO='" + ACTNO + "'  ";

            sql += " AND (TRDDT BETWEEN '" + STRDATE + "' AND  '" + ENDDATE + "')";

            sql += " AND  CURRENCY='" + CURRENCY + "' ";


            SqlDataAdapter adp;
            adp = new SqlDataAdapter(sql, conn);
            dtWithdraw.TableName = "Withdraw";
            adp.Fill(dtWithdraw);


            dsReturn.Tables.Add(dtWithdraw);


        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_getHWithdraw]" + ex.Message);
            DataTable dtError = new DataTable("result");
            dtError.Columns.Add("Error");
            dtError.Columns.Add("ErrorCode");
            dtError.Rows.Add(new object[] { "WSError:" + ex.Message, "0005" });
            dsReturn.Tables.Add(dtError);
        }
        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();

        doc.InnerXml = dsReturn.GetXml();
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + FIRM + ACTNO + CURRENCY + STRDATE + ENDDATE
+ STRTIME + ENDTIME);
        return doc;

    }





    [WebMethod]
    public System.Xml.XmlDocument WS_CheckWithdrawPassword(string FIRM, string ACTNO, String PASSWORD, String IP)
    {
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_CheckWithdrawPassword]";

        DataSet dsReturn = new DataSet("Return");
        try
        {
            if (FIRM.Contains("585"))
            {
                if (FIRM.Substring(0, 1).ToUpper() == "S")
                {
                    FIRM = FIRM.Substring(1, FIRM.Length - 1);
                }
            }
            else
            {
                FIRM = FIRM.ToUpper().Trim();
            }
            FIRM = FIRM.Trim();

            MobDataParse mobData = new MobDataParse();
            //判斷目前時間是否超過MOBGW啟動時間
            //並且超過小於MOBGW關閉時間,才可以查MOBGW,其餘透過DB查



            FunctionHandler fh = new FunctionHandler();

            string[] OriginalstrData = fh.getOpenGWPasswordCheck(FIRM.Replace("F00", ""), ACTNO, PASSWORD, IP);
            if (OriginalstrData != null)
            {




                string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
                for (int idx = 0; idx < OriginalstrData.Length; idx++)
                {

                }
                DataTable dt = new DataTable("Password");

                byte[] returncodebyte = ASCIIEncoding.ASCII.GetBytes(OriginalstrData[0]);

                com.ddsc.net.OpenGWRecvHead raw = new com.ddsc.net.OpenGWRecvHead();
                com.ddsc.net.SocketClient.ParserStruct<com.ddsc.net.OpenGWRecvHead>.ByteArrayToStructure(returncodebyte, ref raw);

                dt.Columns.Add("msg");

                DataRow dr = dt.NewRow();
                dr["msg"] = new string(raw.ReturnCode);
                dt.Rows.Add(dr);
                dsReturn.Tables.Add(dt);
            }






        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_CheckWithdrawPassword]" + ex.Message);
            DataTable dtError = new DataTable("result");
            dtError.Columns.Add("Error");
            dtError.Columns.Add("ErrorCode");
            dtError.Rows.Add(new object[] { "WSError:" + ex.Message, "0005" });
            dsReturn.Tables.Add(dtError);
        }
        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();

        doc.InnerXml = dsReturn.GetXml();
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + FIRM + ACTNO + PASSWORD + IP);
        return doc;

    }


    [WebMethod]
    public System.Xml.XmlDocument WS_ChangePassword(string FIRM, string ACTNO, string Password, string ChangePassword)
    {
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_ChangePassword]";


        DataSet dsReturn = new DataSet("Return");
        try
        {
            if (FIRM.Contains("585"))
            {
                if (FIRM.Substring(0, 1).ToUpper() == "S")
                {
                    FIRM = FIRM.Substring(1, FIRM.Length - 1);
                }
            }
            else
            {
                FIRM = FIRM.ToUpper().Trim();
            }
            FIRM = FIRM.Trim();
            MobDataParse mobData = new MobDataParse();
            //判斷目前時間是否超過MOBGW啟動時間
            //並且超過小於MOBGW關閉時間,才可以查MOBGW,其餘透過DB查



            FunctionHandler fh = new FunctionHandler();

            string[] OriginalstrData = fh.getOpenGWChangePassword(FIRM.Replace("F00", ""), ACTNO, Password, ChangePassword);
            if (OriginalstrData != null)
            {




                string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
                for (int idx = 0; idx < OriginalstrData.Length; idx++)
                {

                }
                DataTable dt = new DataTable("Password");

                byte[] returncodebyte = ASCIIEncoding.ASCII.GetBytes(OriginalstrData[0]);

                com.ddsc.net.OpenGWRecvHead raw = new com.ddsc.net.OpenGWRecvHead();
                com.ddsc.net.SocketClient.ParserStruct<com.ddsc.net.OpenGWRecvHead>.ByteArrayToStructure(returncodebyte, ref raw);

                dt.Columns.Add("msg");

                DataRow dr = dt.NewRow();
                dr["msg"] = new string(raw.ReturnCode);
                dt.Rows.Add(dr);
                dsReturn.Tables.Add(dt);
            }



        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_ChangePassword]" + ex.Message);
            DataTable dtError = new DataTable("result");
            dtError.Columns.Add("Error");
            dtError.Columns.Add("ErrorCode");
            dtError.Rows.Add(new object[] { "WSError:" + ex.Message, "0005" });
            dsReturn.Tables.Add(dtError);
        }
        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();

        doc.InnerXml = dsReturn.GetXml();
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + FIRM + ACTNO + Password + ChangePassword);
        return doc;

    }




    [WebMethod]
    public System.Xml.XmlDocument WS_getOrderWithdraw(string MTYPE, string seqno, string TYPE, string FIRM, string ACTNO
        , String CURRENCY, String AMT, String TOCURRENCY
        , String TOMTYPE, String TOAMT, string IP)
    {

        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getOrderWithdraw]";


        /*    2.      10-12 欄位

    A.     出金 : 換匯入金幣別=空白, 入金系統=空白, 目的金額=00000000000000

    B.     互轉 :  換匯入金幣別=空白, 入金系統 = (I/O) 須不同於出金系統, 目的金額=00000000000000

    C.     換匯 : 國內無換匯作業, 所以中菲廠商過來的異動別不可為 5

    3.      17-19欄位

    A.     中菲廠商過來的都是新申請單, 都是 “N”

    B.     換匯 : 國內無換匯, 所以異動別不可為 5*/


        DataSet dsReturn = new DataSet("Return");
        try
        {

            getActno(ref FIRM, ref ACTNO);
            MobDataParse mobData = new MobDataParse();
            //判斷目前時間是否超過MOBGW啟動時間
            //並且超過小於MOBGW關閉時間,才可以查MOBGW,其餘透過DB查

            try
            {
                decimal result = 0;
                FunctionHandler fh = new FunctionHandler();
                try
                {
                    AMT = (decimal.Parse(AMT)).ToString("0");
                }
                catch
                {
                    AMT = "0";
                }
                try
                {
                    TOAMT = (decimal.Parse(TOAMT)).ToString("0");

                }
                catch
                {
                    TOAMT = "0";
                }

                string[] OriginalstrData = fh.getOrderWithdraw(MTYPE, seqno, TYPE, FIRM, ACTNO, CURRENCY, AMT, TOCURRENCY, TOMTYPE, TOAMT, "", IP, "", "", "N", "N", "N");
                if (OriginalstrData != null)
                {

                    mobData.parseMobInfoData(OriginalstrData);

                    string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
                    for (int idx = 0; idx < OriginalstrData.Length; idx++)
                    {
                    }
                }
                if (mobData.mdt_Withdraw != null)
                {
                    mobData.mdt_OrderWithdraw.TableName = "OrderWithdraw";
                    DataTable dt = getWITHDRAWERRORCODE();
                    DataRow drFind = null;
                    drFind = dt.Rows.Find(mobData.mdt_OrderWithdraw.Rows[0]["CODE"].ToString());
                    if (drFind != null)
                        mobData.mdt_OrderWithdraw.Rows[0]["CODE_NAME"] = drFind["MSG"].ToString();

                    dsReturn.Tables.Add(mobData.mdt_OrderWithdraw);
                }

            }
            catch (Exception ex)
            {
                BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_getOrderWithdraw]" + ex.Message);
                DataTable dtError = new DataTable("result");
                dtError.Columns.Add("Error");
                dtError.Columns.Add("ErrorCode");
                dtError.Rows.Add(new object[] { "WSError:" + ErrorMessage.MSG0010, "0010" });
                dsReturn.Tables.Add(dtError);

            }



        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_getOrderWithdraw]" + ex.Message);
            DataTable dtError = new DataTable("result");
            dtError.Columns.Add("Error");
            dtError.Columns.Add("ErrorCode");
            dtError.Rows.Add(new object[] { "WSError:" + ex.Message, "0005" });
            dsReturn.Tables.Add(dtError);
        }
        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();

        doc.InnerXml = dsReturn.GetXml();
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + MTYPE + seqno + TYPE + FIRM + ACTNO
+ CURRENCY + AMT + TOCURRENCY
+ TOMTYPE + TOAMT + IP);
        return doc;

    }


    [WebMethod]
    public string WS_getCASHOUTTIME(string type)
    {
        try
        {

            SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);
            string sql = @"declare  @opdate as varchar(8) 
declare  @optime as varchar(6)
declare  @twday as varchar(1)
declare @closedate as varchar(8)
declare @closetime as varchar(6)
declare @bTime  as varchar(4)
declare @eTime as varchar(4)
declare @topTime as varchar(4)
declare @type as varchar(1)
 set @type='" + type + "' " +
@"set @opdate=convert(varchar,GETDATE(),112)
 set @twday=''
set @optime=   REPLACE(CONVERT(varchar(5), GETDATE(), 108), ':', '')
 
 set @closedate= @opdate
 while(1=1)--
 begin
   SELECT  @twday=  twday  FROM [DDSCAccountDB].[dbo].[TWHOLIDAY_SET] where HOLIDAY_DATE=@closedate
	print @twday
	print @closedate
   if (@twday<>'Y'  )
   begin
   break
   end
   else
   begin
    set @twday=''
	set @closedate= CONVERT(CHAR(10),DATEADD(day,1, convert(datetime, @closedate)),112)
	end

 end 
 select @bTime=btime,@eTime=etime ,@topTime=( select top 1 etime from WITHDRAWTIME ) from WITHDRAWTIME   
     where  type  = (case when @type='3' then    '3'  else '1'   end)
 and  (cast(@optime as int )>=cast(btime as int) and cast(@optime as int)<cast(etime as int)) 
  order by seq
print @bTime+','+ @eTime+','+@topTime

if (@eTime!='9999')  
begin
	set  @closetime=@eTime
end
else if ( @closedate =@opdate)
begin

set @closedate= CONVERT(CHAR(10),DATEADD(day,1, convert(datetime, @closedate)),112)
 while(1=1)--
 begin
   SELECT  @twday=  twday  FROM [DDSCAccountDB].[dbo].[TWHOLIDAY_SET] where HOLIDAY_DATE=@closedate
 
   if (@twday<>'Y'  )
   begin
   break
   end
   else
   begin
    set @twday=''
	set @closedate= CONVERT(CHAR(10),DATEADD(day,1, convert(datetime, @closedate)),112)
	end

 end 



set  @closetime=@topTime
end
if ( @closedate!=@opdate)
begin
set  @closetime=@topTime
end
 
 select  @closedate  closedate,@closetime  closetime ,( datepart(dw,convert(datetime, @closedate ,112))-1) week

   ";

            DataTable dt = new DataTable();
            SqlDataAdapter adp;
            adp = new SqlDataAdapter(sql, conn);
            adp.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                return dt.Rows[0]["week"].ToString() + "," + dt.Rows[0]["closedate"].ToString() + dt.Rows[0]["closetime"].ToString();
            }


        }
        catch (Exception ex)
        {

        }
        return "";
    }


    [WebMethod]
    public System.Xml.XmlDocument WS_getOrderWithdrawMobile(string SignData, string Data, string IP)
    {
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getOrderWithdrawMobile]";

        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();


        DataSet dsReturn = new DataSet("Return");

        string CloseWithDrawTime = ConfigurationSettings.AppSettings["CloseWithDrawTime"].ToString();//1401~1600,1801~2000

        string[] CloseWithDrawTimes = CloseWithDrawTime.Split(',');
        int nowtime = int.Parse(DateTime.Now.ToString("HHmm"));
        bool ret = false;

        for (int i = 0; i < CloseWithDrawTimes.Length; i++)
        {
            if (int.Parse(CloseWithDrawTimes[i].Split('~')[0]) <= nowtime && int.Parse(CloseWithDrawTimes[i].Split('~')[1]) >= nowtime)
            {
                ret = true;
                break;
            }
        }



        try
        {
            if (!ret)
            {
                //手機不用驗章
                SCRYPTLib.CryptClass Crypt = null;
                try
                {
                    Crypt = new SCRYPTLib.CryptClass();
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
                int rtn = Crypt.VerifySignature(0, SignData, Data, "OU=PSCNET", 0);
                string cerid = "";
                string cerinfo = "";


                if (rtn == 0)
                {
                    cerinfo = Crypt.GetDigest();

                    cerid = Crypt.GetSerialNumber();




                }
                //else
                //{
                //    throw new Exception("驗章失敗");
                //}

                //COMPANY(7)+ACTNO(7)+TYPE(1)+AMT(14,2)+CURRENCY(3)+TOCURRENCY(3)+no(9)
                string TYPE = Data.Substring(14, 1);
                string MTYPE = (TYPE == "C") ? "O" : "I";//I: 國內 O: 國外
                string seqno = Data.Substring(35, 9);

                /*1.出金申請    2.取消
    3.國內外互轉申請        web->service     3內轉外   C外轉內
    4.出金申請(全出)
    5.換匯申請(國外期貨only)*/


                string FIRM = Data.Substring(0, 7);
                string ACTNO = Data.Substring(7, 7);
                String CURRENCY = Data.Substring(29, 3);
                String AMT = Data.Substring(15, 14);// +"." + Data.Substring(27, 2);
                String TOCURRENCY = (TYPE == "5") ? Data.Substring(32, 3) : "";
                String TOMTYPE = (TYPE == "3" || TYPE == "C") ? (TYPE == "C" ? "I" : "O") : "";
                String TOAMT = "0000000000000";
                getActno(ref FIRM, ref ACTNO);
                //判斷目前時間是否超過MOBGW啟動時間
                //並且超過小於MOBGW關閉時間,才可以查MOBGW,其餘透過DB查
                TYPE = TYPE == "C" ? "3" : TYPE;//如果室外轉內 在設定回電文TYPE
                doc = WS_getOrderWithdraw(MTYPE, seqno, TYPE, FIRM, ACTNO, CURRENCY, AMT, TOCURRENCY, TOMTYPE, TOAMT, IP);


                XmlReader Xmlreader = XmlReader.Create(new System.IO.StringReader(doc.OuterXml));
                string sss = "";
                DataSet ds = new DataSet();
                ds.ReadXml(Xmlreader);

                if (ds.Tables[0].TableName == "OrderWithdraw")
                {
                    ds.Tables[0].Columns.Remove("CODE_NAME");
                    sss = String.Concat(ds.Tables[0].Rows[0].ItemArray);


                }
                lock (_lockCaObjectFile)
                {
                    WriterLOG7 mobj_CAlog = new WriterLOG7("CA", true);
                    mobj_CAlog.WriteEntryData("[IP][" + IP + "][Data][" + Data + "][Reply][" + sss + "][SignData][" + SignData + "][cerid][" + cerid + "][returnCode][0]");
                    mobj_CAlog.Close();

                }

            }
            else
            {
                DataTable dtError = new DataTable("result");
                dtError.Columns.Add("Error");
                dtError.Columns.Add("ErrorCode");
                dtError.Rows.Add(new object[] { ErrorMessage.MSG0007, "0007" });
                dsReturn.Tables.Add(dtError);
                doc.InnerXml = dsReturn.GetXml();

            }

        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_getOrderWithdrawMobile]" + ex.Message);
            DataTable dtError = new DataTable("result");
            dtError.Columns.Add("Error");
            dtError.Columns.Add("ErrorCode");
            dtError.Rows.Add(new object[] { "WSError:" + ex.Message, "0005" });
            dsReturn.Tables.Add(dtError);
            doc.InnerXml = dsReturn.GetXml();
        }



        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + SignData + Data + IP);

        return doc;

    }




    [WebMethod]
    public System.Xml.XmlDocument WS_getOrderWithdrawCA(string SignData, string Data, string IP)
    {
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getOrderWithdrawCA]";


        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();

        DataSet dsReturn = new DataSet("Return");

        string CloseWithDrawTime = ConfigurationSettings.AppSettings["CloseWithDrawTime"].ToString();//1401~1600,1801~2000

        string[] CloseWithDrawTimes = CloseWithDrawTime.Split(',');
        int nowtime = int.Parse(DateTime.Now.ToString("HHmm"));
        bool ret = false;

        for (int i = 0; i < CloseWithDrawTimes.Length; i++)
        {
            if (int.Parse(CloseWithDrawTimes[i].Split('~')[0]) <= nowtime && int.Parse(CloseWithDrawTimes[i].Split('~')[1]) >= nowtime)
            {
                ret = true;
                break;
            }
        }


        try
        {
            if (!ret)
            {


                SCRYPTLib.CryptClass Crypt = null;
                try
                {
                    Crypt = new SCRYPTLib.CryptClass();
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message);
                }
                int rtn = Crypt.VerifySignature(0, SignData, Data, "OU=PSCNET", 0);
                string cerid = "";
                string cerinfo = "";



                if (rtn == 0)
                {
                    cerinfo = Crypt.GetDigest();

                    cerid = Crypt.GetSerialNumber();




                }
                else
                {
                    throw new Exception("驗章失敗");
                }


                //COMPANY(7)+ACTNO(7)+TYPE(1)+AMT(14,2)+CURRENCY(3)+TOCURRENCY(3)+no(9)+(20)
                string TYPE = Data.Substring(14, 1);
                string MTYPE = (TYPE == "C") ? "O" : "I";//I: 國內 O: 國外
                string seqno = Data.Substring(35, 9);

                /*1.出金申請    2.取消
    3.國內外互轉申請        web->service     3內轉外   C外轉內
    4.出金申請(全出)
    5.換匯申請(國外期貨only)*/


                string FIRM = Data.Substring(0, 7);
                string ACTNO = Data.Substring(7, 7);
                String CURRENCY = Data.Substring(29, 3);
                String AMT = Data.Substring(15, 14);// +"." + Data.Substring(27, 2);
                String TOCURRENCY = (TYPE == "5") ? Data.Substring(32, 3) : "";
                String TOMTYPE = (TYPE == "3" || TYPE == "C") ? (TYPE == "C" ? "I" : "O") : "";
                String TOAMT = "0000000000000";
                getActno(ref FIRM, ref ACTNO);
                MobDataParse mobData = new MobDataParse();
                //判斷目前時間是否超過MOBGW 
                //並且超過小於MOBGW關閉時間,才可以查MOBGW,其餘透過DB查
                TYPE = TYPE == "C" ? "3" : TYPE;//如果室外轉內 在設定回電文TYPE
                doc = WS_getOrderWithdraw(MTYPE, seqno, TYPE, FIRM, ACTNO, CURRENCY, AMT, TOCURRENCY, TOMTYPE, TOAMT, IP);

                XmlReader Xmlreader = XmlReader.Create(new System.IO.StringReader(doc.OuterXml));

                DataSet ds = new DataSet();
                string sss = "";

                ds.ReadXml(Xmlreader);
                if (ds.Tables[0].TableName == "OrderWithdraw")
                {
                    ds.Tables[0].Columns.Remove("CODE_NAME");
                    sss = String.Concat(ds.Tables[0].Rows[0].ItemArray);


                }
                lock (_lockCaObjectFile)
                {
                    WriterLOG7 mobj_CAlog = new WriterLOG7("CA", true);
                    mobj_CAlog.WriteEntryData("[IP][" + IP + "][Data][" + Data + "][Reply][" + sss + "][SignData][" + SignData + "][cerid][" + cerid + "][returnCode][" + rtn + "]");
                    mobj_CAlog.Close();

                }

            }
            else
            {
                DataTable dtError = new DataTable("result");
                dtError.Columns.Add("Error");
                dtError.Columns.Add("ErrorCode");
                dtError.Rows.Add(new object[] { ErrorMessage.MSG0007, "0007" });
                dsReturn.Tables.Add(dtError);
                doc.InnerXml = dsReturn.GetXml();

            }


        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_getOrderWithdrawCA]" + ex.Message);
            DataTable dtError = new DataTable("result");
            dtError.Columns.Add("Error");
            dtError.Columns.Add("ErrorCode");
            dtError.Rows.Add(new object[] { "WSError:" + ex.Message, "0005" });
            dsReturn.Tables.Add(dtError);
            doc.InnerXml = dsReturn.GetXml();
        }


        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + SignData + Data + IP);


        return doc;

    }



    [WebMethod]
    public System.Xml.XmlDocument WS_getOrderWithdrawFind(string FIRM, string ACTNO, String STRDATE, String ENDDATE
        , String TYPE, string CURRENCY
       )
    {

        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + "[WS_getOrderWithdrawFind]";



        DataSet dsReturn = new DataSet("Return");
        try
        {

            getActno(ref FIRM, ref ACTNO);
            MobDataParse mobData = new MobDataParse();
            //判斷目前時間是否超過MOBGW啟動時間
            //並且超過小於MOBGW關閉時間,才可以查MOBGW,其餘透過DB查
            DataTable dtWithdraw = new DataTable();
            //if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_OpenTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_CloseTime"].ToString()))
            //{

            string NowDate = DateTime.Now.ToString("yyyyMMdd");


            SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);
            string sql = @"select ORDDT,SEQNO
,MTYPE
,case when MTYPE='I' then '國內' 
	  when MTYPE='O' then '國外'  END AS MTYPE_NAME
,TYPE
,case when TYPE='1' then '出金申請' 
	  when TYPE='2' then '取消' 
	  when TYPE='3' then '國內外互轉申請' 
      when TYPE='4' then '出金申請(全出)' 
	  when TYPE='5' then '換匯申請'  
 end as TYPE_NAME
,COMPANY,ACTNO,CURRENCY,     case when TYPE='2' then CASHOUT when TYPE='4' then CASHOUT else AMT end as  AMT
,TOCURRENCY
,TOMTYPE
,case when TOMTYPE='I' then '國內' 
	  when TOMTYPE='O' then '國外'  END AS TOMTYPE_NAME
,OUTNO,INNO
,OPDATE
,OPTIME
,CloseDate
,CloseTime
,CODE
,case when  TYPE='2' and CODE='D000' THEN '取消成功' ELSE    (select MSG FROM dbo.WITHDRAWERRORCODE a where a.CODE=b.CODE) END CODE_NAME

,
case when (TYPE='1' OR  TYPE='4')and CODE='D000'
		 THEN 
		 ( 

			case when 
			(convert(    decimal(18),(CloseDate+closetime)) >convert(   decimal(18),convert(varchar,GETDATE(),112)+  REPLACE(CONVERT(varchar(5), GETDATE(), 108), ':', ''))
			) then '尚未處理'  
ELSE
		 '已經處理(結案)' END )
     when (TYPE='2' )and CODE='D000' THEN '取消成功' 

ELSE '已經處理(結案)' 

END
 REMARK
 
from ( select B.*,(convert (varchar  , getdate() ,112)+replace(convert (varchar  , getdate() ,8),':','')) nowdate
 from dbo.Withdraw B )B";

            sql += @"  where  COMPANY='" + FIRM + "' AND ACTNO='" + ACTNO + "'  ";

            sql += " AND (ORDDT BETWEEN '" + STRDATE + "' AND  '" + ENDDATE + "')";
            if (TYPE.ToUpper() != "ALL")
            {
                if (TYPE == "1")
                {
                    sql += " AND (TYPE='1' or TYPE='4'  ) ";
                }
                else
                {
                    sql += " AND TYPE='" + TYPE + "' ";
                }

            }

            if (CURRENCY.Trim().Length > 0)
            {

                sql += " AND CURRENCY ='" + CURRENCY + "'  ";



            }


            SqlDataAdapter adp;
            adp = new SqlDataAdapter(sql, conn);
            dtWithdraw.TableName = "WITHDRAW";
            adp.Fill(dtWithdraw);








            //}
            //else
            //{
            //    DataTable dtError = new DataTable("result");
            //    dtError.Columns.Add("Error");
            //    dtError.Columns.Add("ErrorCode");
            //    dtError.Rows.Add(new object[] { ErrorMessage.MSG0004, "0004" });
            //    dsReturn.Tables.Add(dtError);

            //}


            dsReturn.Tables.Add(dtWithdraw);


        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_getOrderWithdrawFind]" + ex.Message);
            DataTable dtError = new DataTable("result");
            dtError.Columns.Add("Error");
            dtError.Columns.Add("ErrorCode");
            dtError.Rows.Add(new object[] { "WSError:" + ex.Message, "0005" });
            dsReturn.Tables.Add(dtError);
        }
        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();

        doc.InnerXml = dsReturn.GetXml();
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + FIRM + ACTNO + STRDATE + ENDDATE + TYPE + CURRENCY);
        return doc;

    }




    [WebMethod]
    public System.Xml.XmlDocument WS_getIB()
    {

        DataSet dsReturn = new DataSet("Return");


        DataTable dtIB = new DataTable("IB");

        dtIB.CaseSensitive = true;




        SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);
        string sql = @" 	SELECT   [COMPANY],[BRKNAME] FROM  [AEConfigDB]. [AEConfigDB]. [dbo].[FBMITD]  where company like 'F00%'";


        SqlDataAdapter adp;
        adp = new SqlDataAdapter(sql, conn);
        adp.Fill(dtIB);

        dtIB.PrimaryKey = new DataColumn[] { dtIB.Columns["COMPANY"] };
        dsReturn.Tables.Add(dtIB);
        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();

        doc.InnerXml = dsReturn.GetXml();

        return doc;

    }




    [WebMethod]
    public System.Xml.XmlDocument WS_getWITHDRAWTIME(string type)
    {

        DataSet dsReturn = new DataSet("Return");


        DataTable dtIB = new DataTable("WITHDRAWTIME");

        dtIB.CaseSensitive = true;




        SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);
        string sql = @" select * from dbo.WITHDRAWTIME where type='" + type + "' order by seq asc  ";


        SqlDataAdapter adp;
        adp = new SqlDataAdapter(sql, conn);
        adp.Fill(dtIB);
        dsReturn.Tables.Add(dtIB);
        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();

        doc.InnerXml = dsReturn.GetXml();

        return doc;

    }

    [WebMethod]
    public System.Xml.XmlDocument WS_Holiday_Year()
    {

        DataSet dsReturn = new DataSet("Return");


        DataTable dtIB = new DataTable("HOLIDAY");

        dtIB.CaseSensitive = true;




        SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);
        string sql = @"select DISTINCT substring(HOLIDAY_DATE,1,4)Holiday_Year from TWHOLIDAY_SET   ";


        SqlDataAdapter adp;
        adp = new SqlDataAdapter(sql, conn);
        adp.Fill(dtIB);

        dtIB.PrimaryKey = new DataColumn[] { dtIB.Columns["Holiday_Year"] };
        dsReturn.Tables.Add(dtIB);
        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();

        doc.InnerXml = dsReturn.GetXml();

        return doc;

    }


    [WebMethod]
    public System.Xml.XmlDocument WS_Holiday_Year_Query(string Year)
    {

        DataSet dsReturn = new DataSet("Return");


        DataTable dtIB = new DataTable("HOLIDAY");

        dtIB.CaseSensitive = true;




        SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);
        string sql = @"  SELECT 
                CONVERT(VARCHAR(10), convert(datetime,HOLIDAY_DATE), 120)HOLIDAY_DATE,[HOLIDAY_DATE]
      ,[NOTE]
      ,[TWDAY]
                            FROM TWHOLIDAY_SET where 1=1 ";
        if (!string.IsNullOrEmpty(Year))
        {
            sql += " AND substring(HOLIDAY_DATE,1,4) = '" + Year + "' ";

        }


        SqlDataAdapter adp;
        adp = new SqlDataAdapter(sql, conn);
        adp.Fill(dtIB);

        dtIB.PrimaryKey = new DataColumn[] { dtIB.Columns["Holiday_Year"] };
        dsReturn.Tables.Add(dtIB);
        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();

        doc.InnerXml = dsReturn.GetXml();

        return doc;

    }


    [WebMethod]
    public bool WS_ChkHoliday_Year(string year)
    {
        try
        {
            DataSet dsReturn = new DataSet("Return");


            DataTable dtIB = new DataTable("HOLIDAY");

            dtIB.CaseSensitive = true;




            SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);
            string sql = @"SELECT * FROM TWHOLIDAY_SET A WHERE substring(HOLIDAY_DATE,1,4)='" + year + "'   ";


            SqlDataAdapter adp;
            adp = new SqlDataAdapter(sql, conn);
            adp.Fill(dtIB);


            if (dtIB.Rows.Count > 0)
                return true;
            else
                return false;
        }
        catch (Exception ex)
        {
            return false;
        }

    }




    [WebMethod]
    public bool WS_HolidayMaintain(List<clsTWHOLIDAY_SET> holiday)
    {

        try
        {
            bool ret = true;
            SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);
            SqlCommand sqlcmd = new SqlCommand();
            string sql = " ";
            conn.Open();
            foreach (clsTWHOLIDAY_SET item in holiday)
            {
                string date = item.HOLIDAY_DATE.Replace("-", "");
                if (item.ACTION_TYPE.Trim() == "") continue;
                else if (item.ACTION_TYPE.Trim() == "ADD")
                {
                    sql = @"   INSERT INTO [dbo].[TWHOLIDAY_SET]
           ([HOLIDAY_DATE]
           ,[NOTE]
           ,[TWDAY]
           ,[CRT_ID]
           ,[CRT_DATE]
           ,[UPD_ID]
           ,[UPD_DATE])
     VALUES
           ('" + date + @"' 
           ,''
           ,'Y'
           ,'admin'
            ,getdate()
           ,'admin'
           ,getdate()
            )";
                }
                else if (item.ACTION_TYPE.Trim() == "UPD")
                {
                    sql = @"   delete from   [dbo].[TWHOLIDAY_SET] where HOLIDAY_DATE ='" + date + "'";
                }

                sqlcmd.Connection = conn;
                sqlcmd.CommandText = sql;
                int retcode = sqlcmd.ExecuteNonQuery();
                if (retcode > 0)
                    ret &= true;
                else
                    ret &= false;

            }

            DataTable dtIB = new DataTable("HOLIDAY");





            return ret;
        }
        catch (Exception ex)
        {
            return false;
        }
    }


    [WebMethod]
    public bool WS_AddHoliday_Year(string year)
    {

        try
        {
            bool ret = true;

            DataTable dtIB = new DataTable("HOLIDAY");

            DateTime beginDay = new DateTime(int.Parse(year), 1, 1);
            DateTime endDay = new DateTime(int.Parse(year), 12, 31);

            TimeSpan ts = endDay - beginDay;


            SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);
            string sql = " ";
            conn.Open();
            SqlCommand sqlcmd = new SqlCommand();
            for (int i = 0; i < ts.Days; i++)
            {

                //累加日期
                DateTime cur_day = beginDay.AddDays(i);
                string date = cur_day.ToString("yyyyMMdd");
                //判斷為六日才新增
                if (cur_day.DayOfWeek == DayOfWeek.Saturday || cur_day.DayOfWeek == DayOfWeek.Sunday)
                {
                    sql = @"   INSERT INTO [dbo].[TWHOLIDAY_SET]
           ([HOLIDAY_DATE]
           ,[NOTE]
           ,[TWDAY]
           ,[CRT_ID]
           ,[CRT_DATE]
           ,[UPD_ID]
           ,[UPD_DATE])
     VALUES
           ('" + date + @"' 
           ,''
           ,'Y'
           ,'admin'
            ,getdate()
           ,'admin'
           ,getdate()
            )";


                    sqlcmd.Connection = conn;
                    sqlcmd.CommandText = sql;
                    int retcode = sqlcmd.ExecuteNonQuery();
                    if (retcode > 0)
                        ret &= true;
                    else
                        ret &= false;
                }
            }


            return ret;
        }
        catch (Exception ex)
        {
            return false;
        }
    }

    [WebMethod]
    public System.Xml.XmlDocument WS_getKEY(string company, string actno)
    {

        DataSet dsReturn = new DataSet("Return");


        getActno(ref company, ref actno);
        DataTable dtKEY = new DataTable("KEY");




        FunctionHandler fh = new FunctionHandler();

        SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);
        string sql = @"SELECT * FROM  [AEConfigDB]. [AEConfigDB]. [dbo].[FBMCUS]  where company='" + company + "' and actno='" + actno + "' ";


        SqlDataAdapter adp;
        adp = new SqlDataAdapter(sql, conn);
        adp.Fill(dtKEY);
        if (dtKEY.Rows.Count > 0)
            dtKEY.Rows[0]["IDNO"] = fh.fh_EncString(dtKEY.Rows[0]["IDNO"].ToString());

        dsReturn.Tables.Add(dtKEY);
        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();

        doc.InnerXml = dsReturn.GetXml();

        return doc;

    }



    [WebMethod]
    public System.Xml.XmlDocument WS_getRateForAE(string FIRM, string AENO, int RATE)
    {
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getRateForAE]";
        DataSet dsReturn = new DataSet("Return");
        try
        {


            MobDataParse mobData = new MobDataParse();
            //判斷目前時間是否超過MOBGW啟動時間
            //並且超過小於MOBGW關閉時間,才可以查MOBGW,其餘透過DB查
            DataTable dtWithdraw = new DataTable();
            //if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_OpenTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_CloseTime"].ToString()))
            //{

            try
            {

                FunctionHandler fh = new FunctionHandler();


                string[] OriginalstrData = fh.getRateForAE(FIRM, AENO, RATE);
                if (OriginalstrData != null)
                {

                    mobData.parseMobInfoData(OriginalstrData);

                    string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
                    for (int idx = 0; idx < OriginalstrData.Length; idx++)
                    {

                    }
                }
                if (mobData.mdt_RateData != null)
                {


                    dsReturn.Tables.Add(mobData.mdt_RateData);
                }

            }
            catch (Exception ex)
            {
                BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_getRateForAE]" + ex.Message);
                DataTable dtError = new DataTable("result");
                dtError.Columns.Add("Error");
                dtError.Columns.Add("ErrorCode");
                dtError.Rows.Add(new object[] { "WSError:" + ErrorMessage.MSG0010, "0010" });
                dsReturn.Tables.Add(dtError);

            }



        }
        catch (Exception ex)
        {
            DataTable dtError = new DataTable("result");
            dtError.Columns.Add("Error");
            dtError.Columns.Add("ErrorCode");
            dtError.Rows.Add(new object[] { "WSError:" + ex.Message, "0005" });
            dsReturn.Tables.Add(dtError);
        }
        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();

        doc.InnerXml = dsReturn.GetXml();
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + FIRM + AENO + RATE.ToString());
        return doc;

    }




    [WebMethod]
    public System.Xml.XmlDocument WS_getOrderWithdrawFindForMGM(string FIRM, string ACTNO, String STRDATE, String ENDDATE
        , String TYPE, string CURRENCY, string TIME, string ORDER
       )
    {

        DataSet dsReturn = new DataSet("Return");
        try
        {


            MobDataParse mobData = new MobDataParse();
            //判斷目前時間是否超過MOBGW啟動時間
            //並且超過小於MOBGW關閉時間,才可以查MOBGW,其餘透過DB查
            DataTable dtWithdraw = new DataTable();
            //if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_OpenTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_CloseTime"].ToString()))
            //{



            string NowDate = DateTime.Now.ToString("yyyyMMdd");


            SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);
            //計算前一梯次日期
            string sql = @"
 declare  @twday as varchar(1)
  declare @closedate as varchar(8)
  set @closedate= CONVERT(CHAR(10),DATEADD(day,-1, convert(datetime, GETDATE())),112)
  set @twday=''
  while(1=1)--
 begin
   SELECT  @twday=  twday  FROM [DDSCAccountDB].[dbo].[TWHOLIDAY_SET] where HOLIDAY_DATE=@closedate
	print @twday
	print @closedate
   if (@twday<>'Y'  )
   begin
   break
   end
   else
   begin
    set @twday=''
	set @closedate= CONVERT(CHAR(10),DATEADD(day,-1, convert(datetime, @closedate)),112)
	end

 end 




select ORDDT,ORDTM,SEQNO
,MTYPE
,case when MTYPE='I' then '國內' 
	  when MTYPE='O' then '國外'  END AS MTYPE_NAME
,TYPE
,case when TYPE='1' then '出金申請' 
	  when TYPE='2' then '取消' 
	  when TYPE='3' then (case when MTYPE='I' then  '國內轉國外' else '國外轉國內' end )
      when TYPE='4' then '出金申請(全出)' 
	  when TYPE='5' then '換匯申請'  
 end as TYPE_NAME
,COMPANY,ACTNO,CURRENCY,    case when TYPE='2' then CASHOUT when TYPE='4' then CASHOUT else AMT end as  AMT
,TOCURRENCY
,TOMTYPE
,case when TOMTYPE='I' then '國內' 
	  when TOMTYPE='O' then '國外'  END AS TOMTYPE_NAME
,OUTNO,INNO
,CloseDate
,CloseTime
,CODE
,case when  TYPE='2' and CODE='D000' THEN '取消成功' ELSE    (select MSG FROM dbo.WITHDRAWERRORCODE a where a.CODE=b.CODE) END CODE_NAME

,
case when (TYPE='1' OR  TYPE='4')and CODE='D000'
		 THEN 
		 ( 


			case when 
			(convert(    decimal(18),(CloseDate+closetime)) >convert(   decimal(18),convert(varchar,GETDATE(),112)+  REPLACE(CONVERT(varchar(5), GETDATE(), 108), ':', ''))
			) then '尚未處理'  


ELSE
		 '已經處理(結案)' END )
     when (TYPE='2' )and CODE='D000' THEN '取消成功' 

ELSE '已經處理(結案)' 

END
 REMARK
 ,ACTNAME
from ( select a.actname,B.*,(convert (varchar  , getdate() ,112)+replace(convert (varchar  , getdate() ,8),':','')) nowdate
 from dbo.Withdraw B  left join  [AEConfigDB]. [AEConfigDB].dbo.FBMCUS a on a.COMPANY=b.company and a.ACTNO=b.actno  )B";

            sql += @"  where  ";

            if (FIRM.Trim() == "ALL")
            {
                sql += " 1=1 ";
            }
            else
            {
                if (FIRM.Contains("585"))
                {
                    sql += "  COMPANY in (select FBROKER from  [DDSCAccountDB].[dbo].[FBMMAP] WHERE BROKER='" + FIRM + "' ) ";
                }
                else
                    sql += "   COMPANY='" + FIRM + "'  ";
            }

            if (ACTNO.Trim().Length > 0)
            {
                sql += " AND ACTNO='" + ACTNO + "'  ";
            }



            //else
            //{
            //    sql += " and  OPDATE=CONVERT(varchar ,GETDATE(),112) ";

            //    sql += timesql;
            //}
            string TYPE_SQL = "";
            if (TYPE.ToUpper() != "ALL")
            {

                if (TYPE == "1")
                {
                    sql += " AND (TYPE='1' or TYPE='4' or TYPE='2' ) ";
                }
                else
                {
                    TYPE_SQL = TYPE == "33" ? "3" : TYPE; //當國外轉國內時，Type為3
                    sql += " AND TYPE='" + TYPE_SQL + "' ";

                }
            }
            if (TYPE == "3")
            {
                sql += " AND MTYPE='I' ";
            }
            if (TYPE == "33")
            {
                sql += " AND MTYPE='O' ";
            }

            if (TIME.Trim().Length > 0)
            {




                if (TIME != "9999")//9999代表為次日邏輯
                {

                    sql += " AND (closedate=convert (varchar  , getdate() ,112)  AND closetime='" + TIME + "' )  ";
                }
                else
                {

                    sql += " AND closedate>convert (varchar  , getdate() ,112) ";

                }
            }
            else
            {
                if (STRDATE.Length > 0 && ENDDATE.Length > 0)
                {

                    sql += " AND (ORDDT BETWEEN '" + STRDATE + "' AND  '" + ENDDATE + "')";
                }
            }


            if (CURRENCY.Trim().Length > 0)
            {

                sql += " AND CURRENCY ='" + CURRENCY + "'  ";



            }


            switch (ORDER.Substring(0, 1))
            {
                case "0":
                    sql += " order by SEQNO {0}";
                    break;
                case "1":
                    sql += " order by outno {0}";
                    break;
                case "2":
                    sql += " order by COMPANY {0}";
                    break;
                case "3":
                    sql += " order by AMT  {0}";
                    break;
                case "4":
                    sql += " order by ORDDT {0}";
                    break;
                case "5":
                    sql += " order by (OPDATE+OPTIME) {0}";
                    break;
                case "6":
                    sql += " order by CODE_NAME {0}";
                    break;
                case "7":
                    sql += " order by (COMPANY+ACTNO) {0},(OPDATE+OPTIME) {0}";
                    break;
                case "8":
                    sql += " order by TYPE {0}";
                    break;
            }
            switch (ORDER.Substring(1, 1))
            {
                case "0":
                    sql = string.Format(sql, "ASC");
                    break;
                case "1":
                    sql = string.Format(sql, "DESC");

                    break;
            }

            //ORDER X Y
            /*
            X
            0原始單號
            1存提單號
            2分行別
            3金額
            4申請日
            5處理日
            6狀態別
            Y
            0升冪
            1降冪*/

            SqlDataAdapter adp;
            adp = new SqlDataAdapter(sql, conn);
            dtWithdraw.TableName = "WITHDRAW";
            adp.Fill(dtWithdraw);




            //}
            //else
            //{
            //    DataTable dtError = new DataTable("result");
            //    dtError.Columns.Add("Error");
            //    dtError.Columns.Add("ErrorCode");
            //    dtError.Rows.Add(new object[] { ErrorMessage.MSG0004, "0004" });
            //    dsReturn.Tables.Add(dtError);

            //}


            dsReturn.Tables.Add(dtWithdraw);


        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_getOrderWithdrawFindForMGM]" + ex.Message);
            DataTable dtError = new DataTable("result");
            dtError.Columns.Add("Error");
            dtError.Columns.Add("ErrorCode");
            dtError.Rows.Add(new object[] { "WSError:" + ex.Message, "0005" });
            dsReturn.Tables.Add(dtError);
        }
        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();

        doc.InnerXml = dsReturn.GetXml();

        return doc;

    }






    public void getActno(ref string firm, ref string actno)
    {
        if (firm.Contains("S585"))
        {

            DataTable dtData = new DataTable();
            SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["SQLConnection3"].ToString());
            SqlDataAdapter adp;
            string SqlCommand = "";

            SqlCommand = "select factno ,fbroker from fbmmap where broker='" + firm + "' and tactno='" + actno + "' ";

            adp = new SqlDataAdapter(SqlCommand, conn);
            adp.Fill(dtData);
            if (dtData.Rows.Count > 0)
            {
                actno = dtData.Rows[0]["factno"].ToString();
                firm = dtData.Rows[0]["fbroker"].ToString();
            }
            else
                firm = "F008000";
        }



    }
    [WebMethod]
    public string[] WS_getInfoByProducts(string productstring)
    {
        string[] returnprice = new string[productstring.Split(',').Length];

        //判斷目前時間是否超過MOBGW啟動時間

        if (DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["ClosePriceTransfer_EndTime"].ToString()))
        {
            FunctionHandler fh = new FunctionHandler();


            for (int i = 0; i < returnprice.Length; i++)
            {
                string[] HighLowPrice;
                string matchprice;

                matchprice = WS_getMatchPrice(productstring.Split(',')[i]);
                HighLowPrice = WS_getHighLowPrice(productstring.Split(',')[i]);
                returnprice[i] = productstring.Split(',')[i] + "@" + matchprice;

                if (HighLowPrice.Length == 2)
                {
                    returnprice[i] += "@" + HighLowPrice[0] + "@" + HighLowPrice[1];
                }

            }

        }
        else
        {

            DataTable dtData = new DataTable();
            SqlConnection conn = new SqlConnection(ConfigurationSettings.AppSettings["MarketInfoSqlConnectionString"].ToString());
            SqlDataAdapter adp;
            string SqlCommand = "";
            string cmd = "'" + productstring.Replace(",", "','") + "'";
            SqlCommand = "select highprice,lowprice,closeprice,Commodity_Id from tblClosePrice where  Commodity_Id in (" + cmd + ")  ";

            adp = new SqlDataAdapter(SqlCommand, conn);
            adp.Fill(dtData);
            if (dtData.Rows.Count > 0)
            {
                returnprice = new string[dtData.Rows.Count];
                int i = 0;
                foreach (DataRow dr in dtData.Rows)
                {
                    returnprice[i] = dr["Commodity_Id"].ToString().Trim() + "@";
                    if (dr["closeprice"].ToString().Trim() != "")
                    {
                        returnprice[i] += String.Format("{0:####0.##}", (decimal.Parse(dr["closeprice"].ToString()))) + "@";
                    }
                    else
                    {
                        returnprice[i] += "@";
                    }
                    if (dr["highprice"].ToString().Trim() != "")
                    {
                        returnprice[i] += String.Format("{0:####0.##}", (decimal.Parse(dr["highprice"].ToString()))) + "@";
                    }
                    else
                    {
                        returnprice[i] += "@";
                    }
                    if (dr["lowprice"].ToString().Trim() != "")
                    {
                        returnprice[i] += String.Format("{0:####0.##}", (decimal.Parse(dr["lowprice"].ToString()))) + "@";
                    }
                    else
                    {
                        returnprice[i] += "@";
                    }
                    i++;
                }
            }


        }
        return returnprice;

    }

    public void TransferMessageOption(string UserLevel, string MessageOption, string GroupID, string ID)
    {
        //A PUBLIC_ADMIN_AE 
        //B PUBLIC_ADMIN_CUSTOMER
        //C PUBLIC_ADMIN_ALL
        //D PRIVATE_ADMIN_AE
        //E PRIVATE_ADMIN_CUSTOMER
        //F PUBLIC_SUPERVISER_AE
        //G PUBLIC_SUPERVISER_CUSTOMER
        //H PUBLIC_SUPERVISER_ALL
        //I PRIVATE_SUPERVISER_AE
        //J PRIVATE_SUPERVISER_CUSTOMER
        //K PUBLIC_AE_ALL
        //L PUBLIC_AE_GROUP
        //M PRIVATE_AE_CUSTOMER

        string result = "";
        if (UserLevel == "1")//admin
        {
            if (MessageOption == "0")
            {

            }
            else if (MessageOption == "1")
            {
            }
            else if (MessageOption == "2")
            {
            }
        }
    }

    [WebMethod]
    public DataTable WS_InsertMessage(string UserLevel, string MessageType, string MessageOption, string GroupID, string ID, string Message
        , string HyperLink
        , string Color
        , string DateStart
         , string DateEnd
        , string TimeStart
         , string TimeEnd
         , string DataOrder
          , string LoginId
         , string LoginCompany

        )
    {
        DataTable drResult = new DataTable("info");
        try
        {
            //MessageOption
            //A PUBLIC_ADMIN_AE 
            //B PUBLIC_ADMIN_CUSTOMER
            //C PUBLIC_ADMIN_ALL


            //D PRIVATE_ADMIN_AE
            //E PRIVATE_ADMIN_CUSTOMER

            //F PUBLIC_SUPERVISER_AE
            //G PUBLIC_SUPERVISER_CUSTOMER
            //H PUBLIC_SUPERVISER_ALL

            //I PRIVATE_SUPERVISER_AE
            //J PRIVATE_SUPERVISER_CUSTOMER

            //K PUBLIC_AE_ALL
            //L PUBLIC_AE_GROUP

            //M PRIVATE_AE_CUSTOMER


            SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);

            string sql = "";


            if (DataOrder == "")
            {

                sql = @" declare  @Order as int 

set @Order =(select    isnull(max([DataOrder]),0)+1   from [DDSCAccountDB].[dbo].[tbMessage]) ";

                sql += @"INSERT INTO [DDSCAccountDB].[dbo].[tbMessage]
           ([UserLevel]
           ,[MessageType]
           ,[MessageOption]
           ,[GroupID]
           ,[ID]
           ,[Message]
           ,[HyperLink]
           ,[Color]
           ,[DateStart]
           ,[DateEnd]
           ,[TimeStart]
           ,[TimeEnd]
           ,[DataOrder]
           ,[crt_id]
           ,[crt_date]
           ,[upd_id]
           ,[upd_date])
     VALUES
           (@UserLevel
           ,@MessageType
           ,@MessageOption
           ,@GroupID
           ,@ID
           ,@Message
           ,@HyperLink 
           ,@Color
           ,@DateStart
           ,@DateEnd
           ,@TimeStart
           ,@TimeEnd
           ,@Order
           ,@crt_id
           ,getdate()
           ,@upd_id
           ,getdate())";
            }

            else
            {
                sql = @"  update [DDSCAccountDB].[dbo].[tbMessage]  set [DataOrder]=[DataOrder]+1   where  [DataOrder] >= " + DataOrder + "  ";

                sql += @"INSERT INTO [DDSCAccountDB].[dbo].[tbMessage]
           ([UserLevel]
           ,[MessageType]
           ,[MessageOption]
           ,[GroupID]
           ,[ID]
           ,[Message]
           ,[HyperLink]
           ,[Color]
           ,[DateStart]
           ,[DateEnd]
           ,[TimeStart]
           ,[TimeEnd]
           ,[DataOrder]
           ,[crt_id]
           ,[crt_date]
           ,[upd_id]
           ,[upd_date])
     VALUES
           (@UserLevel
           ,@MessageType
           ,@MessageOption
           ,@GroupID
           ,@ID
           ,@Message
           ,@HyperLink 
           ,@Color
           ,@DateStart
           ,@DateEnd
           ,@TimeStart
           ,@TimeEnd
           ,@DataOrder
           ,@crt_id
           ,getdate()
           ,@upd_id
           ,getdate())";
            }
            SqlCommand cmd = new SqlCommand();
            cmd.Parameters.Add("@UserLevel", SqlDbType.VarChar, 1);
            cmd.Parameters.Add("@MessageType", SqlDbType.VarChar, 1);
            cmd.Parameters.Add("@MessageOption", SqlDbType.VarChar, 1);
            cmd.Parameters.Add("@GroupID", SqlDbType.VarChar, 30);
            cmd.Parameters.Add("@ID", SqlDbType.VarChar, 20);
            cmd.Parameters.Add("@Message", SqlDbType.Text, 600);
            cmd.Parameters.Add("@HyperLink", SqlDbType.Text, 600);
            cmd.Parameters.Add("@Color", SqlDbType.VarChar, 6);
            cmd.Parameters.Add("@DateStart", SqlDbType.VarChar, 8);
            cmd.Parameters.Add("@DateEnd", SqlDbType.VarChar, 8);
            cmd.Parameters.Add("@TimeStart", SqlDbType.VarChar, 6);
            cmd.Parameters.Add("@TimeEnd", SqlDbType.VarChar, 6);
            if (DataOrder != "")
                cmd.Parameters.Add("@DataOrder", SqlDbType.Int);
            cmd.Parameters.Add("@crt_id", SqlDbType.VarChar, 20);
            cmd.Parameters.Add("@upd_id", SqlDbType.VarChar, 20);
            cmd.Parameters["@UserLevel"].Value = UserLevel;
            cmd.Parameters["@MessageType"].Value = MessageType;
            cmd.Parameters["@MessageOption"].Value = MessageOption;
            cmd.Parameters["@GroupID"].Value = GroupID;
            cmd.Parameters["@ID"].Value = ID;
            cmd.Parameters["@Message"].Value = Message;
            cmd.Parameters["@HyperLink"].Value = HyperLink;
            cmd.Parameters["@Color"].Value = Color;
            cmd.Parameters["@DateStart"].Value = DateStart;
            cmd.Parameters["@DateEnd"].Value = DateEnd;
            cmd.Parameters["@TimeStart"].Value = TimeStart;
            cmd.Parameters["@TimeEnd"].Value = TimeEnd;
            if (DataOrder != "")
                cmd.Parameters["@DataOrder"].Value = DataOrder;

            cmd.Parameters["@crt_id"].Value = LoginId;
            cmd.Parameters["@upd_id"].Value = LoginId;

            conn.Open();
            cmd.Connection = conn;

            cmd.CommandText = sql;
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {

                drResult.Columns.Add("ReturnMessage");
                drResult.Columns.Add("ReturnCode");
                drResult.Rows.Add(new object[] { "存檔成功", "000" });


                if (MessageType == "1")//緊急
                    Send("", MessageOption, GroupID, ID, Message, Color, DateStart, DateEnd, TimeStart, TimeEnd, DataOrder == "" ? "0" : DataOrder, LoginId, LoginCompany, HyperLink);

            }
            else
            {

                drResult.Columns.Add("ReturnMessage");
                drResult.Columns.Add("ReturnCode");
                drResult.Rows.Add(new object[] { "存檔失敗", "100" });
            }

        }
        catch (Exception ex)
        {


            drResult.Columns.Add("ReturnMessage");
            drResult.Columns.Add("ReturnCode");
            drResult.Rows.Add(new object[] { "存檔異常" + ex.Message, "999" });


        }
        return drResult;
    }



    public void Send(string Seq, string MessageOption, string GroupID, string ID, string Message
        , string Color
        , string DateStart
         , string DateEnd
        , string TimeStart
         , string TimeEnd
         , string DataOrder
          , string LoginId, string LoginCompany, string HyperLink
        )
    {
        try
        {
            string MESSAGE_IP = ConfigurationSettings.AppSettings["MESSAGE_IP"];
            string MESSAGE_PORT = ConfigurationSettings.AppSettings["MESSAGE_PORT"];
            Socket S = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            S.Connect(MESSAGE_IP, int.Parse(MESSAGE_PORT));


            PutMessageBody PutMessageBody = new PutMessageBody();
            PutMessageBody.Seq = System.Text.ASCIIEncoding.ASCII.GetBytes(Color.PadLeft(4, '0'));
            PutMessageBody.MessageOption = System.Text.ASCIIEncoding.ASCII.GetBytes(MessageOption.PadLeft(1, '0'));
            PutMessageBody.GroupID = System.Text.ASCIIEncoding.ASCII.GetBytes(GroupID.PadRight(30, ' '));
            PutMessageBody.Id = System.Text.ASCIIEncoding.ASCII.GetBytes(ID.PadRight(20, ' '));
            PutMessageBody.Message = System.Text.UnicodeEncoding.Unicode.GetBytes(Message.PadRight(600, ' ')); //中英文混雜
            PutMessageBody.Color = System.Text.ASCIIEncoding.ASCII.GetBytes(Color.PadLeft(6, '0'));
            PutMessageBody.DateStart = System.Text.ASCIIEncoding.ASCII.GetBytes(DateStart.PadRight(8, ' '));
            PutMessageBody.DateEnd = System.Text.ASCIIEncoding.ASCII.GetBytes(DateEnd.PadRight(8, ' '));
            PutMessageBody.TimeStart = System.Text.ASCIIEncoding.ASCII.GetBytes(TimeStart.PadRight(4, ' '));
            PutMessageBody.TimeEnd = System.Text.ASCIIEncoding.ASCII.GetBytes(TimeEnd.PadRight(4, ' '));
            PutMessageBody.DataOrder = BitConverter.GetBytes(Int32.Parse(DataOrder));//""byte.Parse(
            PutMessageBody.CrtId = System.Text.ASCIIEncoding.ASCII.GetBytes(LoginId.PadRight(20, ' '));
            PutMessageBody.Company = System.Text.ASCIIEncoding.ASCII.GetBytes(LoginCompany.PadRight(7, ' '));
            PutMessageBody.HyperLink = System.Text.ASCIIEncoding.ASCII.GetBytes(HyperLink.PadRight(1000, ' '));


            byte[] head = new byte[] { DDSCSocketHead.PutMessage };
            byte[] EndCode = new byte[] { DDSCSocketHead.endCode };

            byte[] data = ParserFunction.StructureToByteArray(PutMessageBody);
            byte[] len = BitConverter.GetBytes(data.Length);
            //  head.con
            byte[] raw = ParserFunction.ConcatArrays<byte>(head, len, data, EndCode);

            S.Send(raw);
            S.Close();

        }
        catch (Exception ex)
        {
            throw ex;
        }


    }

    [WebMethod]
    public DataSet WS_DelMessage(string UserLevel, string SEQ
          , string LoginId
        , string LoginCompany
        )
    {
        DataSet ds = new DataSet("result");
        DataTable drResult = new DataTable("info");
        try
        {



            SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);

            string sql = @" delete from  [DDSCAccountDB].[dbo].[tbMessage]
            where SEQ=@SEQ ";

            SqlCommand cmd = new SqlCommand();
            cmd.Parameters.Add("@SEQ", SqlDbType.Int);


            cmd.Parameters["@SEQ"].Value = SEQ;

            conn.Open();
            cmd.Connection = conn;
            cmd.CommandText = sql;
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {

                drResult.Columns.Add("ReturnMessage");
                drResult.Columns.Add("ReturnCode");
                drResult.Rows.Add(new object[] { "刪除成功", "000" });
            }
            else
            {

                drResult.Columns.Add("ReturnMessage");
                drResult.Columns.Add("ReturnCode");
                drResult.Rows.Add(new object[] { "刪除失敗", "100" });
            }

        }
        catch (Exception ex)
        {


            drResult.Columns.Add("ReturnMessage");
            drResult.Columns.Add("ReturnCode");
            drResult.Rows.Add(new object[] { "刪除失敗", "999" });


        }
        ds.Tables.Add(drResult);
        return ds;
    }


    [WebMethod]
    public DataSet WS_DelALLMessage(string UserLevel, string[] SEQ
          , string LoginId
        , string LoginCompany
        )
    {
        DataSet ds = new DataSet("result");
        DataTable drResult = new DataTable("info");
        try
        {



            SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);
            SqlCommand cmd = new SqlCommand();

            string sql = @" delete from  [DDSCAccountDB].[dbo].[tbMessage] where  ";
            if (SEQ.Length == 1)
            {
                sql += " SEQ= " + SEQ[0];
            }
            else
            {
                for (int i = 0; i < SEQ.Length; i++)
                {

                    sql += "    SEQ= " + SEQ[i] + " or";

                }
                sql = sql.Substring(0, sql.Length - 2);
            }


            conn.Open();
            cmd.Connection = conn;
            cmd.CommandText = sql;
            int c = cmd.ExecuteNonQuery();
            if (c > 0)
            {

                drResult.Columns.Add("ReturnMessage");
                drResult.Columns.Add("ReturnCode");
                drResult.Rows.Add(new object[] { "刪除成功", "000" });
            }
            else
            {

                drResult.Columns.Add("ReturnMessage");
                drResult.Columns.Add("ReturnCode");
                drResult.Rows.Add(new object[] { "刪除失敗", "100" });
            }

        }
        catch (Exception ex)
        {


            drResult.Columns.Add("ReturnMessage");
            drResult.Columns.Add("ReturnCode");
            drResult.Rows.Add(new object[] { "刪除失敗", "999" });


        }
        ds.Tables.Add(drResult);
        return ds;
    }




    [WebMethod]
    public DataSet WS_SelectMessage(string UserLevel
        , string MessageType, string MessageOption
        , string GroupID, string ID
        , string DateStart
         , string DateEnd
          , string LoginId
        , string LoginCompany
        , int p
        , int max
        )
    {
        //MessageOption

        //A PUBLIC_ADMIN_AE 
        //B PUBLIC_ADMIN_CUSTOMER
        //C PUBLIC_ADMIN_ALL
        //D PRIVATE_ADMIN_AE
        //E PRIVATE_ADMIN_CUSTOMER

        //F PUBLIC_SUPERVISER_AE
        //G PUBLIC_SUPERVISER_CUSTOMER
        //H PUBLIC_SUPERVISER_ALL
        //I PRIVATE_SUPERVISER_AE
        //J PRIVATE_SUPERVISER_CUSTOMER

        //K PUBLIC_AE_ALL
        //L PUBLIC_AE_GROUP
        //M PRIVATE_AE_CUSTOMER
        DataSet ds = new DataSet("result");
        DataTable drResult = new DataTable("info");
        try
        {
            SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);
            string sql = @"SELECT [SEQ]
      ,[UserLevel]
      ,[MessageType]
      ,[MessageOption]
      ,[GroupID]
      ,case when isnull([ID],'')='' then 'all' else [ID] end[ID]
      ,[Message]
      ,[HyperLink]
      ,[Color]
      ,[DateStart]
      ,[DateEnd]
      ,[TimeStart]
      ,[TimeEnd]
      ,[DataOrder]
      ,[crt_id]
      ,[crt_date]
      ,[upd_id]
      ,[upd_date]
  FROM [DDSCAccountDB].[dbo].[tbMessage] where [MessageOption]='" + MessageOption + "' ";

            if (MessageType != "")
            {
                sql += "and [MessageType]='" + MessageType + "' ";
            }

            if (MessageOption == "L")
            {
                if (GroupID.Length > 0)
                    sql += "and [GroupID]='" + GroupID + "' ";
            }
            if (MessageOption == "D" || MessageOption == "E" || MessageOption == "I" || MessageOption == "J" || MessageOption == "M")
            {
                if (ID.Length > 0)
                    sql += "and [ID]='" + ID + "' ";
            }
            if (UserLevel != "1") //不等於ADMIN
            {

                sql += "and [crt_id]='" + LoginId + "' ";
            }

            if (DateStart.Length > 0)
            {
                sql += "and [DateStart]>='" + DateStart + "' and [DateEnd] <='" + DateEnd + "' ";
            }
            if (UserLevel == "1") //等於ADMIN
                sql += " order by [DataOrder] asc ";
            else
                sql += " order by [crt_date] asc ";
            SqlDataAdapter adp;
            SqlCommand sqlcmd = new SqlCommand(sql, conn);
            adp = new SqlDataAdapter(sqlcmd);
            DataTable dt = new DataTable("DDSCAccountDB");
            int i = adp.Fill(p, max, dt);
            if (i > 0)
            {
                drResult.Columns.Add("ReturnMessage");
                drResult.Columns.Add("ReturnCode");
                drResult.Rows.Add(new object[] { i.ToString(), "000" });
                ds.Tables.Add(drResult);
                ds.Tables.Add(dt);
            }
            else
            {
                drResult.Columns.Add("ReturnMessage");
                drResult.Columns.Add("ReturnCode");
                drResult.Rows.Add(new object[] { "查無資料", "100" });

                ds.Tables.Add(drResult);
            }



        }
        catch (Exception ex)
        {


            drResult.Columns.Add("ReturnMessage");
            drResult.Columns.Add("ReturnCode");
            drResult.Rows.Add(new object[] { "查詢異常", "999" });

            ds.Tables.Add(drResult);
        }
        return ds;
    }


    [WebMethod]
    public DataSet WS_SelectCountMessage(string UserLevel
        , string MessageType, string MessageOption
        , string GroupID, string ID
        , string DateStart
         , string DateEnd
          , string LoginId
        , string LoginCompany

        )
    {
        //MessageOption

        //A PUBLIC_ADMIN_AE 
        //B PUBLIC_ADMIN_CUSTOMER
        //C PUBLIC_ADMIN_ALL
        //D PRIVATE_ADMIN_AE
        //E PRIVATE_ADMIN_CUSTOMER

        //F PUBLIC_SUPERVISER_AE
        //G PUBLIC_SUPERVISER_CUSTOMER
        //H PUBLIC_SUPERVISER_ALL
        //I PRIVATE_SUPERVISER_AE
        //J PRIVATE_SUPERVISER_CUSTOMER

        //K PUBLIC_AE_ALL
        //L PUBLIC_AE_GROUP
        //M PRIVATE_AE_CUSTOMER
        DataSet ds = new DataSet("result");
        DataTable drResult = new DataTable("info");
        try
        {
            SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);
            string sql = @"SELECT isnull(count(*),0)count
  FROM [DDSCAccountDB].[dbo].[tbMessage] where [MessageOption]='" + MessageOption + "' ";

            if (MessageType != "")
            {
                sql += "and [MessageType]='" + MessageType + "' ";
            }

            if (MessageOption == "L")
            {
                if (GroupID.Length > 0)
                    sql += "and [GroupID]='" + GroupID + "' ";
            }
            if (MessageOption == "D" || MessageOption == "E" || MessageOption == "I" || MessageOption == "J" || MessageOption == "M")
            {
                if (ID.Length > 0)
                    sql += "and [ID]='" + ID + "' ";
            }
            if (UserLevel != "1") //不等於ADMIN
            {

                sql += "and [crt_id]='" + LoginId + "' ";
            }

            if (DateStart.Length > 0)
            {
                sql += "and [DateStart]>='" + DateStart + "' and [DateEnd] <='" + DateEnd + "' ";
            }

            SqlDataAdapter adp;
            SqlCommand sqlcmd = new SqlCommand(sql, conn);
            adp = new SqlDataAdapter(sqlcmd);
            DataTable dt = new DataTable("DDSCAccountDB");
            int i = adp.Fill(dt);
            if (i > 0)
            {
                drResult.Columns.Add("ReturnMessage");
                drResult.Columns.Add("ReturnCode");
                drResult.Rows.Add(new object[] { i.ToString(), "000" });
                ds.Tables.Add(drResult);
                ds.Tables.Add(dt);
            }
            else
            {
                drResult.Columns.Add("ReturnMessage");
                drResult.Columns.Add("ReturnCode");
                drResult.Rows.Add(new object[] { "查無資料", "100" });

                ds.Tables.Add(drResult);
            }



        }
        catch (Exception ex)
        {


            drResult.Columns.Add("ReturnMessage");
            drResult.Columns.Add("ReturnCode");
            drResult.Rows.Add(new object[] { "查詢異常", "999" });

            ds.Tables.Add(drResult);
        }
        return ds;
    }



    [WebMethod]
    public DataTable WS_UpdMessage(string UserLevel, string MessageType, string MessageOption, string GroupID, string ID, string Message
        , string HyperLink
        , string Color
        , string DateStart
         , string DateEnd
        , string TimeStart
         , string TimeEnd
         , string DataOrder
        , string Seq
          , string LoginId
        , string LoginCompany
        )
    {
        DataTable drResult = new DataTable("info");
        try
        {
            //MessageOption
            //A PUBLIC_ADMIN_AE 
            //B PUBLIC_ADMIN_CUSTOMER
            //C PUBLIC_ADMIN_ALL
            //D PRIVATE_ADMIN_AE
            //E PRIVATE_ADMIN_CUSTOMER
            //F PUBLIC_SUPERVISER_AE
            //G PUBLIC_SUPERVISER_CUSTOMER
            //H PUBLIC_SUPERVISER_ALL
            //I PRIVATE_SUPERVISER_AE
            //J PRIVATE_SUPERVISER_CUSTOMER
            //K PUBLIC_AE_ALL
            //L PUBLIC_AE_GROUP
            //M PRIVATE_AE_CUSTOMER


            SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);

            string sql = "";
            if (DataOrder == "")
            {
                sql = @" declare  @Order as int 

set @Order =(select    isnull(max([DataOrder]),0)+1   from [DDSCAccountDB].[dbo].[tbMessage]) ";


                sql += @" UPDATE [DDSCAccountDB].[dbo].[tbMessage]
   SET [UserLevel] = @UserLevel
      ,[MessageType] = @MessageType
      ,[MessageOption] = @MessageOption
      ,[GroupID] = @GroupID
      ,[ID] = @ID
      ,[Message] = @Message
      ,[HyperLink] =@HyperLink 
      ,[Color] = @Color
      ,[DateStart] = @DateStart
      ,[DateEnd] = @DateEnd
      ,[TimeStart] = @TimeStart
      ,[TimeEnd] = @TimeEnd
      ,[DataOrder] = @Order
      ,[upd_id] = @upd_id
      ,[upd_date] = getdate()
 WHERE [Seq]=@Seq ";
            }
            else
            {
                sql = @"  update [DDSCAccountDB].[dbo].[tbMessage]  set [DataOrder]=[DataOrder]+1   where  [DataOrder] >= " + DataOrder + "  ";

                sql += @" UPDATE [DDSCAccountDB].[dbo].[tbMessage]
   SET [UserLevel] = @UserLevel
      ,[MessageType] = @MessageType
      ,[MessageOption] = @MessageOption
      ,[GroupID] = @GroupID
      ,[ID] = @ID
      ,[Message] = @Message
      ,[HyperLink] =@HyperLink 
      ,[Color] = @Color
      ,[DateStart] = @DateStart
      ,[DateEnd] = @DateEnd
      ,[TimeStart] = @TimeStart
      ,[TimeEnd] = @TimeEnd
      ,[DataOrder] = @DataOrder
      ,[upd_id] = @upd_id
      ,[upd_date] = getdate()
 WHERE [Seq]=@Seq ";
            }
            SqlCommand cmd = new SqlCommand();
            cmd.Parameters.Add("@UserLevel", SqlDbType.VarChar, 1);
            cmd.Parameters.Add("@MessageType", SqlDbType.VarChar, 1);
            cmd.Parameters.Add("@MessageOption", SqlDbType.VarChar, 1);
            cmd.Parameters.Add("@GroupID", SqlDbType.VarChar, 30);
            cmd.Parameters.Add("@ID", SqlDbType.VarChar, 20);
            cmd.Parameters.Add("@Message", SqlDbType.Text, 600);
            cmd.Parameters.Add("@HyperLink", SqlDbType.Text, 600);
            cmd.Parameters.Add("@Color", SqlDbType.VarChar, 6);
            cmd.Parameters.Add("@DateStart", SqlDbType.VarChar, 8);
            cmd.Parameters.Add("@DateEnd", SqlDbType.VarChar, 8);
            cmd.Parameters.Add("@TimeStart", SqlDbType.VarChar, 6);
            cmd.Parameters.Add("@TimeEnd", SqlDbType.VarChar, 6);
            if (DataOrder != "")
                cmd.Parameters.Add("@DataOrder", SqlDbType.Int);
            cmd.Parameters.Add("@upd_id", SqlDbType.VarChar, 20);
            cmd.Parameters.Add("@Seq", SqlDbType.Int);
            cmd.Parameters["@UserLevel"].Value = UserLevel;
            cmd.Parameters["@MessageType"].Value = MessageType;
            cmd.Parameters["@MessageOption"].Value = MessageOption;
            cmd.Parameters["@GroupID"].Value = GroupID;
            cmd.Parameters["@ID"].Value = ID;
            cmd.Parameters["@Message"].Value = Message;
            cmd.Parameters["@HyperLink"].Value = HyperLink;
            cmd.Parameters["@Color"].Value = Color;
            cmd.Parameters["@DateStart"].Value = DateStart;
            cmd.Parameters["@DateEnd"].Value = DateEnd;
            cmd.Parameters["@TimeStart"].Value = TimeStart;
            cmd.Parameters["@TimeEnd"].Value = TimeEnd;
            if (DataOrder != "")
                cmd.Parameters["@DataOrder"].Value = DataOrder;
            cmd.Parameters["@upd_id"].Value = LoginId;
            cmd.Parameters["@Seq"].Value = Seq;
            conn.Open();
            cmd.Connection = conn;
            cmd.CommandText = sql;
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {

                drResult.Columns.Add("ReturnMessage");
                drResult.Columns.Add("ReturnCode");
                drResult.Rows.Add(new object[] { "修改成功", "000" });

                if (MessageType == "1")//緊急
                    Send("", MessageOption, GroupID, ID, Message, Color, DateStart, DateEnd, TimeStart, TimeEnd, DataOrder == "" ? "0" : DataOrder, LoginId, LoginCompany, HyperLink);

            }
            else
            {

                drResult.Columns.Add("ReturnMessage");
                drResult.Columns.Add("ReturnCode");
                drResult.Rows.Add(new object[] { "修改失敗", "100" });
            }

        }
        catch (Exception ex)
        {


            drResult.Columns.Add("ReturnMessage");
            drResult.Columns.Add("ReturnCode");
            drResult.Rows.Add(new object[] { "修改異常", "999" });


        }
        return drResult;
    }



    [WebMethod]
    public DataSet WS_UserPublicMessage(string UserLevel //1:admin  2:supervisor 3:ae 9:cus
         , string MessageType   //"": 全部 "1":一般 "2":空白
          , string LoginId
        , string LoginCompany
        , int p
        , int max
        )
    {
        //MessageOption

        //A PUBLIC_ADMIN_AE 
        //B PUBLIC_ADMIN_CUSTOMER
        //C PUBLIC_ADMIN_ALL
        //D PRIVATE_ADMIN_AE
        //E PRIVATE_ADMIN_CUSTOMER

        //F PUBLIC_SUPERVISER_AE
        //G PUBLIC_SUPERVISER_CUSTOMER
        //H PUBLIC_SUPERVISER_ALL
        //I PRIVATE_SUPERVISER_AE
        //J PRIVATE_SUPERVISER_CUSTOMER

        //K PUBLIC_AE_ALL
        //L PUBLIC_AE_GROUP
        //M PRIVATE_AE_CUSTOMER
        DataSet ds = new DataSet("result");
        DataTable drResult = new DataTable("info");
        try
        {
            SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);
            string sql = "";



            if (UserLevel == "1")//admin
            {
                sql = getPublicADMINMessage(LoginId);

                if (MessageType == "0") sql = " select * from (" + sql + " )a where  [MessageType]='0' ";
                if (MessageType == "1") sql = " select * from ( " + sql + " )a where  [MessageType]='1' ";

                sql += " order by  [DataOrder] asc ";
            }
            else if (UserLevel == "2")//supervisor
            {
                sql = getPublicSuperMessage(LoginId);

                if (MessageType == "0") sql = " select * from (" + sql + " )a where  [MessageType]='0' ";
                if (MessageType == "1") sql = " select * from ( " + sql + " )a where  [MessageType]='1' ";

                sql += " order by  [DataOrder] asc ";
            }
            else if (UserLevel == "3")//AE
            {
                sql = getPublicAEMessage(LoginId);
                if (MessageType == "0") sql = " select * from (" + sql + " )a where  [MessageType]='0' ";
                if (MessageType == "1") sql = " select * from ( " + sql + " )a where  [MessageType]='1' ";
                sql += " order by  [DataOrder] asc ";
            }
            else if (UserLevel == "9")//cus
            {
                sql = getPublicCustomerMessage(LoginCompany, LoginId);
                if (MessageType == "0") sql = " select * from (" + sql + " )a where   [MessageType]='0' ";
                if (MessageType == "1") sql = " select * from (" + sql + " )a where   [MessageType]='1' ";
                sql += " order by  [DataOrder] asc ";

            }


            SqlDataAdapter adp;
            SqlCommand sqlcmd = new SqlCommand(sql, conn);
            adp = new SqlDataAdapter(sqlcmd);
            DataTable dt = new DataTable("DDSCAccountDB");
            int i = adp.Fill(p, max, dt);
            if (i > 0)
            {
                drResult.Columns.Add("ReturnMessage");
                drResult.Columns.Add("ReturnCode");
                drResult.Rows.Add(new object[] { i.ToString(), "000" });
                ds.Tables.Add(drResult);
                ds.Tables.Add(dt);
            }
            else
            {
                drResult.Columns.Add("ReturnMessage");
                drResult.Columns.Add("ReturnCode");
                drResult.Rows.Add(new object[] { "查無資料", "100" });

                ds.Tables.Add(drResult);
            }



        }
        catch (Exception ex)
        {


            drResult.Columns.Add("ReturnMessage");
            drResult.Columns.Add("ReturnCode");
            drResult.Rows.Add(new object[] { "查詢異常", "999" });

            ds.Tables.Add(drResult);
        }
        return ds;
    }

    [WebMethod]
    public DataSet WS_UserPrivateMessage(string UserLevel //1:admin  2:supervisor 3:ae 9:cus
         , string MessageType   //"": 全部 "1":一般 "2":空白
          , string LoginId
        , string LoginCompany
        , int p
        , int max
        )
    {
        //MessageOption

        //A PUBLIC_ADMIN_AE 
        //B PUBLIC_ADMIN_CUSTOMER
        //C PUBLIC_ADMIN_ALL
        //D PRIVATE_ADMIN_AE
        //E PRIVATE_ADMIN_CUSTOMER

        //F PUBLIC_SUPERVISER_AE
        //G PUBLIC_SUPERVISER_CUSTOMER
        //H PUBLIC_SUPERVISER_ALL
        //I PRIVATE_SUPERVISER_AE
        //J PRIVATE_SUPERVISER_CUSTOMER

        //K PUBLIC_AE_ALL
        //L PUBLIC_AE_GROUP
        //M PRIVATE_AE_CUSTOMER
        DataSet ds = new DataSet("result");
        DataTable drResult = new DataTable("info");
        try
        {
            SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);
            string sql = "";

            if (UserLevel == "2")//super
            {
                sql = getPrivateSuperMessage(LoginId);

                if (MessageType == "0") sql = " select * from (" + sql + " )a where  [MessageType]='0' ";
                if (MessageType == "1") sql = " select * from (" + sql + " )a where  [MessageType]='1' ";

                sql += " order by  [DataOrder] asc ";

            }
            if (UserLevel == "3")//AE
            {
                sql = getPrivateAEMessage(LoginId);
                if (MessageType == "0") sql = " select * from (" + sql + " )a where  [MessageType]='0' ";
                if (MessageType == "1") sql = " select * from (" + sql + " )a where  [MessageType]='1' ";

                sql += " order by  [DataOrder] asc ";
            }
            else if (UserLevel == "9")//cus
            {

                sql = getPrivateCustomerMessage(LoginCompany, LoginId);
                if (MessageType == "0") sql = " select * from (" + sql + " )a where  [MessageType]='0' ";
                if (MessageType == "1") sql = " select * from (" + sql + " )a where  [MessageType]='1' ";
                sql += " order by  [DataOrder] asc ";

            }


            SqlDataAdapter adp;
            SqlCommand sqlcmd = new SqlCommand(sql, conn);
            adp = new SqlDataAdapter(sqlcmd);
            DataTable dt = new DataTable("DDSCAccountDB");
            int i = adp.Fill(p, max, dt);
            if (i > 0)
            {
                drResult.Columns.Add("ReturnMessage");
                drResult.Columns.Add("ReturnCode");
                drResult.Rows.Add(new object[] { i.ToString(), "000" });
                ds.Tables.Add(drResult);
                ds.Tables.Add(dt);
            }
            else
            {
                drResult.Columns.Add("ReturnMessage");
                drResult.Columns.Add("ReturnCode");
                drResult.Rows.Add(new object[] { "查無資料", "100" });

                ds.Tables.Add(drResult);
            }



        }
        catch (Exception ex)
        {


            drResult.Columns.Add("ReturnMessage");
            drResult.Columns.Add("ReturnCode");
            drResult.Rows.Add(new object[] { "查詢異常", "999" });

            ds.Tables.Add(drResult);
        }
        return ds;
    }

    public string getPublicADMINMessage(string userid)
    {
        string sql = @"
 
SELECT [SEQ]
      ,[Message]
      ,[HyperLink]
      ,[Color]
      ,[DataOrder]
 ,[MessageType]
  FROM [DDSCAccountDB].[dbo].[tbMessage] 
where   
cast (	[DateStart]+' '+ stuff([TimeStart],3,0,':')  as datetime) <=getdate()
and 
cast (	[DateEnd]+' '+ stuff([TimeEnd],3,0,':')  as datetime) >=getdate()
 and ([MessageOption]='A' or [MessageOption]='B' or [MessageOption]='C')
 and [crt_id]='{0}'

";

        sql = string.Format(sql, userid);
        return sql;
    }

    public string getPublicSuperMessage(string userid)
    {
        string sql = @"
SELECT [SEQ]
      ,[Message]
      ,[HyperLink]
      ,[Color]
      ,[DataOrder]
 ,[MessageType]
  FROM [DDSCAccountDB].[dbo].[tbMessage] 
where   
cast (	[DateStart]+' '+ stuff([TimeStart],3,0,':')  as datetime) <=getdate()
and 
cast (	[DateEnd]+' '+ stuff([TimeEnd],3,0,':')  as datetime) >=getdate()
 and ([MessageOption]='A'   or [MessageOption]='C')
union all
SELECT [SEQ]
      ,[Message]
      ,[HyperLink]
      ,[Color]
      ,[DataOrder]
 ,[MessageType]
  FROM [DDSCAccountDB].[dbo].[tbMessage] 
where   
cast (	[DateStart]+' '+ stuff([TimeStart],3,0,':')  as datetime) <=getdate()
and 
cast (	[DateEnd]+' '+ stuff([TimeEnd],3,0,':')  as datetime) >=getdate()
and [crt_id] in 
(select a.userid from AEConfigDB.AEConfigDB.dbo.UserInfo a ,AEConfigDB.AEConfigDB.dbo.User_Level b  
where  b.level='2' and a.userid=b.userid
 and groupid= (select groupid from AEConfigDB.AEConfigDB.dbo.UserInfo   where  userid ='{0}' ))
 and ([MessageOption]='F'   or [MessageOption]='G' or [MessageOption]='H')

";

        sql = string.Format(sql, userid);
        return sql;
    }

    public string getPublicAEMessage(string userid)
    {
        string sql = @"
SELECT [SEQ]
      ,[Message]
      ,[HyperLink]
      ,[Color]
      ,[DataOrder]
 ,[MessageType]
  FROM [DDSCAccountDB].[dbo].[tbMessage] 
where   
cast (	[DateStart]+' '+ stuff([TimeStart],3,0,':')  as datetime) <=getdate()
and 
cast (	[DateEnd]+' '+ stuff([TimeEnd],3,0,':')  as datetime) >=getdate()
and ( [MessageOption]='A' or [MessageOption]='C')
union all
SELECT [SEQ]
      ,[Message]
      ,[HyperLink]
      ,[Color]
      ,[DataOrder]
 ,[MessageType]
  FROM [DDSCAccountDB].[dbo].[tbMessage] 
where   
cast (	[DateStart]+' '+ stuff([TimeStart],3,0,':')  as datetime) <=getdate()
and 
cast (	[DateEnd]+' '+ stuff([TimeEnd],3,0,':')  as datetime) >=getdate()
and [crt_id] in 

(select a.userid from AEConfigDB.AEConfigDB.dbo.UserInfo a ,AEConfigDB.AEConfigDB.dbo.User_Level b  
where  b.level='2' and a.userid=b.userid
 and groupid= (select groupid from AEConfigDB.AEConfigDB.dbo.UserInfo   where  userid ='{0}' ))

 and ( [MessageOption]='F' or [MessageOption]='H')
 

";

        sql = string.Format(sql, userid);
        return sql;
    }


    public string getPrivateSuperMessage(string userid)
    {
        string sql = @"
SELECT [SEQ]
      ,[Message]
      ,[HyperLink]
      ,[Color]
      ,[DataOrder]
 ,[MessageType]
  FROM [DDSCAccountDB].[dbo].[tbMessage] 
where   
cast (	[DateStart]+' '+ stuff([TimeStart],3,0,':')  as datetime) <=getdate()
and 
cast (	[DateEnd]+' '+ stuff([TimeEnd],3,0,':')  as datetime) >=getdate()
and [MessageOption]='D' and [ID]='{0}'
 
 
";

        sql = string.Format(sql, userid);
        return sql;
    }



    public string getPrivateAEMessage(string userid)
    {
        string sql = @"
SELECT [SEQ]
      ,[Message]
      ,[HyperLink]
      ,[Color]
      ,[DataOrder]
 ,[MessageType]
  FROM [DDSCAccountDB].[dbo].[tbMessage] 
where   
cast (	[DateStart]+' '+ stuff([TimeStart],3,0,':')  as datetime) <=getdate()
and 
cast (	[DateEnd]+' '+ stuff([TimeEnd],3,0,':')  as datetime) >=getdate()
and [MessageOption]='D' and [ID]='{0}'
union all
SELECT [SEQ]
      ,[Message]
      ,[HyperLink]
      ,[Color]
      ,[DataOrder]
 ,[MessageType]
  FROM [DDSCAccountDB].[dbo].[tbMessage] 
where   
cast (	[DateStart]+' '+ stuff([TimeStart],3,0,':')  as datetime) <=getdate()
and 
cast (	[DateEnd]+' '+ stuff([TimeEnd],3,0,':')  as datetime) >=getdate()
and [crt_id]in 
(
select a.userid from AEConfigDB.AEConfigDB.dbo.UserInfo a ,AEConfigDB.AEConfigDB.dbo.User_Level b  
where  b.level='2' and a.userid=b.userid
 and groupid= (select groupid from AEConfigDB.AEConfigDB.dbo.UserInfo   where  userid ='{0}' )
)
and [MessageOption]='I' and [ID]='{0}'
 
";

        sql = string.Format(sql, userid);
        return sql;
    }



    public string getPublicCustomerMessage(string company, string actno)
    {
        string sql = @"
SELECT [SEQ]
      ,[Message]
      ,[HyperLink]
      ,[Color]
      ,[DataOrder]
 ,[MessageType]
  FROM [DDSCAccountDB].[dbo].[tbMessage] 
where   
cast (	[DateStart]+' '+ stuff([TimeStart],3,0,':')  as datetime) <=getdate()
and 
cast (	[DateEnd]+' '+ stuff([TimeEnd],3,0,':')  as datetime) >=getdate()
and ([MessageOption]='B' or [MessageOption]='C')
union all
SELECT [SEQ]
      ,[Message]
      ,[HyperLink]
      ,[Color]
      ,[DataOrder]
 ,[MessageType]
  FROM [DDSCAccountDB].[dbo].[tbMessage] 
where   
cast (	[DateStart]+' '+ stuff([TimeStart],3,0,':')  as datetime) <=getdate()
and 
cast (	[DateEnd]+' '+ stuff([TimeEnd],3,0,':')  as datetime) >=getdate()
and [crt_id] in

(select a.userid from AEConfigDB.AEConfigDB.dbo.UserInfo a ,AEConfigDB.AEConfigDB.dbo.User_Level b  
where  b.level='2' and a.userid=b.userid
 and groupid in (select groupid from AEConfigDB.AEConfigDB.dbo.UserInfo   where  userid in 
	(select userid from AEConfigDB.AEConfigDB.dbo.tblCustomerSet   where company ='{0}' and actno ='{1}'  ) 
	)
)
and( [MessageOption]='G' or [MessageOption]='H')

union all
SELECT [SEQ]
      ,[Message]
      ,[HyperLink]
      ,[Color]
      ,[DataOrder]
 ,[MessageType]
  FROM [DDSCAccountDB].[dbo].[tbMessage] 
where   
cast (	[DateStart]+' '+ stuff([TimeStart],3,0,':')  as datetime) <=getdate()
and 
cast (	[DateEnd]+' '+ stuff([TimeEnd],3,0,':')  as datetime) >=getdate()
and ( 
[MessageOption]='K' or ([MessageOption]='L'  

and [crt_id] in

(select a.userid from AEConfigDB.AEConfigDB.dbo.UserInfo a ,AEConfigDB.AEConfigDB.dbo.User_Level b  
where  b.level='2' and a.userid=b.userid
 and groupid in (select groupid from AEConfigDB.AEConfigDB.dbo.UserInfo   where  userid in 
	(select userid from AEConfigDB.AEConfigDB.dbo.tblCustomerSet   where company ='{0}' and actno ='{1}'  ) 
	)
)
 



)
)

 
";

        sql = string.Format(sql, company, actno);
        return sql;
    }

    public string getPrivateCustomerMessage(string company, string actno)
    {
        string sql = @"
SELECT [SEQ]
      ,[Message]
      ,[HyperLink]
      ,[Color]
      ,[DataOrder]
 ,[MessageType]
  FROM [DDSCAccountDB].[dbo].[tbMessage] 
where   
cast (	[DateStart]+' '+ stuff([TimeStart],3,0,':')  as datetime) <=getdate()
and 
cast (	[DateEnd]+' '+ stuff([TimeEnd],3,0,':')  as datetime) >=getdate()
and [MessageOption]='E'  and [ID]='{2}'
union all
SELECT [SEQ]
      ,[Message]
      ,[HyperLink]
      ,[Color]
      ,[DataOrder]
 ,[MessageType]
  FROM [DDSCAccountDB].[dbo].[tbMessage] 
where   
cast (	[DateStart]+' '+ stuff([TimeStart],3,0,':')  as datetime) <=getdate()
and 
cast (	[DateEnd]+' '+ stuff([TimeEnd],3,0,':')  as datetime) >=getdate()
and [crt_id] in

(select a.userid from AEConfigDB.AEConfigDB.dbo.UserInfo a ,AEConfigDB.AEConfigDB.dbo.User_Level b  
where  b.level='2' and a.userid=b.userid
 and groupid= (select groupid from AEConfigDB.AEConfigDB.dbo.UserInfo   where  userid in 
(select userid from AEConfigDB.AEConfigDB.dbo.tblCustomerSet   where company ='{0}' and actno ='{1}'  ) ))

and  [MessageOption]='J'  

union all
SELECT [SEQ]
      ,[Message]
      ,[HyperLink]
      ,[Color]
      ,[DataOrder]
 ,[MessageType]
  FROM [DDSCAccountDB].[dbo].[tbMessage] 
where   
cast (	[DateStart]+' '+ stuff([TimeStart],3,0,':')  as datetime) <=getdate()
and 
cast (	[DateEnd]+' '+ stuff([TimeEnd],3,0,':')  as datetime) >=getdate()
and  [MessageOption]='M' and [ID]='{2}'

 
";

        sql = string.Format(sql, company, actno, actno);
        return sql;
    }



    [WebMethod]
    public System.Xml.XmlDocument WS_getBANK400(string FIRM, string ACTNO, string CURRENCY)
    {


        getActno(ref   FIRM, ref   ACTNO);

        DataSet dsReturn = new DataSet("Return");


        DataTable dtIB = new DataTable("BANK400");

        dtIB.CaseSensitive = true;




        SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);
        string sql = @"  
select a.*, 

a.BANKID2+'-'+a.BANKID3 +(select BANKNAME from [dbo].[BANK] where bankno =a.BANKID2) BANKNAME
from [dbo].[BANK400] a  where  BROKER= '" + FIRM + @"' and ACTNO= '" + ACTNO + "' and CURCY='" + CURRENCY + "'  ";


        SqlDataAdapter adp;
        adp = new SqlDataAdapter(sql, conn);
        adp.Fill(dtIB);


        dsReturn.Tables.Add(dtIB);
        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();

        doc.InnerXml = dsReturn.GetXml();

        return doc;

    }

    [WebMethod]
    public string WS_getStockPrice(string kindid)
    {
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getStockPrice]";
        string price = "";
        //判斷目前時間是否超過MOBGW啟動時間
        //並且超過小於MOBGW關閉時間,才可以查MOBGW,其餘透過DB查 
        if (!chkDBTime())
        {

            FunctionHandler fh = new FunctionHandler();
            string[] OriginalstrData = fh.getMOB_StockPrice(kindid);
            if (OriginalstrData != null)
            {
                if (OriginalstrData[0] == "0")
                {

                }
                else
                    price = String.Format("{0:####0.####}", (decimal.Parse(OriginalstrData[0].Split('@')[2])));
            }
        }
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + kindid);
        return price;

    }
    [WebMethod]
    public System.Xml.XmlDocument WS_getGreeksQuery(string FIRM, string ACTNO, string CURRENCY, string costrate, string Volatility, string tempqty, bool bolStockPrice)
    {
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getGreeksQuery]";

        FunctionHandler fh = new FunctionHandler();
        DataSet dsReturn = new DataSet("Return");
        try
        {
            //getActno(ref FIRM, ref ACTNO);
            DataTable ForeignAccountMaster = getForeignAccountMaster();
            System.Xml.XmlNode s = WS_getReal_UnLiquidation(FIRM, ACTNO, CURRENCY);
            DataSet ds = new DataSet();
            System.Xml.XmlDocument xmlDoc = new System.Xml.XmlDocument();
            xmlDoc.LoadXml(s.OuterXml);
            System.Xml.XmlNodeReader xmlReader = new System.Xml.XmlNodeReader(xmlDoc);
            ds.ReadXml(xmlReader);
            if (ds.Tables.Count > 0)
            {
                foreach (DataRow dr in ds.Tables["UnLiquidationMain"].Rows)
                {
                    if (dr["productKind"].ToString() == "1" || dr["productKind"].ToString() == "2")
                    {
                        double strikeprice = 0;
                        double.TryParse(dr["stkprc"].ToString(), out strikeprice);
                        double matchqty = 0;
                        double.TryParse(dr["TotalOTQTY"].ToString(), out matchqty);
                        double realPrice = 0;
                        double.TryParse(dr["realPrice"].ToString(), out realPrice);
                        double iamt = 0;
                        double.TryParse(dr["iamt"].ToString(), out iamt);
                        double mamt = 0;
                        double.TryParse(dr["mamt"].ToString(), out mamt);
                        string cp = dr["callput"].ToString();
                        if (cp == "N")
                            cp = "F";
                        addpositionData(dr["BS"].ToString(), dr["ProductId"].ToString(), dr["MKTCOMNO"].ToString()
                            , dr["COMYM"].ToString(), cp, strikeprice, dr["productName"].ToString(),
                            matchqty, realPrice, "Y", iamt, mamt, 0, false, costrate, Volatility, bolStockPrice, ref ForeignAccountMaster);
                    }
                }
            }
            foreach (string data in tempqty.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries))
            {
                string[] tempvalue = data.Split('@');
                string ProductId = tempvalue[0];

                string cp = tempvalue[4];
                if (cp == "")
                    cp = "F";
                double strikeprice = 0;
                double.TryParse(tempvalue[5], out strikeprice);
                double qty = 0;
                double.TryParse(tempvalue[1], out qty);
                addpositionData("B", ProductId, ProductId.Substring(0, 3)
                    , tempvalue[3], cp, strikeprice, tempvalue[2],
                    0, 0, "Y", 0, 0, qty, true, costrate, Volatility, bolStockPrice, ref ForeignAccountMaster);
            }
            dsReturn.Tables.Add(ForeignAccountMaster);

        }
        catch (Exception ex)
        {
            DataTable dtError = new DataTable("result");
            dtError.Columns.Add("Error");
            dtError.Columns.Add("ErrorCode");
            dtError.Rows.Add(new object[] { "WSError:" + ex.Message, "0005" });
            dsReturn.Tables.Add(dtError);
        }
        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();
        doc.InnerXml = dsReturn.GetXml();
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + FIRM + ACTNO + CURRENCY + costrate + Volatility + tempqty + bolStockPrice.ToString());
        return doc;
    }
    private void ComputerNewGreek(DataRow dr, string costrate, string Volatility)
    {
        try
        {
            double douTimeValue;
            double douIncluded = 0;
            double Delta = 0, DeltaValue = 0, Gamma = 0, GammaValue = 0, Theta = 0, ThetaValue = 0, Vega = 0, VegaValue = 0;
            double MatchQty = dr["BS"].ToString() == "B" ? (double)dr["computeqty"] : -(double)dr["computeqty"];
            double Cvalue = (double)dr["Cvalue"] * (double)dr["ExRate"];
            double MarketPrice = (double)dr["MarketPrice"];
            double TargetPrice = (double)dr["TargetPrice"];
            double StrickPrice = (double)dr["StrickPrice"];

            //期貨
            if (dr["CP"].ToString().ToUpper() == "F")
            {
                //dr["Delta"] = (MatchQty) * Cvalue / 50;
                //dr["DeltaValue"] = (MatchQty) * Cvalue * MarketPrice;

                //dr["Delta"] = (MatchQty) * Cvalue / (50 * MarketPrice);
                //dr["DeltaValue"] = (MatchQty) * Cvalue / (50 * MarketPrice) * MarketPrice;.
                //修改需求公式
                //dr["Delta"]      = (MarketPrice * Cvalue) / (TargetPrice * 50);
                //dr["DeltaValue"] = (MarketPrice * Cvalue) / (TargetPrice * 50) * MatchQty;

                //20161017修改需求公式
                if (dr["Comm"].ToString() == "TXF")
                    dr["Delta"] = 4 * MatchQty;
                else
                    dr["Delta"] = (MarketPrice * Cvalue) / (TargetPrice * 50) * MatchQty;
                dr["DeltaValue"] = (MarketPrice * Cvalue) / (TargetPrice * 50) * MatchQty * (TargetPrice * 50);
            }
            else
            {
                dr["Prenuim"] = MarketPrice * MatchQty * Cvalue;
                double x = StrickPrice;
                double r = double.Parse(costrate);
                double t = (double)dr["days"] / 365;
                double v = 0;
                double ratio = double.Parse(Volatility);
                if (dr["CP"].ToString().ToUpper() == "C")
                {
                    douIncluded = Math.Max(0, TargetPrice - StrickPrice);
                    douTimeValue = (MarketPrice - douIncluded) * MatchQty * Cvalue;//
                    dr["TimeValue"] = dr["BS"].ToString() == "B" ? douTimeValue < 0 ? douTimeValue : -douTimeValue : douTimeValue;

                    v = Common.TSCRisk.AACALLIMV(TargetPrice, x, r, t, MarketPrice);
                    if (ratio != 0)
                        v = v * (1 + ratio / 100);
                    Delta = Common.TSCRisk.AAC_DELTA(TargetPrice, x, r, v, t) * MatchQty;
                    Gamma = Common.TSCRisk.AAC_GAMMA(TargetPrice, x, r, v, t) * MatchQty;
                    Theta = Common.TSCRisk.AAC_THETA(TargetPrice, x, r, v, t) * MatchQty;
                    Vega = Common.TSCRisk.AAC_VEGA(TargetPrice, x, r, v, t) / 100 * MatchQty;
                }
                else if (dr["CP"].ToString().ToUpper() == "P")
                {
                    douIncluded = Math.Max(0, StrickPrice - TargetPrice);
                    douTimeValue = (MarketPrice - douIncluded) * MatchQty * Cvalue;//
                    dr["TimeValue"] = dr["BS"].ToString() == "B" ? douTimeValue < 0 ? douTimeValue : -douTimeValue : douTimeValue;

                    v = Common.TSCRisk.AAPUTIMV(TargetPrice, x, r, t, MarketPrice);
                    if (ratio != 0)
                        v = v * (1 + ratio / 100);
                    Delta = Common.TSCRisk.AAP_DELTA(TargetPrice, x, r, v, t) * MatchQty;
                    Gamma = Common.TSCRisk.AAP_GAMMA(TargetPrice, x, r, v, t) * MatchQty;
                    Theta = Common.TSCRisk.AAP_THETA(TargetPrice, x, r, v, t) * MatchQty;
                    Vega = Common.TSCRisk.AAP_VEGA(TargetPrice, x, r, v, t) / 100 * MatchQty;
                }

                Delta = Delta.ToString().Substring(0, 1) == "不" ? 0 : Delta;
                Gamma = Gamma.ToString().Substring(0, 1) == "不" ? 0 : Gamma;
                Theta = Theta.ToString().Substring(0, 1) == "不" ? 0 : Theta;
                Vega = Vega.ToString().Substring(0, 1) == "不" ? 0 : Vega;

                DeltaValue = Delta * TargetPrice * Cvalue;
                GammaValue = Gamma * TargetPrice * Cvalue;
                ThetaValue = Theta * Cvalue;
                VegaValue = Vega * Cvalue;

                dr["Delta"] = Delta;
                dr["DeltaValue"] = DeltaValue;
                dr["Gamma"] = Gamma;
                dr["GammaValue"] = GammaValue;
                dr["Theta"] = Theta;
                dr["ThetaValue"] = ThetaValue;
                dr["Vega"] = Vega;
                dr["VegaValue"] = VegaValue;
            }

        }
        catch (Exception ex)
        {
            throw (ex);
        }
    }
    private void addpositionData(string BS, string Symbol, string Comm, string Settlement_Month, string CP, double dStrickPrice, string ProductName, double MatchQty,
        double MktPrice, string Flag, double iamt, double mamt, double tempqty, bool bolTemp, string costrate, string Volatility, bool bolStockPrice, ref DataTable ForeignAccountMaster)
    {
        double cvalues = 0;
        bool bolAdd = false;
        string TargetId = "";
        DataRow dr = ForeignAccountMaster.Rows.Find(new string[] { Comm, Settlement_Month, CP, dStrickPrice.ToString(), "Y" });
        if (dr == null)
            bolAdd = true;
        if (bolAdd)
        {
            dr = ForeignAccountMaster.NewRow();
            dr["Comm"] = Comm;
            dr["Settlement_Month"] = Settlement_Month;
            dr["CP"] = CP;
            dr["StrickPrice"] = dStrickPrice;
            dr["BS"] = BS;
            dr["MatchQty"] = MatchQty;
            dr["SymbolName"] = ProductName;
            dr["Symbol"] = Symbol;
            if (MktPrice == 0)
            {
                double.TryParse(WS_getMatchPrice(Symbol), out MktPrice);
            }
            dr["MarketPrice"] = MktPrice;

            DataTable dtProduct = new DataTable();
            SqlConnection conn = new SqlConnection(ASTR_ConfigConnection3);
            string sql = @" 
            Declare @COMTYPE varchar(1),@KINDID varchar(3),@PRODUCTID varchar(20),@ENDDAY varchar(8),@TARGETID varchar(10),@CVALUE decimal(16,4)
set @COMTYPE='{0}'
set  @KINDID='{1}' 
set @PRODUCTID='{2}'
if(@COMTYPE='0')
begin 
	select @CVALUE =contract_size from AECONFIGDB.AEConfigDB.dbo.P09MF where kind_id=@KINDID
	select @ENDDAY=end_date from AECONFIGDB.AEConfigDB.dbo.P08MF where prod_id_s=@PRODUCTID 
end
else if(@COMTYPE='1')
begin 
	select @CVALUE =contract_size,@TARGETID=Futcomno from AECONFIGDB.AEConfigDB.dbo.P09M   where kind_id=@KINDID
	select  @TARGETID=kind_id from AECONFIGDB.AEConfigDB.dbo.P09MF   where COMMODITY=@TARGETID 
	select top 1 @TARGETID=prod_id_s from AECONFIGDB.AEConfigDB.dbo.P08MF where SUBSTRING(prod_id_s,1,3)=@TARGETID order by settle_date  
	select @ENDDAY=end_date from AECONFIGDB.AEConfigDB.dbo.P08M where prod_id_s=@PRODUCTID
end 
select @ENDDAY ENDDAY,@TARGETID TARGETID ,@CVALUE CVALUE";
            string comtype = "0";
            if (CP != "F")
                comtype = "1";
            SqlDataAdapter adp;
            adp = new SqlDataAdapter(string.Format(sql, new object[] { comtype, Comm, Symbol }), conn);
            adp.Fill(dtProduct);
            int days = 0;
            if (dtProduct.Rows.Count > 0)
            {
                TargetId = dtProduct.Rows[0]["TARGETID"].ToString();
                double.TryParse(dtProduct.Rows[0]["CVALUE"].ToString(), out cvalues);
                string date = dtProduct.Rows[0]["ENDDAY"].ToString();
                DateTime dtday = new DateTime(int.Parse(date.Substring(0, 4)), int.Parse(date.Substring(4, 2)), int.Parse(date.Substring(6, 2)));
                //int.Parse(date)-DateTime.Now.ToString("yyyyMMdd")
                try
                {
                    days = int.Parse(date) - int.Parse(DateTime.Now.ToString("yyyyMMdd")) + 1;
                }
                catch (Exception)
                {
                }

            }
            dr["TargetId"] = TargetId;
            dr["Flag"] = Flag;
            dr["Days"] = days;
            dr["Cvalue"] = cvalues;
            dr["Exrate"] = 1;
            dr["iamt"] = iamt;
            dr["mamt"] = mamt;
            string price = "";
            if (CP == "C" || CP == "P")
            {
                if (Flag == "Y" && TargetId.Length > 3)
                {
                    //switch (Comm)
                    //{
                    //    case "TX1":
                    //    case "TX2":
                    //    case "TX4":
                    //    case "TX5":
                    //        string StrickPrice =  WS_getMatchPrice(TargetId);
                    //        if (StrickPrice.Length > 2)
                    //            StrickPrice = StrickPrice.Substring(0, 2);


                    //        //string priceCall = AEFutureMaster.WSDataSet.WS_MatchPrice("1", getProductId("2", Comm, Settlement_Month, StrickPrice, "C"));
                    //        //string pricePut = AEFutureMaster.WSDataSet.WS_MatchPrice("1", getProductId("2", Comm, Settlement_Month, StrickPrice, "P"));
                    //        //douTheoryPrice = double.Parse(StrickPrice) + double.Parse(priceCall) - double.Parse(pricePut);

                    //        dr["TargetPrice"] = 0;
                    //        break;
                    //    default:

                    if (bolStockPrice)
                        price = WS_getStockPrice(TargetId.Substring(0, 3));
                    else
                        price = WS_getMatchPrice(TargetId);
                    dr["TargetPrice"] = price.Trim() != "" ? price : "0";
                    //        break;
                    //}
                }
            }
            else if (CP == "F")
            {
                TargetId = "MXF" + dr["Symbol"].ToString().Substring(3, 2);
                price = WS_getMatchPrice(TargetId);
                dr["TargetPrice"] = price.Trim() != "" ? price : "0";
            }

        }
        if (bolTemp)
            dr["AddQty"] = tempqty;


        if (Symbol != "")
        {
            if (bolAdd)
                ForeignAccountMaster.Rows.Add(dr);
            ComputerNewGreek(dr, costrate, Volatility);
        }
    }
    private DataTable getForeignAccountMaster()
    {
        DataTable ForeignAccountMaster = new DataTable("ForeignAccountMaster");
        ForeignAccountMaster.Columns.Add("Comm", typeof(string));
        ForeignAccountMaster.Columns.Add("Settlement_Month", typeof(string));
        ForeignAccountMaster.Columns.Add("CP", typeof(string));
        ForeignAccountMaster.Columns.Add("StrickPrice", typeof(double)).DefaultValue = 0;
        ForeignAccountMaster.Columns.Add("MatchQty", typeof(double)).DefaultValue = 0;
        ForeignAccountMaster.Columns.Add("AddQty", typeof(double)).DefaultValue = 0;
        ForeignAccountMaster.Columns.Add("computeqty", typeof(double)).Expression = "AddQty+MatchQty";
        ForeignAccountMaster.Columns.Add("MarketPrice", typeof(double)).DefaultValue = 0;
        ForeignAccountMaster.Columns.Add("ExRate", typeof(double)).DefaultValue = 0;

        ForeignAccountMaster.Columns.Add("Symbol", typeof(string));
        ForeignAccountMaster.Columns.Add("SymbolName", typeof(string));
        ForeignAccountMaster.Columns.Add("TargetId", typeof(string));
        ForeignAccountMaster.Columns.Add("TargetPrice", typeof(double)).DefaultValue = 0;
        ForeignAccountMaster.Columns.Add("BS", typeof(string));
        ForeignAccountMaster.Columns.Add("Delta", typeof(double)).DefaultValue = 0;
        ForeignAccountMaster.Columns.Add("DeltaValue", typeof(double)).DefaultValue = 0;
        ForeignAccountMaster.Columns.Add("Gamma", typeof(double)).DefaultValue = 0;
        ForeignAccountMaster.Columns.Add("GammaValue", typeof(double)).DefaultValue = 0;
        ForeignAccountMaster.Columns.Add("Theta", typeof(double)).DefaultValue = 0;
        ForeignAccountMaster.Columns.Add("ThetaValue", typeof(double)).DefaultValue = 0;
        ForeignAccountMaster.Columns.Add("Vega", typeof(double)).DefaultValue = 0;
        ForeignAccountMaster.Columns.Add("VegaValue", typeof(double)).DefaultValue = 0;
        ForeignAccountMaster.Columns.Add("TimeValue", typeof(double)).DefaultValue = 0;
        ForeignAccountMaster.Columns.Add("Days", typeof(double)).DefaultValue = 0;
        ForeignAccountMaster.Columns.Add("Cvalue", typeof(double)).DefaultValue = 0;
        ForeignAccountMaster.Columns.Add("ShowMatchQty", typeof(string));
        ForeignAccountMaster.Columns.Add("ShowDeltaValue", typeof(double)).DefaultValue = 0;
        ForeignAccountMaster.Columns.Add("ShowGammaValue", typeof(double)).DefaultValue = 0;
        ForeignAccountMaster.Columns.Add("Prenuim", typeof(double)).DefaultValue = 0;
        ForeignAccountMaster.Columns.Add("Iamt", typeof(double)).DefaultValue = 0;
        ForeignAccountMaster.Columns.Add("Mamt", typeof(double)).DefaultValue = 0;
        ForeignAccountMaster.Columns.Add("IsCheck", typeof(bool));
        ForeignAccountMaster.Columns.Add("Flag", typeof(string));

        ForeignAccountMaster.Columns["computeqty"].DefaultValue = "0";
        ForeignAccountMaster.Columns["Delta"].DefaultValue = "0";
        ForeignAccountMaster.Columns["DeltaValue"].DefaultValue = "0";
        ForeignAccountMaster.Columns["Gamma"].DefaultValue = "0";
        ForeignAccountMaster.Columns["GammaValue"].DefaultValue = "0";
        ForeignAccountMaster.Columns["Theta"].DefaultValue = "0";
        ForeignAccountMaster.Columns["ThetaValue"].DefaultValue = "0";
        ForeignAccountMaster.Columns["Vega"].DefaultValue = "0";
        ForeignAccountMaster.Columns["VegaValue"].DefaultValue = "0";
        ForeignAccountMaster.Columns["TimeValue"].DefaultValue = "0";

        ForeignAccountMaster.PrimaryKey = new DataColumn[] { ForeignAccountMaster.Columns["Comm"], ForeignAccountMaster.Columns["Settlement_Month"], 
            ForeignAccountMaster.Columns["CP"], ForeignAccountMaster.Columns["StrickPrice"], ForeignAccountMaster.Columns["Flag"]};
        ForeignAccountMaster.Columns["ShowMatchQty"].Expression = "IIF(BS='B', MatchQty, '('+MatchQty+')')";

        ForeignAccountMaster.Columns["ShowDeltaValue"].Expression = "IIF(IsCheck=true, DeltaValue, 0)";
        ForeignAccountMaster.Columns["ShowGammaValue"].Expression = "IIF(IsCheck=true, GammaValue, 0)";
        ForeignAccountMaster.Columns["IsCheck"].DefaultValue = "true";
        return ForeignAccountMaster;
    }





    [WebMethod]
    public System.Xml.XmlDocument WS_get_Combine(string Type, string company, string ACTNO
        , string Comno1, string Comym1, string strikePrice1, string Callput1, string bs1, string qty1, string Comno2, string Comym2, string strikePrice2
        , string Callput2, string bs2, string qty2

        )
    {
        string key = Type + "_" + company + "_" + ACTNO + "_" + Comno1 + "_" + Comym1 + "_" + strikePrice1 + "_" + Callput1 + "_" + bs1 + "_" + qty1 + "_" + Comno2 + "_" + Comym2 + "_" + strikePrice2 + "_" + Callput2 + "_" + bs2 + "_" + qty2;
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_get_Combine]";

        DataSet dsReturn = new DataSet("Return");
        try
        {
            getActno(ref company, ref ACTNO);

            MobDataParse mobData = new MobDataParse();
            //判斷目前時間是否超過MOBGW啟動時間
            //並且超過小於MOBGW關閉時間,才可以查MOBGW,其餘透過DB查

            // if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_OpenTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_CloseTime"].ToString()))
            if (!chkDBTime())
            {

                FunctionHandler fh = new FunctionHandler();

                string[] combineData = new string[1];


                //商品代號1	Comno1	X(7)    
                Comno1 = Comno1.Trim().PadRight(7, ' ');
                //商品年月1	Comym1	X(6)   
                Comym1 = Comym1.Trim().PadRight(6, ' ');
                //履約價1	Stkprc1	9(5)V9(4)
                decimal ds1 = 0;
                decimal.TryParse(strikePrice1.Trim(), out ds1);
                strikePrice1 = ds1.ToString("00000.0000").Replace(".", "").PadLeft(9, '0');
                //CALL/PUT1	Callput1	X(1) 
                Callput1 = Callput1.PadRight(1, ' ');
                //買賣別1	BS1	X(1)         
                bs1 = bs1.Trim().PadRight(1, ' ');
                //數量1	Qty1	9(5)     
                qty1 = qty1.Trim().PadLeft(5, '0');
                //商品代號2	Comno2	X(7)    
                Comno2 = Comno2.Trim().PadRight(7, ' ');
                //商品年月2	Comym2	X(6)   
                Comym2 = Comym2.Trim().PadRight(6, ' ');
                //履約價2	Stkprc2	9(5)V9(4)
                decimal ds2 = 0;
                decimal.TryParse(strikePrice2.Trim(), out ds2);
                strikePrice2 = ds2.ToString("00000.0000").Replace(".", "").PadLeft(9, '0');
                //CALL/PUT2	Callput2	X(1) 
                Callput2 = Callput2.PadRight(1, ' ');
                //買賣別2	BS2	X(1)         
                bs2 = bs2.PadRight(1, ' ');
                //數量1	Qty2	9(5)     
                qty2 = qty2.Trim().PadLeft(5, '0');




                combineData[0] = Type + "00010001" + company + ACTNO + Comno1 + Comym1 + strikePrice1 + Callput1 + bs1 + qty1 + Comno2 + Comym2 + strikePrice2 + Callput2 + bs2 + qty2;

                string[] OriginalstrData = fh.getMOB_Combine(ACTNO, company, combineData);
                if (OriginalstrData != null)
                {

                    mobData.parseMobInfoData(OriginalstrData);

                    string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
                    for (int idx = 0; idx < OriginalstrData.Length; idx++)
                    {

                    }
                }

                DataTable MOBCombineData = mobData.GetMOBCombineDT();





                if (MOBCombineData != null)
                {
                    MOBCombineData.TableName = "CombineData";
                    dsReturn.Tables.Add(MOBCombineData);
                }

            }
            else
            {

                DataTable dtError = new DataTable("result");
                dtError.Columns.Add("Error");
                dtError.Columns.Add("ErrorCode");
                dtError.Rows.Add(new object[] { ErrorMessage.MSG0006, "0004" });
                dsReturn.Tables.Add(dtError);
            }



        }
        catch (Exception ex)
        {

            DataTable dtError = new DataTable("result");
            dtError.Columns.Add("Error");
            dtError.Columns.Add("ErrorCode");
            dtError.Rows.Add(new object[] { "WSError:" + ex.Message, "0005" });
            dsReturn.Tables.Add(dtError);
        }
        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();

        doc.InnerXml = dsReturn.GetXml();
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + key);
        return doc;

    }





    ////高風險查詢低於25% //V1.0.0.23 added by peter on 20170110
    [WebMethod]
    public System.Xml.XmlDocument WS_getRateForDate(string DATE)
    {
        string date = "[" + DateTime.Now.ToString("yyyyMMddHHmmssfff") + "]" + BOSHistoryQuery.GetIP() + "[WS_getRateForDate]";
        DataSet dsReturn = new DataSet("Return");
        try
        {


            MobDataParse mobData = new MobDataParse();
            //判斷目前時間是否超過MOBGW啟動時間
            //並且超過小於MOBGW關閉時間,才可以查MOBGW,其餘透過DB查
            DataTable dtWithdraw = new DataTable();
            //if (!closeday && DateTime.Now > DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_OpenTime"].ToString()) && DateTime.Now < DateTime.Parse(ConfigurationSettings.AppSettings["MOBGW_CloseTime"].ToString()))
            //{

            try
            {

                FunctionHandler fh = new FunctionHandler();


                string[] OriginalstrData = fh.getRateForDate(DATE);
                if (OriginalstrData != null)
                {

                    mobData.parseMobInfoData(OriginalstrData);

                    string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
                    for (int idx = 0; idx < OriginalstrData.Length; idx++)
                    {
                    }
                }
                if (mobData.mdt_RateForDateData != null)
                {


                    dsReturn.Tables.Add(mobData.mdt_RateForDateData);
                }

            }
            catch (Exception ex)
            {
                BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_getRateForDate]" + ex.Message);
                DataTable dtError = new DataTable("result");
                dtError.Columns.Add("Error");
                dtError.Columns.Add("ErrorCode");
                dtError.Rows.Add(new object[] { "WSError:" + ErrorMessage.MSG0010, "0010" });
                dsReturn.Tables.Add(dtError);

            }



        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[WS_getRateForDate]" + ex.Message);
            DataTable dtError = new DataTable("result");
            dtError.Columns.Add("Error");
            dtError.Columns.Add("ErrorCode");
            dtError.Rows.Add(new object[] { "WSError:" + ex.Message, "0005" });
            dsReturn.Tables.Add(dtError);
        }
        System.Xml.XmlDocument doc = new System.Xml.XmlDocument();

        doc.InnerXml = dsReturn.GetXml();
        BOSHistoryQuery._LM.WriteLog("WS_LOG", date + " " + DATE);
        return doc;

    }


    public static string GetIP()
    {
        return "[" + HttpContext.Current.Request["REMOTE_ADDR"] + ":" + HttpContext.Current.Request["REMOTE_PORT"] + "]";
    }

}

