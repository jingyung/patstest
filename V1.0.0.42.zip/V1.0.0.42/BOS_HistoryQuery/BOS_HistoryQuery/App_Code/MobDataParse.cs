﻿using System;
using System.Collections.Generic;

using System.Web;
using System.Text;
using System.Data;


/// <summary>
/// MobDataParse 的摘要描述
/// </summary>
public class MobDataParse
{

    private DataTable mdt_RealPart;
    private DataTable mdt_RealPartMix;
    private DataTable mdt_UnLiquidationDetail;
    private DataTable mdt_PositionData;
    private DataTable mdt_UnLiquidationMain;

    private DataTable mdt_TotalUnLiquidation;

    private DataTable mdt_FutureData;
    private DataTable mdt_OptionData;
    private DataTable mdt_translate_values;

    public DataTable mdt_MOBCurrentMargin;
    public DataTable mdt_MOBCurrentBalance;
    public DataTable mdt_MOBCombineData;
    public DataTable mdt_CurrentEquity;
    public DataTable mdt_CurrentEquityCollect;

    public DataTable mdt_Withdraw;

    public DataTable mdt_OrderWithdraw;

    public DataTable mdt_RateData; //高風險
    public DataTable mdt_RateForDateData; //高風險25%
    public bool bolCombine;
    //private DataTable mdt_MOBCurrenetMarginRapid;

    public MobDataParse()
    {

        //
        // TODO: 在此加入建構函式的程式碼
        //
        //-----取得初始資料------
        //this.getINIData();

        //初始化Table
        initializedRealPart();
        initializedRealPartMix();
        initializedUnLiquidationDetail();
        initializedPositionData();
        initializedUnLiquidationMain();
        initializedMOBCombineData();

        initializedCurrentEquity();
        initializedCurrentEquityCollect();
        initializedWithdraw();
        initializedOrderWithdraw();
        initializedTotalUnLiquidation();

        initializedRateData();
        initializedRateForDateData();
    }

    public void parseMobInfoData(string OriginalstrData)
    {
        string[] str = new string[1];
        str[0] = OriginalstrData;
        parseMobInfoData(str);
    }

    /// <summary>
    /// 拆解行情資訊
    /// </summary>
    /// <param name="strData">The STR data.</param>
    // public void parseMobInfoData(string strData)
    public void parseMobInfoData(string[] OriginalstrDataArry)
    {

        Int32 idx = 0;

        for (idx = 0; idx < OriginalstrDataArry.Length; idx++)
        {
            string OriginalstrData = OriginalstrDataArry[idx];
            try
            {

                //mobj_InfoLog.WriteEntryData(OriginalstrData);

                string strData = OriginalstrData;// + OriginalstrData.Substring(28); 沒有seq

                //依 strData頭碼分派資料給個 unMOB                
                byte[] header = Encoding.Default.GetBytes(OriginalstrData.Substring(0, 1));

                switch (header[0].ToString().Trim())
                {
                    case "81":   // 0x51保證金查詢 回覆

                        bool bolHaveData_cm = unCurrentMargin_MobInfo(strData);

                        break;
                    case "19":       //0x13 未平倉查詢回覆


                        Boolean bolHaveData = false;
                        int BodyCount = Convert.ToInt16(strData.Substring(23, 2));

                        Byte[] byteLiquidation = new byte[Encoding.Default.GetBytes(strData).Length];
                        Array.Copy(Encoding.Default.GetBytes(strData), 0, byteLiquidation, 0, byteLiquidation.Length);
                        string[] strProducts = new string[BodyCount];

                        for (int i = 0; i < BodyCount; i++)
                        {

                            strProducts[i] = SubStr(strData, i * 163 + 59, 10).Trim();

                            Array.Copy(Encoding.Default.GetBytes("".PadRight(10, ' ')), 0, byteLiquidation, i * 163 + 25 + 34, 10);

                        }
                        bolHaveData = unLiquidation_MobInfo(Encoding.Default.GetString(byteLiquidation), strProducts);
                        break;

                    case "83":       // 0x53當日損益查詢回覆

                        bool bolHaveData_cb = CurrentBalance_MobInfo(strData);
                        break;

                    case "87":   //0x57 即時部位查詢回覆  單式查詢  混合查詢 分別填入兩個不同的table
                        Boolean bolhaveData_real = false;
                        Boolean bolhaveData_realMix = false;

                        BodyCount = Convert.ToInt16(strData.Substring(23, 2));
                        if (BodyCount > 0)
                        {
                            Byte[] byteCurrentPosition = new byte[Encoding.Default.GetBytes(strData).Length];
                            Array.Copy(Encoding.Default.GetBytes(strData), 0, byteCurrentPosition, 0, byteCurrentPosition.Length);
                            string strProduct = "";


                            strProduct = SubStr(strData, 38, 10).Trim();

                            Array.Copy(Encoding.Default.GetBytes("".PadRight(10, ' ')), 0, byteCurrentPosition, 38, 10);


                            if (strData.Substring(24, 1) == "1")
                            {
                                bolhaveData_real = ucCurrentPosition_MobInfo(Encoding.Default.GetString(byteCurrentPosition), strProduct);

                            }
                            if (strData.Substring(24, 1) == "2")
                            {
                                bolhaveData_realMix = ucCurrentPositionMix_MobInfo(Encoding.Default.GetString(byteCurrentPosition));

                            }
                        }
                        break;

                    //case "98":   //0x62 拆組                     
                    //    if (strData.Substring(17, 2) == "00")
                    //    {
                    //        //批號_流水號
                    //        //strData.Substring(1, 8) + "_" + strData.Substring(13, 4) + "申請成功!!"
                    //    }
                    //    else if (strData.Substring(17, 2) == "99")
                    //    {
                    //        //批號_流水號
                    //        //strData.Substring(1, 8) + "_" + strData.Substring(13, 4) + "申請失敗!!"
                    //    }
                    //    break;


                    case "98":  //0x62 拆組     98
                    case "101":  //0x65 拆組     101

                        //for (int i = 1; i <= int.Parse(strData.Substring(13, 4)); i++)
                        //{
                        strData = strData.Substring(2);//systex head(1)+psg raw
                        DataRow dr = mdt_MOBCombineData.NewRow();



                        dr["ADJNO"] = strData.Substring(1, 8);

                        dr["COUNT"] = strData.Substring(9, 4);

                        dr["SEQNO"] = strData.Substring(13, 4);



                        if (strData.Substring(17, 2) == "00")
                        {

                            dr["STATUS"] = "申請成功!!";

                        }

                        else if (strData.Substring(17, 2) == "99")
                        {

                            dr["STATUS"] = "申請失敗!!";

                        }



                        mdt_MOBCombineData.Rows.Add(dr);
                        //}
                        break;
                    case "34":  //0x22 當日損益查詢         
                        //if (strData.Substring(9, 1) != "0")
                        if (strData.Substring(19, 1) != "0")
                        {
                            strData = strData.Substring(10);
                            string abbr = SubStr(strData, 90, 30).Trim();


                            Byte[] byteEquity = new byte[Encoding.Default.GetBytes(strData).Length];
                            Array.Copy(Encoding.Default.GetBytes(strData), 0, byteEquity, 0, byteEquity.Length);
                            Array.Copy(Encoding.Default.GetBytes("".PadRight(30, ' ')), 0, byteEquity, 90, 30);
                            strData = Encoding.Default.GetString(byteEquity);
                            DataRow drNew = mdt_CurrentEquity.NewRow();
                            drNew["COMPANY"] = strData.Substring(10, 7);
                            drNew["ACTNO"] = strData.Substring(17, 7);
                            drNew["OFFSETDATE"] = strData.Substring(24, 8);
                            drNew["OPTTRDDT"] = strData.Substring(32, 8);
                            drNew["TRD_ORDNO"] = strData.Substring(40, 8);
                            drNew["TRDORDNO"] = strData.Substring(40, 6);
                            drNew["TRDLINESNO"] = strData.Substring(46, 1);
                            drNew["TRDSEQNO"] = strData.Substring(47, 1);
                            drNew["OPT_ORDNO"] = strData.Substring(48, 8);
                            drNew["productid"] = strData.Substring(56, 10);
                            drNew["COMTYPE"] = strData.Substring(66, 1);
                            drNew["COMNO"] = strData.Substring(67, 7);
                            drNew["COMYM"] = strData.Substring(74, 6);
                            drNew["STKPRC"] = decimal.Parse(strData.Substring(80, 9)) / 10000;
                            drNew["CALLPUT"] = strData.Substring(89, 1);
                            drNew["ABBR"] = abbr;
                            drNew["PS"] = strData.Substring(120, 1);
                            drNew["TRDPRC1"] = decimal.Parse(strData.Substring(121, 10)) / 10000;
                            drNew["OPTPRIC1"] = decimal.Parse(strData.Substring(131, 10)) / 10000;
                            drNew["OFFSETQTY"] = int.Parse(strData.Substring(141, 5));
                            drNew["CURRENCY"] = strData.Substring(146, 3);
                            drNew["OSPRTLOS"] = decimal.Parse(strData.Substring(149, 15)) / 100;
                            drNew["TRD_charge"] = decimal.Parse(strData.Substring(164, 15)) / 100;
                            drNew["TRD_tax"] = decimal.Parse(strData.Substring(179, 15)) / 100;
                            drNew["OPT_charge"] = decimal.Parse(strData.Substring(194, 15)) / 100;
                            drNew["OPT_tax"] = decimal.Parse(strData.Substring(209, 15)) / 100;
                            drNew["charge"] = decimal.Parse(strData.Substring(224, 15)) / 100;
                            drNew["tax"] = decimal.Parse(strData.Substring(239, 15)) / 100;
                            drNew["Equity"] = decimal.Parse(strData.Substring(254, 15)) / 100;
                            drNew["ORDTYPE"] = strData.Substring(269, 1);
                            drNew["spread"] = strData.Substring(270, 1);
                            drNew["ProductName"] = BOSHistoryQuery.NewProductNameTransfer(drNew["abbr"].ToString().Trim(), drNew["comym"].ToString().Trim(), drNew["stkprc"].ToString().Trim(), drNew["comtype"].ToString().Trim(), drNew["callput"].ToString().Trim())[1];

                            if (mdt_CurrentEquityCollect.Rows.Find(new object[] { drNew["COMPANY"].ToString(), drNew["ACTNO"].ToString(), drNew["OFFSETDATE"].ToString(), drNew["productid"].ToString(), drNew["ordtype"].ToString(), drNew["CURRENCY"] }) == null)
                            {
                                DataRow drNewCollect = mdt_CurrentEquityCollect.NewRow();
                                drNewCollect["COMPANY"] = drNew["COMPANY"].ToString();
                                drNewCollect["ACTNO"] = drNew["ACTNO"].ToString();
                                drNewCollect["OFFSETDATE"] = drNew["OFFSETDATE"].ToString(); //平倉日期
                                drNewCollect["productid"] = drNew["productid"].ToString();
                                drNewCollect["ordtype"] = drNew["ordtype"].ToString();     //類型
                                drNewCollect["CURRENCY"] = drNew["CURRENCY"].ToString();  //幣別 
                                mdt_CurrentEquityCollect.Rows.Add(drNewCollect);
                            }
                            mdt_CurrentEquity.Rows.Add(drNew);

                        }
                        else
                        {

                        }
                        break;
                    case "35":  //0x23 出入金查詢回覆
                        //if (strData.Substring(9, 1) != "0")
                        if (strData.Substring(19, 1) != "0")
                        {
                            strData = strData.Substring(10);
                            DataRow drNewWithdraw = this.mdt_Withdraw.NewRow();

                            drNewWithdraw["FIRM"] = strData.Substring(10, 7);
                            drNewWithdraw["ACTNO"] = strData.Substring(17, 7);
                            drNewWithdraw["BANKNO"] = strData.Substring(24, 7);
                            drNewWithdraw["BANKACTNO"] = strData.Substring(31, 16);
                            drNewWithdraw["TRDDT"] = strData.Substring(47, 8);
                            drNewWithdraw["CODE"] = strData.Substring(55, 1);

                            drNewWithdraw["CODE_NAME"] = drNewWithdraw["CODE"].ToString() == "1" ? "入金" : "出金";
                            drNewWithdraw["CURRENCY"] = strData.Substring(56, 3);

                            drNewWithdraw["AMT"] = decimal.Parse(strData.Substring(59, 15)) / 100;
                            drNewWithdraw["MDATE"] = strData.Substring(74, 8);
                            drNewWithdraw["MTIME"] = strData.Substring(82, 8);
                            mdt_Withdraw.Rows.Add(drNewWithdraw);

                        }
                        break;
                    case "36":  //0x24 出入金委託回覆
                        //mdt_OrderWithdraw
                        DataRow drNewOrderWithdraw = mdt_OrderWithdraw.NewRow();
                        strData = strData.Substring(2);//systex head(1)+psg raw
                        drNewOrderWithdraw["MTYPE"] = strData.Substring(1, 1);

                        drNewOrderWithdraw["SEQNO"] = strData.Substring(2, 9);
                        drNewOrderWithdraw["TYPE"] = strData.Substring(11, 1);
                        drNewOrderWithdraw["FIRM"] = strData.Substring(12, 7);
                        drNewOrderWithdraw["ACTNO"] = strData.Substring(19, 7);
                        drNewOrderWithdraw["CODE"] = strData.Substring(26, 4);
                        drNewOrderWithdraw["MAXAMOUNT"] = decimal.Parse(strData.Substring(30, 14)) / 100;
                        drNewOrderWithdraw["NETVALUE"] = decimal.Parse(strData.Substring(44, 15)) / 100;
                        drNewOrderWithdraw["IAMT"] = decimal.Parse(strData.Substring(59, 14)) / 100;
                        drNewOrderWithdraw["RAMT"] = decimal.Parse(strData.Substring(73, 14)) / 100;
                        drNewOrderWithdraw["OUTNO"] = strData.Substring(87, 8);
                        drNewOrderWithdraw["TONO"] = strData.Substring(95, 8);
                        drNewOrderWithdraw["MDATE"] = strData.Substring(103, 8);

                        mdt_OrderWithdraw.Rows.Add(drNewOrderWithdraw);
                        break;
                    case "89":   //未平倉彙總
                        //if (strData.Substring(9, 1) != "0")
                        if (strData.Substring(19, 1) != "0")
                        {
                            strData = strData.Substring(10);
                            DataRow tr = this.mdt_TotalUnLiquidation.NewRow();
                            string FIRM = strData.Substring(10, 7).Trim();
                            string ACTNO = strData.Substring(17, 7);
                            string COMMODX = strData.Substring(24, 21).Trim();
                            string BS = strData.Substring(45, 1);
                            string QTY = strData.Substring(46, 7);
                            string AVGPRCS = strData.Substring(53, 1);
                            string AVGPRC = strData.Substring(54, 9);
                            AVGPRC = ParsePGWNumber(AVGPRC, 4);
                            decimal AVGPRC_dec = decimal.Parse(AVGPRC);
                            AVGPRC_dec = AVGPRCS == "-" ? -1 * AVGPRC_dec : AVGPRC_dec;


                            string REALPRCS = strData.Substring(63, 1);
                            string REALPRC = strData.Substring(64, 9);
                            REALPRC = ParsePGWNumber(REALPRC, 4);
                            decimal REALPRC_dec = decimal.Parse(REALPRC);
                            REALPRC_dec = REALPRCS == "-" ? -1 * REALPRC_dec : REALPRC_dec;


                            string PRTLOSS = strData.Substring(73, 1);
                            string PRTLOS = strData.Substring(74, 14);
                            PRTLOS = ParsePGWNumber(PRTLOS, 2);
                            decimal PRTLOS_dec = decimal.Parse(PRTLOS);
                            PRTLOS_dec = PRTLOSS == "-" ? -1 * PRTLOS_dec : PRTLOS_dec;



                            string TAX = strData.Substring(88, 9);
                            TAX = ParsePGWNumber(TAX, 2);

                            string FEE = strData.Substring(97, 9);
                            FEE = ParsePGWNumber(FEE, 2);
                            string NETPLS = strData.Substring(106, 1);
                            string NETPL = strData.Substring(107, 14);
                            NETPL = ParsePGWNumber(NETPL, 2);
                            decimal NETPL_dec = decimal.Parse(NETPL);
                            NETPL_dec = NETPLS == "-" ? -1 * NETPL_dec : NETPL_dec;

                            string COMTYPE1 = strData.Substring(121, 1);
                            string COMYM1 = strData.Substring(122, 6);
                            string STKPRC1 = strData.Substring(128, 9);
                            STKPRC1 = ParsePGWNumber(STKPRC1, 4);
                            decimal STKPRC1_dec = decimal.Parse(STKPRC1);
                            STKPRC1 = STKPRC1_dec.ToString("#.####");
                            string CALLPUT1 = strData.Substring(137, 1);
                            string BS1 = strData.Substring(138, 1);
                            string AVGPRC1 = strData.Substring(139, 9);
                            AVGPRC1 = ParsePGWNumber(AVGPRC1, 4);
                            decimal AVGPRC1_dec = decimal.Parse(AVGPRC1);
                            string COMTYPE2 = strData.Substring(148, 1);
                            string COMYM2 = strData.Substring(149, 6);
                            string STKPRC2 = strData.Substring(155, 9);
                            STKPRC2 = ParsePGWNumber(STKPRC2, 4);
                            decimal STKPRC2_dec = decimal.Parse(STKPRC2);
                            STKPRC2 = STKPRC2_dec.ToString("#.####");
                            string CALLPUT2 = strData.Substring(164, 1);
                            string BS2 = strData.Substring(165, 1);
                            string AVGPRC2 = strData.Substring(166, 9);
                            AVGPRC2 = ParsePGWNumber(AVGPRC2, 4);
                            decimal AVGPRC2_dec = decimal.Parse(AVGPRC2);
                            AVGPRC2 = AVGPRC2_dec.ToString();
                            string desc = strData.Substring(175, strData.Length - 175).Trim();
                            string desc1 = desc.Split(',')[0];
                            string desc2 = desc.Split(',')[1];

                            tr["productKind"] = COMTYPE1.Trim() != "" && COMTYPE2.Trim() != "" ? "3"
                  : (COMTYPE1.Trim() == "F" ? "1" : "2");
                            tr["investorAcno"] = ACTNO;
                            tr["BS"] = tr["productKind"].ToString() == "3" ? BS1 + "\n" + BS2 : BS;
                            tr["ProductId"] = COMMODX;
                            tr["TotalOTQTY"] = int.Parse(QTY).ToString();
                            //this._dtMain["NowOTQTY"]                                                 
                            tr["RefTotalPrice"] = "";
                            tr["RefTotalPL"] = PRTLOS_dec;
                            tr["AvgMatchPrice"] = AVGPRC_dec;

                            //這邊只會有複式選擇權所以只會1 2或三
                            // 1 單式期貨 2選擇權 3複式選擇



                            tr["currency"] = "";


                            tr["realPrice"] = REALPRC_dec;


                            tr["multiplecomno"] = tr["productKind"].ToString() == "3" ? COMMODX : "";
                            tr["multipleBS"] = BS;


                            tr["multipleMatchPrice1"] = tr["productKind"].ToString() == "3" ? AVGPRC1_dec.ToString() : "0";

                            tr["multipleMatchPrice2"] = tr["productKind"].ToString() == "3" ? AVGPRC2_dec.ToString() : "0";


                            tr["PriceDiff"] = BS == "B" ? (REALPRC_dec - AVGPRC_dec) : (AVGPRC_dec - REALPRC_dec);

                            tr["MultiName"] = "";


                            tr["footMatchPrice"] = tr["productKind"].ToString() == "3" ? AVGPRC1_dec.ToString("#,##0.####") + "\n" + AVGPRC2_dec.ToString("#,##0.####") + "\n" : "";

                            string period = "";
                            period = getOptionPeriod(COMMODX.Substring(COMMODX.Length - 2, 1)).ToString();

                            if (tr["productKind"].ToString() == "3")
                            {
                                tr["productName"] = getmutiname(COMMODX, COMYM1, COMYM2, STKPRC1, STKPRC2, CALLPUT1, CALLPUT2, desc1, desc2);
                            }
                            else
                            {
                                if (COMTYPE1 == "F")
                                    tr["productName"] = desc1.Trim() + period;
                                else
                                    tr["productName"] = desc1.Trim() + STKPRC1 + CALLPUT1 + period;
                            }
                            tr["COMTYPE"] = COMTYPE1;
                            tr["COMNO"] = "";
                            tr["callput"] = CALLPUT1 == "" ? "N" : CALLPUT1; //當期貨時 等於N
                            tr["MKTCOMNO"] = COMMODX.Substring(0, 3);
                            tr["COMYM"] = COMYM1;
                            tr["stkprc"] = STKPRC1;
                            tr["stkprc_dec"] = STKPRC1_dec;
                            tr["IAMT"] = "";
                            tr["MAMT"] = "";

                            tr["TAX"] = TAX;
                            tr["FEE"] = FEE;
                            tr["EQUITY"] = NETPL_dec;


                            mdt_TotalUnLiquidation.Rows.Add(tr);

                        }
                        break;
                    case "96":   //高風險查詢

                        //if (strData.Substring(9, 1) != "0")
                        if (strData.Substring(19, 1) != "0")
                        {
                            strData = strData.Substring(10);
                            string FU19103S = strData.Substring(27, 1).Trim();
                            string FU19103 = strData.Substring(28, 14).Trim();
                            FU19103 = Decimal.Parse(FU19103S + FU19103).ToString();
                            string INIRATES = strData.Substring(42, 1).Trim();
                            string INIRATE = strData.Substring(43, 14).Trim();
                            INIRATE = Decimal.Parse(INIRATES + INIRATE).ToString();
                            string MATRATES = strData.Substring(57, 1).Trim();
                            string MATRATE = strData.Substring(58, 14).Trim();
                            MATRATE = Decimal.Parse(MATRATES + MATRATE).ToString();
                            string IAMTS = strData.Substring(72, 1).Trim();
                            string IAMT = strData.Substring(73, 14).Trim();
                            IAMT = Decimal.Parse(IAMTS + IAMT).ToString();
                            string MAMTS = strData.Substring(87, 1).Trim();
                            string MAMT = strData.Substring(88, 14).Trim();
                            MAMT = Decimal.Parse(MAMTS + MAMT).ToString();
                            string ORDCEXCESSS = strData.Substring(102, 1).Trim();
                            string ORDCEXCESS = strData.Substring(103, 14).Trim();
                            ORDCEXCESS = Decimal.Parse(ORDCEXCESSS + ORDCEXCESS).ToString();
                            string CTDABS = strData.Substring(117, 1).Trim();
                            string CTDAB = strData.Substring(118, 14).Trim();
                            CTDAB = Decimal.Parse(CTDABS + CTDAB).ToString();
                            string OPTEQUITYS = strData.Substring(132, 1).Trim();
                            string OPTEQUITY = strData.Substring(133, 14).Trim();
                            OPTEQUITY = Decimal.Parse(OPTEQUITYS + OPTEQUITY).ToString();
                            string STIME = strData.Substring(147, 8).Trim();


                            dr = this.mdt_RateData.NewRow();

                            dr["FIRM"] = strData.Substring(10, 7).Trim();
                            dr["ACTNO"] = strData.Substring(17, 7).Trim();

                            dr["CCY"] = strData.Substring(24, 3).Trim();

                            dr["FU19103"] = ParsePGWNumber(FU19103, 2);

                            dr["INIRATE"] = ParsePGWNumber(INIRATE, 2);
                            dr["MATRATE"] = ParsePGWNumber(MATRATE, 2);
                            dr["IAMT"] = ParsePGWNumber(IAMT, 2);
                            dr["MAMT"] = ParsePGWNumber(MAMT, 2);
                            dr["ORDCEXCESS"] = ParsePGWNumber(ORDCEXCESS, 2);
                            dr["CTDAB"] = ParsePGWNumber(CTDAB, 2);
                            dr["OPTEQUITY"] = ParsePGWNumber(OPTEQUITY, 2);
                            dr["STIME"] = STIME;
                            mdt_RateData.Rows.Add(dr);

                        }

                        break;

                    case "99":   //高風險查詢25%  ////高風險查詢低於25% //V1.0.0.23 added by peter on 20170110

                        //if (strData.Substring(9, 1) != "0")
                        if (strData.Substring(19, 1) != "0")
                        {
                            strData = strData.Substring(10);
                            string FU19103S = strData.Substring(27, 1).Trim();
                            string FU19103 = strData.Substring(28, 14).Trim();
                            FU19103 = Decimal.Parse(FU19103S + FU19103).ToString();
                            string INIRATES = strData.Substring(42, 1).Trim();
                            string INIRATE = strData.Substring(43, 14).Trim();
                            INIRATE = Decimal.Parse(INIRATES + INIRATE).ToString();
                            string MATRATES = strData.Substring(57, 1).Trim();
                            string MATRATE = strData.Substring(58, 14).Trim();
                            MATRATE = Decimal.Parse(MATRATES + MATRATE).ToString();
                            string IAMTS = strData.Substring(72, 1).Trim();
                            string IAMT = strData.Substring(73, 14).Trim();
                            IAMT = Decimal.Parse(IAMTS + IAMT).ToString();
                            string MAMTS = strData.Substring(87, 1).Trim();
                            string MAMT = strData.Substring(88, 14).Trim();
                            MAMT = Decimal.Parse(MAMTS + MAMT).ToString();
                            string ORDCEXCESSS = strData.Substring(102, 1).Trim();
                            string ORDCEXCESS = strData.Substring(103, 14).Trim();
                            ORDCEXCESS = Decimal.Parse(ORDCEXCESSS + ORDCEXCESS).ToString();
                            string CTDABS = strData.Substring(117, 1).Trim();
                            string CTDAB = strData.Substring(118, 14).Trim();
                            CTDAB = Decimal.Parse(CTDABS + CTDAB).ToString();
                            string OPTEQUITYS = strData.Substring(132, 1).Trim();
                            string OPTEQUITY = strData.Substring(133, 14).Trim();
                            OPTEQUITY = Decimal.Parse(OPTEQUITYS + OPTEQUITY).ToString();

                            string MARGINCALLS = strData.Substring(147, 1).Trim();
                            string MARGINCALL = strData.Substring(148, 14).Trim();
                            MARGINCALL = Decimal.Parse(MARGINCALLS + MARGINCALL).ToString();
                            string DTATIME = strData.Substring(162, 8).Trim();
                            string CLSTIME = strData.Substring(170, 8).Trim();

                            dr = this.mdt_RateForDateData.NewRow();

                            dr["FIRM"] = strData.Substring(10, 7).Trim();
                            dr["ACTNO"] = strData.Substring(17, 7).Trim();

                            dr["CCY"] = strData.Substring(24, 3).Trim();

                            dr["FU19103"] = ParsePGWNumber(FU19103, 2);

                            dr["INIRATE"] = ParsePGWNumber(INIRATE, 2);
                            dr["MATRATE"] = ParsePGWNumber(MATRATE, 2);
                            dr["IAMT"] = ParsePGWNumber(IAMT, 2);
                            dr["MAMT"] = ParsePGWNumber(MAMT, 2);
                            dr["ORDCEXCESS"] = ParsePGWNumber(ORDCEXCESS, 2);
                            dr["CTDAB"] = ParsePGWNumber(CTDAB, 2);
                            dr["OPTEQUITY"] = ParsePGWNumber(OPTEQUITY, 2);
                            dr["MARGINCALL"] = ParsePGWNumber(MARGINCALL, 2);
                            dr["DTATIME"] = DTATIME;
                            dr["CLSTIME"] = CLSTIME;
                            mdt_RateForDateData.Rows.Add(dr);

                        }

                        break;
                }
            }
            catch (Exception ex)
            {
                BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[parseMobInfoData]" + ex.Message);
            }

        }
    }
    public string SubStr(string a_SrcStr, int a_StartIndex, int a_Cnt)
    {
        Encoding l_Encoding = Encoding.GetEncoding("big5", new EncoderExceptionFallback(), new DecoderReplacementFallback(""));
        byte[] l_byte = l_Encoding.GetBytes(a_SrcStr);
        if (a_Cnt <= 0)
            return "";
        //例若長度10 
        //若a_StartIndex傳入9 -> ok, 10 ->不行 
        if (a_StartIndex + 1 > l_byte.Length)
            return "";
        else
        {
            //若a_StartIndex傳入9 , a_Cnt 傳入2 -> 不行 -> 改成 9,1 
            if (a_StartIndex + a_Cnt > l_byte.Length)
                a_Cnt = l_byte.Length - a_StartIndex;
        }
        return l_Encoding.GetString(l_byte, a_StartIndex, a_Cnt);
    }


    /// <summary>
    /// MOB CurrentBalance MOB當日損益查詢
    /// </summary>
    private Boolean CurrentBalance_MobInfo(string info)
    {
        DataTable infoDT1 = new DataTable();
        Boolean status = false;

        try
        {
            if (info.Substring(107, 1) == "1")
            {


                infoDT1.Columns.Add(new DataColumn("OSPRTLOS"));//當日損益
                infoDT1.Columns.Add(new DataColumn("BCPREMIUM"));//買方權利金市值(買權)
                infoDT1.Columns.Add(new DataColumn("BPPREMIUM"));//買方權利金市值(賣權)
                infoDT1.Columns.Add(new DataColumn("SCPREMIUM"));//賣方權利金市值(買權)
                infoDT1.Columns.Add(new DataColumn("SPPREMIUM"));//賣方權利金市值(賣權)

                DataRow dr = infoDT1.NewRow();
                dr["OSPRTLOS"] = NumberTrim(info.Substring(27, 16));
                dr["BCPREMIUM"] = NumberTrim(info.Substring(43, 16));
                dr["BPPREMIUM"] = NumberTrim(info.Substring(59, 16));
                dr["SCPREMIUM"] = NumberTrim(info.Substring(75, 16));
                dr["SPPREMIUM"] = NumberTrim(info.Substring(91, 16));

                infoDT1.Rows.Add(dr);
                infoDT1.AcceptChanges();

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentBalance.Rows[0]["value"] = NumberTrim(info.Substring(27, 16));        //當日損益
                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentBalance.Rows[1]["value"] = NumberTrim(info.Substring(43, 16));         //買方權利金市值(買權)
                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentBalance.Rows[2]["value"] = NumberTrim(info.Substring(59, 16));       //買方權利金市值(賣權)
                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentBalance.Rows[3]["value"] = NumberTrim(info.Substring(75, 16));   //賣方權利金市值(買權)
                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentBalance.Rows[4]["value"] = NumberTrim(info.Substring(91, 16)); //賣方權利金市值(賣權)

                status = true;
            }
            else
            {
                //do nothing 
                status = false;
            }
        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "CurrentBalance_MobInfo" + ex.Message);
            status = false;
        }
        mdt_MOBCurrentBalance = infoDT1;
        return status;

    }


    //added 20100421 MOB unliquidation 明細
    private DataRow unLiquidation_list(string info, DataRow ddr, int i, string productdesc)
    {
        try
        {
            //added by philip 20100319
            double CurrentBalance = 0;
            double CurrentValue = 0;

            ddr["currency"] = info.Substring(i * 170 + 125, 3);           //幣別
            ddr["investorAcno"] = info.Substring(16, 7);                  //下單帳號
            ddr["tradedate"] = info.Substring(i * 170 + 37, 10);          //成交日期
            ddr["matchTime"] = "";                                        //成交時間  先帶空白
            ddr["orderNo"] = info.Substring(i * 170 + 29, 8);             //委託單號
            ddr["BS"] = info.Substring(i * 170 + 47, 1);                  //買賣別

            //商品代碼
            ddr["productId"] = info.Substring(i * 170 + 49, 10).Trim();
            //ddr["productId"] = getProductId(comtypeTransfer(info.Substring(i * 170 + 48, 1)), ProductNameTrans(info.Substring(i * 170 + 49, 7).Trim(), info.Substring(i * 170 + 48, 1)), info.Substring(i * 170 + 56, 6), info.Substring(i * 170 + 62, 6), info.Substring(i * 170 + 68, 1));
            string period = getOptionPeriod(ddr["productId"].ToString().Substring(ddr["productId"].ToString().Length - 2, 1)).ToString();
            string cp = "N";
            string strikeprice = "0";
            ddr["COMTYPE"] = info.Substring(i * 170 + 48, 1).Trim();

            if (info.Substring(i * 170 + 48, 1) == "1")
            {
                cp = getOptionCP(ddr["productId"].ToString().Substring(8, 1));
                strikeprice = decimal.Parse(ddr["productId"].ToString().Substring(3, 5)).ToString("#0.####");
                strikeprice = decimal.Parse(info.Substring(i * 170 + 216, 6).Trim()).ToString("#0.####");

                ddr["productName"] = productdesc + strikeprice + cp + period;
            }
            else
            {

                ddr["productName"] = productdesc + period;
            }
            ddr["callput"] = cp;
            ddr["MKTcomno"] = ddr["productId"].ToString().Substring(0, 3);
            ddr["comym"] = "201" + ddr["productId"].ToString().Substring(ddr["productId"].ToString().Length - 1, 1) + getOptionPeriod(ddr["productId"].ToString().Substring(ddr["productId"].ToString().Length - 2, 1)).ToString().PadLeft(2, '0');
            ddr["stkprc"] = strikeprice;
            ddr["stkprc_dec"] = strikeprice;
            double price = double.Parse(info.Substring(i * 170 + 128, 9)) / 10000;//Math.Round(double.Parse(info.Substring(i * 170 + 128, 9)) / 10000, 2, MidpointRounding.AwayFromZero);
            ddr["MatchPrice"] = price.ToString("#,##0.####");

            //參考即時價
            //參考浮動損益

            //參考現值

            double dCurrentPrice = double.Parse(info.Substring(i * 170 + 161, 9)) / 10000;
            double cntsize = double.Parse(info.Substring(i * 170 + 143, 18)) / 1000000;
            double PRTLOS_as400 = double.Parse(info.Substring(i * 170 + 188, 15)) / 100;
            //若查不到 則帶 NA
            if (dCurrentPrice == 0)
            {
                ddr["RefRealPrice"] = "0";
                ddr["RefPL"] = "0";
                ddr["RefNowPrice"] = "0";     //參考現值

            }
            else
            {
                int qty = Convert.ToInt16(info.Substring(i * 170 + 70, 4));


                //added 20100326 四捨五入
                //double roundoff_dCurrentPrice = Math.Round(dCurrentPrice, 2, MidpointRounding.AwayFromZero);\\\

                double roundoff_dCurrentPrice = dCurrentPrice;

                ddr["RefRealPrice"] = roundoff_dCurrentPrice.ToString("#,##0.####");

                //modified by philip 20100319 CurrentBalance即時浮動損益 依成交時的買賣別計算
                //if (info.Substring(i * 170 + 47, 1) == "B")
                //{
                //    CurrentBalance = (dCurrentPrice - price) * cntsize * qty;

                //}
                //else
                //{
                //    CurrentBalance = (price - dCurrentPrice) * cntsize * qty;
                //}

                //added 20100326 四捨五入
                //  double roundoff_CurrentBalance = Math.Round(CurrentBalance, 2, MidpointRounding.AwayFromZero);
                double roundoff_CurrentBalance = CurrentBalance = PRTLOS_as400;
                ddr["RefPL"] = roundoff_CurrentBalance.ToString("#,##0.##");    //參考浮動損益


                //參考現值

                CurrentValue = dCurrentPrice * cntsize * qty;
                //  double roundoff_CurrentValue = Math.Round(CurrentValue, 2, MidpointRounding.AwayFromZero);
                double roundoff_CurrentValue = CurrentValue;
                ddr["RefNowPrice"] = roundoff_CurrentValue.ToString("#,##0.####");

            }

            ddr["OTQTY"] = Convert.ToInt16(info.Substring(i * 170 + 70, 4));  //留倉口數

            ddr["DTOVER"] = info.Substring(i * 170 + 69, 1);               //當沖
            ddr["productKind"] = spreadType(info.Substring(i * 170 + 124, 1).Trim());              //商品類別 

            //避免複式單拆開後.造成重複問題,將第二隻腳成交序號修改成"成交序號+腳號"
            if (info.Substring(i * 170 + 35, 1) != "1" && (info.Substring(i * 170 + 124, 1) == "0" || info.Substring(i * 170 + 124, 1) == "7" || bolCombine))
            {
                ddr["matchseq"] = info.Substring(i * 170 + 35, 2);        ////拆單續號
            }
            else
            {
                ddr["matchseq"] = info.Substring(i * 170 + 36, 1);        ////拆單續號
            }

            if (ddr["productKind"].ToString() == "3" || ddr["productKind"].ToString() == "4")
            {

                ddr["footMatchPrice"] = ddr["MatchPrice"].ToString();
                string spreadKind = info.Substring(i * 170 + 124, 1).Trim();
                if (spreadKind == "1" || spreadKind == "2" || spreadKind == "3" || spreadKind == "4" || spreadKind == "5")
                {
                    ddr["productName"] = productdesc;
                }
            }
            ddr["IAMT"] = decimal.Parse(info.Substring(i * 170 + 103, 8)).ToString();               //IAMT
            ddr["MAMT"] = decimal.Parse(info.Substring(i * 170 + 111, 8).Trim()).ToString();              //MAMT 

            ddr["TAX"] = double.Parse(info.Substring(i * 170 + 170, 9)) / 100;
            ddr["FEE"] = double.Parse(info.Substring(i * 170 + 179, 9)) / 100;


            ddr["COMNO"] = info.Substring(i * 170 + 188, 7).Trim();
            ddr["COMNO"] = info.Substring(i * 170 + 203, 7).Trim();
            ddr["EQUITY"] = (CurrentBalance - (double.Parse(ddr["TAX"].ToString())) - (double.Parse(ddr["FEE"].ToString()))).ToString("#,##0.##"); ;
            return ddr;
        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "unLiquidation_list" + ex.Message);

            return null;
        }
    }

    //added 20100421 MOB unliquidation 複式商品資料更新
    private DataRow unLiquidationDetailCombine(DataRow dr1, DataRow dr2, string spreadKind, string productType, double cntsize, string productdesc, string productdesc2)
    {
        try
        {


            if (spreadKind == "1" || spreadKind == "2" || spreadKind == "3" || spreadKind == "4" || spreadKind == "5")
            {
                string[] strReturn = MultipleProductId(productType, dr1["productId"].ToString(), dr2["productId"].ToString(), dr1["BS"].ToString(), dr2["BS"].ToString(), productdesc, productdesc2, dr1["STKPRC"].ToString(), dr2["STKPRC"].ToString());
                dr1["multiplecomno"] = strReturn[0];
                dr1["productName"] = strReturn[2];
                dr1["multipleBS"] = strReturn[6];

                dr1["productId"] = strReturn[3] + "\n" + strReturn[4];
                dr1["BS"] = strReturn[5] + "\n" + strReturn[6];
                dr1["callput"] = strReturn[7] + "\n" + strReturn[8];


                dr1["MKTCOMNO"] = strReturn[3].Substring(0, 3);

                dr1["COMYM"] = strReturn[11] + "\n" + strReturn[12];
                dr1["STKPRC"] = strReturn[9] + "\n" + strReturn[10];

                if (dr2["BS"].ToString() == strReturn[6])
                {
                    dr1["multipleMatchPrice1"] = dr1["MatchPrice"].ToString();
                    dr1["multipleMatchPrice2"] = dr2["MatchPrice"].ToString();

                    dr1["footMatchPrice"] += "\n" + dr2["MatchPrice"].ToString();
                    dr1["MatchPrice"] = getMultiplePrice(spreadKind, Convert.ToDecimal(dr1["MatchPrice"].ToString()), Convert.ToDecimal(dr2["MatchPrice"].ToString()));
                    if (dr1["RefRealPrice"].ToString() != "NA" && dr2["RefRealPrice"].ToString() != "NA")
                    {
                        dr1["RefRealPrice"] = getMultiplePrice(spreadKind, Convert.ToDecimal(dr1["RefRealPrice"].ToString()), Convert.ToDecimal(dr2["RefRealPrice"].ToString()));
                        dr1["RefNowPrice"] = getMultiplePrice(spreadKind, Convert.ToDecimal(dr1["RefNowPrice"].ToString()), Convert.ToDecimal(dr2["RefNowPrice"].ToString()));
                    }

                }
                else
                {

                    dr1["multipleMatchPrice1"] = dr2["MatchPrice"].ToString();
                    dr1["multipleMatchPrice2"] = dr1["MatchPrice"].ToString();

                    dr1["footMatchPrice"] = dr2["footMatchPrice"] + "\n" + dr1["MatchPrice"].ToString();
                    dr1["MatchPrice"] = getMultiplePrice(spreadKind, Convert.ToDecimal(dr2["MatchPrice"].ToString()), Convert.ToDecimal(dr1["MatchPrice"].ToString()));
                    if (dr1["RefRealPrice"].ToString() != "NA" && dr2["RefRealPrice"].ToString() != "NA")
                    {
                        dr1["RefRealPrice"] = getMultiplePrice(spreadKind, Convert.ToDecimal(dr2["RefRealPrice"].ToString()), Convert.ToDecimal(dr1["RefRealPrice"].ToString()));
                        dr1["RefNowPrice"] = getMultiplePrice(spreadKind, Convert.ToDecimal(dr2["RefNowPrice"].ToString()), Convert.ToDecimal(dr1["RefNowPrice"].ToString()));
                    }


                }
                if (dr1["RefRealPrice"].ToString() != "NA" && dr2["RefRealPrice"].ToString() != "NA")
                {

                    if (dr1["multipleBS"].ToString() == "B")
                    {
                        dr1["RefPL"] = (double.Parse(dr1["RefRealPrice"].ToString()) - double.Parse(dr1["MatchPrice"].ToString())) * int.Parse(dr2["OTQTY"].ToString()) * cntsize;
                    }
                    else
                    {
                        dr1["RefPL"] = (double.Parse(dr1["MatchPrice"].ToString()) - double.Parse(dr1["RefRealPrice"].ToString())) * int.Parse(dr2["OTQTY"].ToString()) * cntsize;
                    }

                }



            }
            else
            {
                dr1["multipleBS"] = dr2["BS"].ToString();
                dr1["productName"] = dr1["productName"].ToString() + " " + dr2["productName"].ToString();
                dr1["MatchPrice"] = "0";
                dr1["RefRealPrice"] = "0";
                dr1["RefNowPrice"] = "0";
                dr1["RefPL"] = "0";

                dr1["footMatchPrice"] += "\n" + dr2["MatchPrice"].ToString();
                dr1["productId"] += "\n" + dr2["productId"].ToString();
                dr1["BS"] += "\n" + dr2["BS"].ToString();
                dr1["callput"] += "\n" + dr2["callput"].ToString();


                dr1["MKTCOMNO"] += "\n" + dr2["MKTCOMNO"].ToString();
                dr1["COMYM"] += "\n" + dr2["COMYM"].ToString();
                dr1["STKPRC"] += "\n" + dr2["STKPRC"].ToString();

            }
            dr1["COMNO"] += "\n" + dr2["COMNO"].ToString();
            dr1["IAMT"] = decimal.Parse(dr1["IAMT"].ToString()) + decimal.Parse(dr2["IAMT"].ToString());
            dr1["MAMT"] = decimal.Parse(dr1["MAMT"].ToString()) + decimal.Parse(dr2["MAMT"].ToString());



            dr1["TAX"] = double.Parse(dr1["TAX"].ToString()) + double.Parse(dr2["TAX"].ToString());
            dr1["FEE"] = double.Parse(dr1["FEE"].ToString()) + double.Parse(dr2["FEE"].ToString());
            dr1["EQUITY"] = (double.Parse(dr1["RefPL"].ToString())) - (double.Parse(dr1["TAX"].ToString())) - (double.Parse(dr1["FEE"].ToString()));
            return dr1;
        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "unLiquidationDetailCombine" + ex.Message);
            return null;
        }
    }


    // private DataRow drC = frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_UnLiquidationDetailTempCombine.NewRow();

    /// <summary>
    /// MOB UnLiquidation 計算   MOB未平倉損益

    /// </summary>
    /// <param name="info"></param>
    /// <returns></returns>
    private bool unLiquidation_MobInfo(string info, string[] strProducts)
    {


        //initializedUnLiquidationDetail();
        try
        {

            int BodyCount = Convert.ToInt16(info.Substring(23, 2));

            for (int i = 0; i < BodyCount; i++)
            {

                //added 20100421 複式單呈現

                //if (info.Substring(i * 145 + 124, 1).Trim() == "6" | info.Substring(i * 145 + 124, 1).Trim() == "1" | info.Substring(i * 145 + 124, 1).Trim() == "2" | info.Substring(i * 145 + 124, 1).Trim() == "3" | info.Substring(i * 145 + 124, 1).Trim() == "4" | info.Substring(i * 145 + 124, 1).Trim() == "5")
                //{
                if (info.Substring(i * 170 + 29, 6) == "3C046 ")
                {
                    string aa = "";
                }
                if (info.Substring(i * 170 + 124, 1).Trim() != "0" && info.Substring(i * 170 + 124, 1).Trim() != "7" && !bolCombine)
                {
                    // //委託單號取前5碼當做比對     拆單續號

                    //modified 20100923 增加日期條件
                    string combineFliter = "tradedate='" + info.Substring(i * 170 + 37, 10) + "' and substring(orderNo,1,6)='" + info.Substring(i * 170 + 29, 6) + "' and matchseq ='" + info.Substring(i * 170 + 36, 1) + "'";

                    DataRow[] dttCombine = mdt_UnLiquidationDetail.Select(combineFliter);

                    //當mdt_UnLiquidationDetail內有一筆複式商品落單的腳 , 才進來做兩隻腳的合併

                    if (dttCombine.Length == 1)
                    {
                        // DataRow drC = frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_UnLiquidationDetailTempCombine.NewRow();
                        DataRow drC = mdt_UnLiquidationDetail.NewRow();

                        drC = unLiquidation_list(info, drC, i, strProducts[i]);

                        string spreadKind = null;
                        string productType = null;
                        // 精誠  7:單式期貨 0:單式期權  6:複式期貨 12345:複選期權             
                        //// 1價差 2跨月 3跨式 4勒式 5轉換逆轉換 0期貨價差  
                        // 
                        if (info.Substring(i * 170 + 124, 1).Trim() == "6")
                        {
                            spreadKind = "0";
                            productType = "4";
                        }
                        else
                        {
                            spreadKind = info.Substring(i * 170 + 124, 1).Trim();
                            productType = "3";
                        }

                        DataRow combineRow = null;
                        //added by philip 20100923
                        double cntsize = double.Parse(info.Substring(i * 170 + 143, 18)) / 1000000;


                        //更新原本在mdt_UnLiquidationDetail 相對應的複式商品
                        if (info.Substring(i * 170 + 35, 1) == "1")
                        {

                            combineRow = unLiquidationDetailCombine(drC, dttCombine[0], spreadKind, productType, cntsize, strProducts[i], dttCombine[0]["productName"].ToString());


                            dttCombine[0]["multiplecomno"] = combineRow["multiplecomno"];
                            dttCombine[0]["multipleBS"] = combineRow["multipleBS"];
                            dttCombine[0]["MatchPrice"] = combineRow["MatchPrice"];
                            dttCombine[0]["RefRealPrice"] = combineRow["RefRealPrice"];
                            dttCombine[0]["RefNowPrice"] = combineRow["RefNowPrice"];
                            dttCombine[0]["RefPL"] = combineRow["RefPL"];
                            dttCombine[0]["matchseq"] = combineRow["matchseq"];
                            dttCombine[0]["productId"] = combineRow["productId"];
                            dttCombine[0]["BS"] = combineRow["BS"];
                            dttCombine[0]["callput"] = combineRow["callput"];
                            dttCombine[0]["COMTYPE"] = combineRow["COMTYPE"];
                            dttCombine[0]["COMNO"] = combineRow["COMNO"];
                            dttCombine[0]["MKTCOMNO"] = combineRow["MKTCOMNO"];
                            dttCombine[0]["COMYM"] = combineRow["COMYM"];
                            dttCombine[0]["STKPRC"] = combineRow["STKPRC"];

                            dttCombine[0]["productName"] = combineRow["productName"];
                            dttCombine[0]["footMatchPrice"] = combineRow["footMatchPrice"];
                            dttCombine[0]["IAMT"] = combineRow["IAMT"];
                            dttCombine[0]["MAMT"] = combineRow["MAMT"];
                            dttCombine[0]["multipleMatchPrice1"] = combineRow["multipleMatchPrice1"];
                            dttCombine[0]["multipleMatchPrice2"] = combineRow["multipleMatchPrice2"];
                            dttCombine[0]["TAX"] = combineRow["TAX"];
                            dttCombine[0]["FEE"] = combineRow["FEE"];
                            dttCombine[0]["EQUITY"] = combineRow["EQUITY"];


                        }
                        else
                        {
                            //dttCombine[0].BeginEdit();
                            //dttCombine[0] = unLiquidationDetailCombine(dttCombine[0], drC, spreadKind, productType);
                            //dttCombine[0].EndEdit();
                            //  dttCombine[0].ItemArray = unLiquidationDetailCombine(dttCombine[0], drC, spreadKind, productType).ItemArray;

                            combineRow = unLiquidationDetailCombine(dttCombine[0], drC, spreadKind, productType, cntsize, dttCombine[0]["productName"].ToString(), strProducts[i]);


                            dttCombine[0]["multiplecomno"] = combineRow["multiplecomno"];
                            dttCombine[0]["multipleBS"] = combineRow["multipleBS"];
                            dttCombine[0]["MatchPrice"] = combineRow["MatchPrice"];
                            dttCombine[0]["RefRealPrice"] = combineRow["RefRealPrice"];
                            dttCombine[0]["RefNowPrice"] = combineRow["RefNowPrice"];
                            dttCombine[0]["RefPL"] = combineRow["RefPL"];
                            dttCombine[0]["matchseq"] = combineRow["matchseq"];
                            dttCombine[0]["productId"] = combineRow["productId"];
                            dttCombine[0]["BS"] = combineRow["BS"];
                            dttCombine[0]["callput"] = combineRow["callput"];
                            dttCombine[0]["COMTYPE"] = combineRow["COMTYPE"];
                            dttCombine[0]["COMNO"] = combineRow["COMNO"];
                            dttCombine[0]["MKTCOMNO"] = combineRow["MKTCOMNO"];
                            dttCombine[0]["COMYM"] = combineRow["COMYM"];
                            dttCombine[0]["STKPRC"] = combineRow["STKPRC"];
                            dttCombine[0]["productName"] = combineRow["productName"];
                            dttCombine[0]["footMatchPrice"] = combineRow["footMatchPrice"];
                            dttCombine[0]["IAMT"] = combineRow["IAMT"];
                            dttCombine[0]["MAMT"] = combineRow["MAMT"];

                            dttCombine[0]["multipleMatchPrice1"] = combineRow["multipleMatchPrice1"];
                            dttCombine[0]["multipleMatchPrice2"] = combineRow["multipleMatchPrice2"];

                            dttCombine[0]["TAX"] = combineRow["TAX"];
                            dttCombine[0]["FEE"] = combineRow["FEE"];
                            dttCombine[0]["EQUITY"] = combineRow["EQUITY"];
                        }

                        //drC.
                        continue;
                        //  frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_UnLiquidationDetailTempCombine.Rows.Add(drC);
                    }
                }


                DataRow ddr = mdt_UnLiquidationDetail.NewRow();

                ddr = unLiquidation_list(info, ddr, i, strProducts[i]);

                mdt_UnLiquidationDetail.Rows.Add(ddr);


            }




            //20100226 判斷是否還有資料
            //initializedUnLiquidationMain();
            //initializedPositionData();

            //if (info.Substring(info.Length - 2, 1) == "\n" || info.Substring(info.Length - 2, 1) == "\r")
            if (info.Substring(info.Length - 1, 1) == "\n")
            {

                //判斷是否有資料


                // if (frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBUnLiquidation.Rows.Count == 0)
                if (mdt_UnLiquidationDetail.Rows.Count == 0)
                {

                    return true;
                }


                //計算加總 
                //modified by philip 20100408 多加一個條件 spread
                // DataTable dtTarget = frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBUnLiquidation.DefaultView.ToTable(true, new string[] { "PS", "ProductName", "currency" , "spread" });

                //modified 201004223 用dataview來接mdt_UnLiquidationDetail 再使用

                DataView unliquidationDetail = new DataView(mdt_UnLiquidationDetail);
                DataTable dtTarget = null;

                if (this.bolCombine)
                    dtTarget = unliquidationDetail.Table.DefaultView.ToTable(true, new string[] { "BS", "productId", "currency" });
                else
                    dtTarget = unliquidationDetail.Table.DefaultView.ToTable(true, new string[] { "BS", "productId", "currency", "productKind" });

                //  DataTable dtTarget = frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_UnLiquidationDetail.DefaultView.ToTable(true, new string[] { "BS", "productId", "currency", "productKind" });


                if (dtTarget.Rows.Count != 0)
                {
                    foreach (DataRow dr in dtTarget.Rows)
                    {

                        int tempOTQTY = 0;
                        double tempTRDPRC1 = 0;
                        double tempCurrentBalance = 0;
                        double tempRefTotalPrice = 0;
                        double tempIAMT = 0;
                        double tempMAMT = 0;

                        double tempTAX = 0;
                        double tempFEE = 0;
                        double tempEQUITY = 0;

                        //  unliquidationDetail.Table.NewRow()
                        DataRow drResult = mdt_PositionData.NewRow();
                        DataRow drrResult = mdt_UnLiquidationMain.NewRow();

                        //modified by philip 20100408 多加一個條件 spread
                        //string command = "PS='" + dr["PS"] + "' and ProductName = '" + dr["ProductName"] + "' and CURRENCY = '" + dr["CURRENCY"] + "' and spread='" + dr["spread"] + "'";
                        string command = "";
                        if (this.bolCombine)
                            command = "BS='" + dr["BS"] + "' and productId = '" + dr["productId"] + "' and currency = '" + dr["currency"] + "' ";
                        else
                            command = "BS='" + dr["BS"] + "' and productId = '" + dr["productId"] + "' and currency = '" + dr["currency"] + "' and productKind='" + dr["productKind"] + "'";

                        // DataRow[] rCount = frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBUnLiquidation.Select(command);
                        DataRow[] rCount = mdt_UnLiquidationDetail.Select(command);
                        Dictionary<int, decimal> dcFootPrice = new Dictionary<int, decimal>();
                        foreach (DataRow drr in rCount)
                        {

                            if (drr["footMatchPrice"].ToString() != "")
                            {
                                int idx = 0;
                                foreach (string foot in drr["footMatchPrice"].ToString().Split(new Char[] { }))
                                {

                                    if (dcFootPrice.ContainsKey(idx))
                                    {
                                        dcFootPrice[idx] += decimal.Parse(foot) * decimal.Parse(drr["OTQTY"].ToString());
                                    }
                                    else
                                    {
                                        dcFootPrice.Add(idx, decimal.Parse(foot) * decimal.Parse(drr["OTQTY"].ToString()));
                                    }
                                    idx++;
                                }

                            }
                            tempOTQTY += Convert.ToInt16(drr["OTQTY"].ToString());

                            if (drr["MatchPrice"].ToString() != "")
                            {
                                tempTRDPRC1 += double.Parse(drr["MatchPrice"].ToString()) * Convert.ToInt16(drr["OTQTY"].ToString());
                            }

                            //if (drr["CurrentBalance"].ToString() == "NA")
                            if (drr["RefPL"].ToString() == "NA")
                            {
                                tempCurrentBalance += 0;
                            }
                            else
                            {

                                tempCurrentBalance += double.Parse(drr["RefPL"].ToString());   //
                            }

                            if (drr["RefNowPrice"].ToString() == "NA")
                            {
                                tempRefTotalPrice += 0;
                            }
                            else
                            {
                                tempRefTotalPrice += double.Parse(drr["RefNowPrice"].ToString());
                            }



                            //update by samantha 20100415 修改只有mdt_UnLiquidationMain帶即時價 
                            //drrResult["realprice"] = drr["RefRealPrice"].ToString().Trim();
                            if (drr["RefNowPrice"].ToString() == "NA")
                            {
                                drrResult["realprice"] = "0";
                            }
                            else
                            {
                                drrResult["realprice"] = drr["RefRealPrice"].ToString().Trim();
                            }

                            //added by philip 20100416 mdt_PositionData 也需要即時價
                            drResult["MarketPrice"] = drr["RefRealPrice"].ToString().Trim();

                            //modified 20100319 即時浮動損益需要加總  再除以總口數
                            //   drResult["CurrentBalance"] = drr["CurrentBalance"].ToString().Trim();

                            drResult["BS"] = drr["BS"].ToString().Trim();
                            drResult["initBS"] = drr["BS"].ToString().Trim();
                            drrResult["BS"] = drr["BS"].ToString().Trim();

                            drResult["ProductId"] = drr["ProductId"].ToString().Trim();
                            drrResult["ProductId"] = drr["ProductId"].ToString().Trim();


                            drrResult["currency"] = drr["currency"].ToString().Trim();

                            //add 20100408 

                            drResult["productKind"] = drr["productKind"].ToString().Trim();
                            drrResult["productKind"] = drr["productKind"].ToString().Trim();

                            //added 20100414 帶入帳號
                            drResult["investorAcno"] = drr["investorAcno"].ToString().Trim();
                            drrResult["investorAcno"] = drr["investorAcno"].ToString().Trim();

                            //added 20100423 帶入複式商品資訊
                            drResult["multiplecomno"] = drr["multiplecomno"].ToString().Trim();
                            drrResult["multiplecomno"] = drr["multiplecomno"].ToString().Trim();
                            drResult["multipleBS"] = drr["multipleBS"].ToString().Trim();
                            drrResult["multipleBS"] = drr["multipleBS"].ToString().Trim();

                            drrResult["productName"] = drr["productName"].ToString().Trim();

                            drrResult["callput"] = drr["callput"];
                            drrResult["MKTCOMNO"] = drr["MKTCOMNO"];
                            drrResult["comym"] = drr["comym"];
                            drrResult["stkprc"] = drr["stkprc"];
                            drrResult["stkprc_dec"] = drr["stkprc_dec"];
                            drrResult["COMTYPE"] = drr["COMTYPE"];
                            drrResult["COMNO"] = drr["COMNO"];
                            tempIAMT += double.Parse(drr["IAMT"].ToString());
                            tempMAMT += double.Parse(drr["MAMT"].ToString());

                            tempTAX += double.Parse(drr["TAX"].ToString());
                            tempFEE += double.Parse(drr["FEE"].ToString());
                            tempEQUITY += double.Parse(drr["EQUITY"].ToString());

                        }

                        drrResult["IAMT"] = tempIAMT.ToString();
                        drrResult["MAMT"] = tempMAMT.ToString();

                        drrResult["TAX"] = tempTAX.ToString();
                        drrResult["FEE"] = tempFEE.ToString();
                        drrResult["EQUITY"] = tempEQUITY.ToString();

                        drrResult["TotalOTQTY"] = tempOTQTY.ToString();

                        drResult["PositionQty"] = tempOTQTY.ToString();
                        drResult["initPositionQty"] = tempOTQTY.ToString();

                        if (tempOTQTY == 0)
                        {

                            drResult["PositionPrice"] = "0";
                            drResult["MarketPrice"] = "0";

                            //added 20100414 
                            drrResult["RefTotalPrice"] = "0";
                        }
                        else
                        {
                            double TRDPRC1 = tempTRDPRC1 / tempOTQTY;
                            //added 20100326 四捨五入
                            //double roundoff_TRDPRC1 = Math.Round(TRDPRC1, 2, MidpointRounding.AwayFromZero);
                            double roundoff_TRDPRC1 = TRDPRC1;
                            // drResult["AvgPrice"] = roundoff_TRDPRC1.ToString("#,##0.##");
                            drResult["PositionPrice"] = roundoff_TRDPRC1.ToString("#,##0.####");
                            drrResult["AvgMatchPrice"] = roundoff_TRDPRC1.ToString("#,##0.####");

                            //added 20100414  參考總現值

                            //  double roundoff_tempRefTotalPrice = Math.Round(tempRefTotalPrice, 2, MidpointRounding.AwayFromZero);
                            double roundoff_tempRefTotalPrice = tempRefTotalPrice;
                            drrResult["RefTotalPrice"] = roundoff_tempRefTotalPrice.ToString("#,##0.####");



                            if (drResult["MarketPrice"].ToString().Trim() == "NA")
                            {

                                drrResult["RefTotalPL"] = "0";
                            }
                            else
                            {
                                //added 20100326 四捨五入
                                // double roundoff_tempCurrentBalance = Math.Round(tempCurrentBalance, 2, MidpointRounding.AwayFromZero);
                                double roundoff_tempCurrentBalance = tempCurrentBalance;

                                drrResult["RefTotalPL"] = roundoff_tempCurrentBalance.ToString("#,##0.####");

                            }
                            if (dcFootPrice.Keys.Count > 0)
                            {

                                foreach (int key in dcFootPrice.Keys)
                                {
                                    if (key == 0)
                                    {
                                        drrResult["footMatchPrice"] = (dcFootPrice[key] / tempOTQTY).ToString("#,##0.####");
                                    }
                                    else
                                    {
                                        drrResult["footMatchPrice"] += "\n" + (dcFootPrice[key] / tempOTQTY).ToString("#,##0.####");
                                    }
                                }
                                string[] multiplrice = drrResult["footMatchPrice"].ToString().Split(new string[] { "\n" }, StringSplitOptions.None);
                                if (multiplrice.Length == 2)
                                {
                                    drrResult["multipleMatchPrice1"] = multiplrice[0];
                                    drrResult["multipleMatchPrice2"] = multiplrice[1];
                                }
                            }
                        }


                        //add by samantha 20100415 新增下單夾部位更新

                        string sign = "";
                        if (drResult["bs"].ToString().Trim() == "S")
                        {
                            sign = "-";
                        }
                        else
                        {
                            sign = "";
                        }


                        //added by philip 20100505 新增彙總複式商品組成類別
                        if ((drrResult["productKind"].ToString() == "3" | drrResult["productKind"].ToString() == "4") & drrResult["multipleBS"].ToString() != "" & drrResult["multiplecomno"].ToString() != "")
                        {
                            drrResult["MultiName"] = MultiProductParser(drrResult["productKind"].ToString(), drrResult["multipleBS"].ToString(), drrResult["multiplecomno"].ToString(), drrResult["BS"].ToString().Split('\n')[0].ToString().Trim())[0];
                        }
                        if ((drrResult["productKind"].ToString() == "3" | drrResult["productKind"].ToString() == "4") & drrResult["multiplecomno"].ToString() == "")
                        {
                            drrResult["MultiName"] = "0";
                            drrResult["multiplecomno"] = drrResult["productId"].ToString();
                            drrResult["multipleBS"] = drrResult["BS"].ToString();
                        }


                        mdt_PositionData.Rows.Add(drResult);
                        object[] sss = drrResult.ItemArray;
                        mdt_UnLiquidationMain.Rows.Add(drrResult);

                    }

                }

                return true;
            }

            return true;
            // return false;

        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "unLiquidation_MobInfo" + ex.Message);
            return false;
        }


    }
    //added 20100408 by philip 判別是單式還是複式商品

    //modified 20100413  1(期貨)2(選擇權)3(複式選擇權)4(複式期貨)
    // 精誠  7:單式期貨 0:單式期權  6:複式期貨 12345:複選期權
    //modified by philip 20100429 多增 N:future C:call P:put判斷
    private string spreadType(string spread)
    {
        if (spread == "7")  //單式期貨
        {
            return "1";
        }
        //if (spread == "0" | spread == "C" | spread == "P") //單式選擇權
        else if (spread == "0")
        {
            return "2";
        }
        else if (spread == "6") //複式期貨  
        {
            return "4";
        }
        else if (spread == "1" | spread == "2" | spread == "3" | spread == "4" | spread == "5")  //複式選擇權  
        {
            if (bolCombine)
            {

                return "2";
            }
            else
            {

                return "3";
            }
        }
        else
        {
            return "3";
        }
        return "";
    }

    private string NumberTrim(string value)
    {

        //if (value == "+nan")
        //{
        //    return "N/A";
        //}

        //modified by philip 20100326 數字四捨五入至小數第二位 
        // 將 decimal 都改成 type , 以利於轉型

        // 2010

        // return string.Format("{0:#,#0.####}", Math.Round(double.Parse(value.ToString()), 2, MidpointRounding.AwayFromZero));
        return string.Format("{0:#,#0.####}", double.Parse(value.ToString()));



    }


    //20100226 added by philip 使用 DataAgent.cs getProductId時 1:期貨 , else : 選擇權

    //20100429 modified by philip 多增一個判斷  comtype =="N"
    private string comtypeTransfer(string comtype)
    {

        if (comtype == "0" | comtype == "N")
        {
            return "1";
        }
        else
        {
            return "0";
        }

    }

    //20100226 added by philip 使用 DataAgentcs translate_value 表格  將舊商品名轉成新商品名

    private string ProductNameTrans(string productname, string comtype)
    {

        if (comtype == "0")  //future
        {
            //DataTable dtProductNames = frmMain.mobj_DataAgent.translate_values.Copy();
            DataTable dtProductNames = mdt_translate_values.Copy();
            string command = "field_value='" + productname + "'";
            DataRow[] dr = dtProductNames.Select(command);
            return dr[0]["field_text"].ToString().Trim();
        }
        else   //option
        {
            return productname;
        }

    }

    /// <summary>
    /// MOB CurrentMargin 計算   MOB保證金查詢

    /// </summary>
    //added 20100409 by philip
    private bool unCurrentMargin_MobInfo(string info)
    {
        DataTable infoDT1 = new DataTable();
        Boolean status = false;
        try
        {

            if (info.Substring(0, 1) == "Q") //判斷頭碼是某為 Q  -> 0x51
            {
                infoDT1.Columns.Add(new DataColumn("EXRATE"));//匯率
                infoDT1.Columns.Add(new DataColumn("LCTDAB"));//昨日權益數

                infoDT1.Columns.Add(new DataColumn("LTDAB"));//昨日餘額 
                infoDT1.Columns.Add(new DataColumn("DWAMT"));//出入金

                infoDT1.Columns.Add(new DataColumn("OSPRTLOS"));//期貨平倉損益


                infoDT1.Columns.Add(new DataColumn("PRTLOS"));//期貨未平倉損益

                infoDT1.Columns.Add(new DataColumn("OPTOSPRTLOS"));//選擇權平倉損益

                infoDT1.Columns.Add(new DataColumn("OPTPRTLOS"));//選擇權未平倉損益 
                infoDT1.Columns.Add(new DataColumn("TPREMIUM"));//當日權利金支出收入

                infoDT1.Columns.Add(new DataColumn("ORIGNFEE"));//成交手續費


                infoDT1.Columns.Add(new DataColumn("CTAXAMT"));//成交期交稅

                infoDT1.Columns.Add(new DataColumn("ORDPREMIUM"));//委託預扣權利金

                infoDT1.Columns.Add(new DataColumn("CTDAB"));//權益數

                infoDT1.Columns.Add(new DataColumn("ORDIAMT"));//委託預扣原始保證金

                infoDT1.Columns.Add(new DataColumn("IAMT"));//原始保證金


                infoDT1.Columns.Add(new DataColumn("MAMT"));//維持保證金

                infoDT1.Columns.Add(new DataColumn("ORDCEXCESS"));//下單可用保證金

                infoDT1.Columns.Add(new DataColumn("BPREMIUM"));//買方權利金市值

                infoDT1.Columns.Add(new DataColumn("SPREMIUM"));//賣方權利金市值

                infoDT1.Columns.Add(new DataColumn("QPTEQUITY"));//權益總值


                infoDT1.Columns.Add(new DataColumn("INIRATE"));//原始比率
                infoDT1.Columns.Add(new DataColumn("MATRATE"));//維持比率
                infoDT1.Columns.Add(new DataColumn("OPTRATE"));//清算比率
                infoDT1.Columns.Add(new DataColumn("TWDOPTEQUITY"));//台幣權益總值

                infoDT1.Columns.Add(new DataColumn("TWDINIRATE"));//台幣原始比率

                infoDT1.Columns.Add(new DataColumn("TWDORDEXCESS"));//台幣下單可用保證金

                infoDT1.Columns.Add(new DataColumn("SYSDATE"));//資料更新日期
                infoDT1.Columns.Add(new DataColumn("SYSTIME"));//回傳資料時間
                //-----自訂的欄位--------
                infoDT1.Columns.Add(new DataColumn("DATA_TITLE"));//回傳資料時間
                infoDT1.Columns.Add(new DataColumn("AIMT"));//追繳金額
                infoDT1.Columns.Add(new DataColumn("TOTAL_DAMT"));//有價證券抵繳總額;
                infoDT1.Columns.Add(new DataColumn("STOCKPRICE_VALUE"));//有價證券抵繳價值;

                infoDT1.Columns.Add(new DataColumn("TMP1PRICE"));//20130611 added by peter;  依「加收保證金指標」所加收之保證金
                infoDT1.Columns.Add(new DataColumn("EXCERCISEPRICE"));//20130611 added by peter;//到期履約損益
                infoDT1.Columns.Add(new DataColumn("TMP2PRICE"));//20130709 added by peter; //風險指標

                DataRow dr = infoDT1.NewRow();

                dr["EXRATE"] = NumberTrim(info.Substring(37, 11));//匯率
                dr["LCTDAB"] = NumberTrim(info.Substring(48, 16));//昨日權益數

                dr["LTDAB"] = NumberTrim(info.Substring(64, 16));//昨日餘額 
                dr["DWAMT"] = NumberTrim(info.Substring(80, 16));//出入金

                dr["OSPRTLOS"] = NumberTrim(info.Substring(96, 16));//期貨平倉損益

                dr["PRTLOS"] = NumberTrim(info.Substring(112, 16));//期貨未平倉損益

                dr["OPTOSPRTLOS"] = NumberTrim(info.Substring(128, 16));//選擇權平倉損益

                dr["OPTPRTLOS"] = NumberTrim(info.Substring(144, 16));//選擇權未平倉損益 
                dr["TPREMIUM"] = NumberTrim(info.Substring(160, 16));//當日權利金支出收入

                dr["ORIGNFEE"] = NumberTrim(info.Substring(176, 16));//成交手續費

                dr["CTAXAMT"] = NumberTrim(info.Substring(192, 16));//成交期交稅

                dr["ORDPREMIUM"] = NumberTrim(info.Substring(208, 16));//委託預扣權利金

                dr["CTDAB"] = NumberTrim(info.Substring(224, 16));//權益數

                dr["ORDIAMT"] = NumberTrim(info.Substring(240, 16));//委託預扣原始保證金

                dr["IAMT"] = NumberTrim(info.Substring(256, 16));//原始保證金

                dr["MAMT"] = NumberTrim(info.Substring(272, 16));//維持保證金

                dr["ORDCEXCESS"] = NumberTrim(info.Substring(288, 16));//下單可用保證金

                dr["BPREMIUM"] = NumberTrim(info.Substring(304, 16));//買方權利金市值

                dr["SPREMIUM"] = NumberTrim(info.Substring(320, 16));//賣方權利金市值

                dr["QPTEQUITY"] = NumberTrim(info.Substring(336, 16));//權益總值

                dr["INIRATE"] = NumberTrim(info.Substring(352, 13)) + "%";//原始比率
                dr["MATRATE"] = NumberTrim(info.Substring(365, 13)) + "%";//維持比率
                dr["OPTRATE"] = NumberTrim(info.Substring(378, 13)) + "%";//清算比率
                dr["TWDOPTEQUITY"] = NumberTrim(info.Substring(391, 16));//台幣權益總值

                dr["TWDINIRATE"] = NumberTrim(info.Substring(407, 16)) + "%";//台幣原始比率
                dr["TWDORDEXCESS"] = NumberTrim(info.Substring(423, 16));//台幣下單可用保證金

                dr["SYSDATE"] = info.Substring(439, 8).Insert(4, "/").Insert(7, "/");//資料更新日期
                dr["SYSTIME"] = info.Substring(447, 6).Insert(2, ":").Insert(5, ":");//回傳資料時間

                dr["DATA_TITLE"] = "本日手續費及稅";
                //追繳金額 = 原始保證金 - 權益數  , 其結果為正才顯示
                decimal recover = Convert.ToDecimal(dr["IAMT"].ToString()) - Convert.ToDecimal(dr["CTDAB"].ToString());
                if (decimal.Parse(NumberTrim(info.Substring(365, 13))) >= 100 || decimal.Parse(NumberTrim(info.Substring(365, 13))) == 0)
                {
                    dr["AIMT"] = "無追繳金額";
                }
                else
                {
                    if (recover > 0)
                    {
                        dr["AIMT"] = recover.ToString("#,##0.####");          //追繳金額
                    }
                }
                dr["TOTAL_DAMT"] = NumberTrim(info.Substring(453, 16));//有價證券抵繳總額
                dr["STOCKPRICE_VALUE"] = NumberTrim(info.Substring(469, 16));//有價證券抵繳價值

                dr["TMP1PRICE"] = NumberTrim(info.Substring(485, 16));//20130611 added by peter;

                dr["EXCERCISEPRICE"] = NumberTrim(info.Substring(501, 16));//20130611 added by peter;
                dr["TMP2PRICE"] = NumberTrim(info.Substring(517, 16));//20130709 added by peter;

                infoDT1.Rows.Add(dr);
                #region "註解"
                //if (radComplete.Checked == true)
                //{
                //完整查詢

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[0]["value"] = NumberTrim(info.Substring(37, 11));      //匯率
                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[1]["value"] = NumberTrim(info.Substring(48, 16));       //昨日權益數

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[2]["value"] = NumberTrim(info.Substring(64, 16));       //昨日餘額 
                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[3]["value"] = NumberTrim(info.Substring(80, 16));       //出入金

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[4]["value"] = NumberTrim(info.Substring(96, 16));       //期貨平倉損益

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[5]["value"] = NumberTrim(info.Substring(112, 16));      //期貨未平倉損益

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[6]["value"] = NumberTrim(info.Substring(128, 16));      //選擇權平倉損益 
                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[7]["value"] = NumberTrim(info.Substring(144, 16));      //選擇權未平倉損益 
                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[8]["value"] = NumberTrim(info.Substring(160, 16));      //當日權利金支出收入


                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[9]["value"] = "本日手續費及稅";

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[10]["value"] = NumberTrim(info.Substring(176, 16));      //成交手續費

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[11]["value"] = NumberTrim(info.Substring(192, 16));      //成交期交稅

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[12]["value"] = NumberTrim(info.Substring(208, 16));      //委託預扣權利金

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[13]["value"] = NumberTrim(info.Substring(224, 16));     //權益數

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[14]["value"] = NumberTrim(info.Substring(240, 16));     //委託預扣原始保證金

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[15]["value"] = NumberTrim(info.Substring(256, 16));     //原始保證金

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[16]["value"] = NumberTrim(info.Substring(272, 16));     //維持保證金

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[17]["value"] = NumberTrim(info.Substring(288, 16));     //下單可用保證金

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[18]["value"] = NumberTrim(info.Substring(304, 16));     //買方權利金市值

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[19]["value"] = NumberTrim(info.Substring(320, 16));     //賣方權利金市值

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[20]["value"] = NumberTrim(info.Substring(336, 16));     //權益總值

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[21]["value"] = NumberTrim(info.Substring(352, 13));    //原始比率
                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[22]["value"] = NumberTrim(info.Substring(365, 13));    //維持比率
                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[23]["value"] = NumberTrim(info.Substring(378, 13));    //清算比率

                ////modified by philip 20100319 追繳金額 = 原始保證金 - 權益數  , 其結果為正才顯示
                //decimal recover = Convert.ToDecimal(frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[15]["value"].ToString()) - Convert.ToDecimal(frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[13]["value"].ToString());
                //if (recover < 0)
                //{
                //    frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[24]["value"] = "無追繳金額";
                //    frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrenetMarginRapid.Rows[7]["value"] = "無追繳金額";
                //}
                //else
                //{
                //    frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[24]["value"] = recover.ToString("#,##0.##");          //追繳金額
                //    frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrenetMarginRapid.Rows[7]["value"] = recover.ToString("#,##0.##");
                //}
                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[25]["value"] = NumberTrim(info.Substring(391, 16));    //台幣權益總值

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[26]["value"] = NumberTrim(info.Substring(407, 16));    //台幣原始比率
                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[27]["value"] = NumberTrim(info.Substring(423, 16));    //台幣下單可用保證金

                //// dt.Rows[28]["value"] = NumberTrim(info.Substring(423, 16));  //有價證券抵繳總額

                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[29]["value"] = info.Substring(439, 8).Insert(4, "/").Insert(7, "/");            //資料更新日期
                //frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrentMarginComplete.Rows[30]["value"] = info.Substring(447, 6).Insert(2, ":").Insert(5, ":");                  //回傳資料時間



                //---------------------------------------------------------
                //////displayCompleteQuery();

                //////}
                //////else
                //////{
                //////快速查詢


                ////frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrenetMarginRapid.Rows[0]["value"] = NumberTrim(info.Substring(112, 16));      //期貨未平倉損益

                ////frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrenetMarginRapid.Rows[1]["value"] = NumberTrim(info.Substring(256, 16));     //原始保證金

                ////frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrenetMarginRapid.Rows[2]["value"] = NumberTrim(info.Substring(272, 16));     //維持保證金

                ////frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrenetMarginRapid.Rows[3]["value"] = NumberTrim(info.Substring(288, 16));     //下單可用保證金

                ////frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrenetMarginRapid.Rows[4]["value"] = NumberTrim(info.Substring(336, 16));     //權益總值

                ////frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrenetMarginRapid.Rows[5]["value"] = NumberTrim(info.Substring(365, 13));    //維持比率
                ////frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrenetMarginRapid.Rows[6]["value"] = NumberTrim(info.Substring(378, 13));    //清算比率

                //////decimal recover = Convert.ToDecimal(info.Substring(256, 16)) - Convert.ToDecimal(info.Substring(224, 16));
                ////////modified by philip 20100319 追繳金額 = 原始保證金 - 權益數  , 其結果為正才顯示
                //////if (recover < 0)
                //////{
                //////    frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrenetMarginRapid.Rows[7]["value"] = "無追繳金額";
                //////}
                //////else
                //////{
                //////    frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrenetMarginRapid.Rows[7]["value"] = recover.ToString("#,##0.##");                                        //追繳金額
                //////}

                ////frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrenetMarginRapid.Rows[8]["value"] = info.Substring(439, 8).Insert(4, "/").Insert(7, "/");                  //資料更新日期
                ////frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_MOBCurrenetMarginRapid.Rows[9]["value"] = info.Substring(447, 6).Insert(2, ":").Insert(5, ":");                   //回傳資料時間
                ////// displayQuickQuery();
                //////  }
                #endregion
                status = true;
            }
        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "unCurrentMargin_MobInfo" + ex.Message);

            // AEFutureMaster.frmMain.AOBJ_ErrLog.WriteError(ex.Source, ex.StackTrace.ToString(), ex.Message, System.Diagnostics.EventLogEntryType.Error);
            status = false;
        }
        finally
        {
        }
        mdt_MOBCurrentMargin = infoDT1;
        return status;
    }


    //added 20100419 by philip 計算 MOB即時部位查詢
    //更新 mdt_realpart
    private bool ucCurrentPosition_MobInfo(string info, string productDesc)
    {
        //initializedRealPart();
        try
        {
            if (info.Substring(28, 10).Trim().Length > 0)
            {
                DataRow dr = mdt_RealPart.NewRow();
                ucCurrentPosition_C(info, dr, productDesc);
                mdt_RealPart.Rows.Add(dr);
            }
            //if (int.Parse(info.Substring(76, 4)) != 0) //目前留倉買有口數

            //{
            //    //DataRow dr = frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_RealPart.NewRow();
            //    DataRow dr = mdt_RealPart.NewRow();
            //    ucCurrentPosition_B(info, dr);
            //    mdt_RealPart.Rows.Add(dr);
            //}
            //if (int.Parse(info.Substring(80, 4)) != 0) //目前留倉賣有口數

            //{
            //    //DataRow dr = frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_RealPart.NewRow();
            //    DataRow dr = mdt_RealPart.NewRow();
            //    ucCurrentPosition_S(info, dr);
            //    mdt_RealPart.Rows.Add(dr);
            //}

            ////收到最後一筆時才將return true
            // if (info.Substring(info.Length - 2, 1) == "1" | info.Substring(info.Length - 2, 1) == "9")
            // {

            //     return true;
            // }

            //// return false;

            return true;

        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "ucCurrentPosition_MobInfo" + ex.Message);
            return false;
        }

    }


    //added 20100505 by philip 計算 MOB即時部位Mix查詢
    //更新 mdt_realpartMix
    private bool ucCurrentPositionMix_MobInfo(string info)
    {
        //initializedRealPartMix();
        try
        {
            if (int.Parse(info.Substring(76, 4)) != 0) //目前留倉買有口數
            {
                DataRow dr = mdt_RealPartMix.NewRow();
                ucCurrentPosition_B(info, dr);
                mdt_RealPartMix.Rows.Add(dr);
            }
            if (int.Parse(info.Substring(80, 4)) != 0) //目前留倉賣有口數
            {
                DataRow dr = mdt_RealPartMix.NewRow();
                ucCurrentPosition_S(info, dr);
                mdt_RealPartMix.Rows.Add(dr);
            }

            ////收到最後一筆時才將return true
            if (info.Substring(info.Length - 3, 1) == "1" | info.Substring(info.Length - 3, 1) == "9")
            {

                return true;
            }

            return false;

        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "ucCurrentPositionMix_MobInfo" + ex.Message);
            return false;
        }

    }


    //added 20100503 by philip 即時部位照商品目前留倉賣新增欄位
    private void ucCurrentPosition_S(string info, DataRow dr)
    {

        try
        {
            string CP = info.Substring(41, 1);

            // DataRow dr = frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_RealPart.NewRow();

            dr["investorAcno"] = info.Substring(17, 7);                                                    //帳號    

            //dr["ProductId"] = frmMain.mobj_DataAgent.getProductId(comtypeTransfer(info.Substring(41, 1)), ProductNameTrans(info.Substring(28, 7).Trim(), CP == "N" ? CP = "0" : CP), info.Substring(35, 6), info.Substring(42, 6), info.Substring(41, 1));
            //dr["ProductId"] = this.getProductId(comtypeTransfer(info.Substring(41, 1)), ProductNameTrans(info.Substring(28, 7).Trim(), CP == "N" ? CP = "0" : CP), info.Substring(35, 6), info.Substring(42, 6), info.Substring(41, 1));
            //dr["ProductId"] = info.Substring(35, 20).Trim();
            dr["ProductId"] = info.Substring(28, 20).Trim();
            //目前都先視為單式商品
            dr["productKind"] = spreadType(info.Substring(41, 1));
            //買賣別由目前買進留倉 目前賣出留倉判別 
            dr["BS"] = "S";
            dr["OTQtyB"] = "0";                                                                         //昨日留倉買
            // dr["OTQtyS"] = NumberTrim(info.Substring(52, 4));                                              //昨日留倉賣
            dr["OTQtyS"] = int.Parse(info.Substring(52, 4));
            dr["NowOrderQtyB"] = "0";                                                                  //本日委託買

            // dr["NowOrderQtyS"] = NumberTrim(info.Substring(60, 4));                                        //本日委託賣

            dr["NowOrderQtyS"] = int.Parse(info.Substring(60, 4));
            dr["NowMatchQtyB"] = "0";                                                                   //目前成交買

            // dr["NowMatchQtyS"] = NumberTrim(info.Substring(68, 4));                                        //目前成交賣

            dr["NowMatchQtyS"] = int.Parse(info.Substring(68, 4));
            dr["TodayEnd"] = NumberTrim(info.Substring(72, 4));                                            //本日了結

            //需要串行情 要再討論 => 這個搞不出來

            //  dr["LiquidationPL"] = NumberTrim(info.Substring(72, 4));                                       //平倉損益


            dr["NowOTQtyB"] = "0";                                                                      //目前留倉買
            //dr["NowOTQtyS"] = NumberTrim(info.Substring(80, 4));                                           //目前留倉買
            dr["NowOTQtyS"] = int.Parse(info.Substring(80, 4));


            double cntsize = Math.Round(double.Parse(info.Substring(166, 18)) / 1000000, 2, MidpointRounding.AwayFromZero);
            double realprice = Math.Round(double.Parse(info.Substring(184, 9)) / 100000, 2, MidpointRounding.AwayFromZero);
            dr["RealPrice"] = realprice.ToString("#,##0.##");


            double AvgCostS = Math.Round(double.Parse(info.Substring(93, 9)), 2, MidpointRounding.AwayFromZero);
            dr["AvgCostB"] = "0";                                                                       //平均成本買

            dr["AvgCostS"] = AvgCostS.ToString("#,##0.##");                                                //平均成本賣


            dr["PriceDiffB"] = "0";                                                                     //價差買

            double PriceDiffS = AvgCostS - realprice;
            dr["PriceDiffS"] = PriceDiffS.ToString("#,##0.##");                                            //價差賣


            double PricePL = PriceDiffS * cntsize * double.Parse(dr["NowOTQtyS"].ToString());
            dr["PricePL"] = PricePL.ToString("#,##0.##");                                                 //浮動損益
            dr["Currency"] = info.Substring(25, 3);                                                        //幣別

            //原始投入金額
            //選擇權買方 : ex. TXO買方顯示該筆均價*口數*50；

            //選擇權賣方 : ex. TXO賣方顯示該筆所需保證金；
            //期貨 : ex. 大台顯示該筆所需保證金

            dr["originalCost"] = NumberTrim(info.Substring(118, 16));



            double ROI = (PricePL / double.Parse(dr["originalCost"].ToString())) * 100;
            dr["ROI"] = ROI.ToString("#,##0.##") + "%";                                                    //報酬率

            //dr["fee"] =                                                                                  //手續費

            //dr["tax"] =                                                                                  //期交稅


            // frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_RealPart.Rows.Add(dr);
        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "ucCurrentPosition_S" + ex.Message);
        }



    }



    //added 20100503 by philip 即時部位照商品目前留倉買新增欄位
    private void ucCurrentPosition_B(string info, DataRow dr)
    {
        try
        {
            string CP = info.Substring(41, 1);

            //DataRow dr = frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_RealPart.NewRow();

            dr["investorAcno"] = info.Substring(17, 7);                                                    //帳號    

            //dr["ProductId"] = frmMain.mobj_DataAgent.getProductId(comtypeTransfer(info.Substring(41, 1)), ProductNameTrans(info.Substring(28, 7).Trim(), CP == "N" ? CP = "0" : CP), info.Substring(35, 6), info.Substring(42, 6), info.Substring(41, 1));
            //dr["ProductId"] = getProductId(comtypeTransfer(info.Substring(41, 1)), ProductNameTrans(info.Substring(28, 7).Trim(), CP == "N" ? CP = "0" : CP), info.Substring(35, 6), info.Substring(42, 6), info.Substring(41, 1));
            //dr["ProductId"] = info.Substring(35,20).Trim();
            dr["ProductId"] = info.Substring(28, 20).Trim();
            //目前都先視為單式商品
            dr["productKind"] = spreadType(info.Substring(41, 1));
            //買賣別由目前買進留倉 目前賣出留倉判別 
            dr["BS"] = "B";
            dr["OTQtyB"] = int.Parse(info.Substring(48, 4));                                              //昨日留倉買
            dr["OTQtyS"] = "0";                                                                         //昨日留倉賣
            // dr["NowOrderQtyB"] = NumberTrim(info.Substring(56, 4));                                        //本日委託買

            dr["NowOrderQtyB"] = int.Parse(info.Substring(56, 4));
            dr["NowOrderQtyS"] = "0";                                                                   //本日委託賣

            dr["NowMatchQtyB"] = NumberTrim(info.Substring(64, 4));                                        //目前成交買

            dr["NowMatchQtyB"] = int.Parse(info.Substring(64, 4));
            dr["NowMatchQtyS"] = "0";                                                                   //目前成交賣

            dr["TodayEnd"] = NumberTrim(info.Substring(72, 4));                                            //本日了結

            //需要串行情 要再討論=> 這個搞不出來

            // dr["LiquidationPL"] = NumberTrim(info.Substring(72, 4));                                       //平倉損益


            // dr["NowOTQtyB"] = NumberTrim(info.Substring(76, 4));                                           //目前留倉買
            dr["NowOTQtyB"] = int.Parse(info.Substring(76, 4));
            dr["NowOTQtyS"] = "0";                                                                      //目前留倉買


            double cntsize = Math.Round(double.Parse(info.Substring(166, 18)) / 1000000, 2, MidpointRounding.AwayFromZero);
            double realprice = Math.Round(double.Parse(info.Substring(184, 9)) / 100000, 2, MidpointRounding.AwayFromZero);
            dr["RealPrice"] = realprice.ToString("#,##0.##");                                              //即時價位


            double AvgCostB = Math.Round(double.Parse(info.Substring(84, 9)), 2, MidpointRounding.AwayFromZero);
            dr["AvgCostB"] = AvgCostB.ToString("#,##0.##");                                                //平均成本買

            dr["AvgCostS"] = "0";                                                                       //平均成本賣



            double PriceDiffB = realprice - AvgCostB;
            dr["PriceDiffB"] = PriceDiffB.ToString("#,##0.##");                                           //價差買

            dr["PriceDiffS"] = "0";                                                                    //價差賣


            double PricePL = PriceDiffB * cntsize * double.Parse(dr["NowOTQtyB"].ToString());
            dr["PricePL"] = PricePL.ToString("#,##0.##");                                                //浮動損益

            dr["Currency"] = info.Substring(25, 3);                                                        //幣別

            //原始投入金額
            //選擇權買方 : ex. TXO買方顯示該筆均價*口數*50；

            //選擇權賣方 : ex. TXO賣方顯示該筆所需保證金；
            //期貨 : ex. 大台顯示該筆所需保證金

            if (CP == "N") //future
            {
                dr["originalCost"] = NumberTrim(info.Substring(102, 16));
            }
            else  // option
            {
                dr["originalCost"] = AvgCostB * double.Parse(dr["NowOTQtyB"].ToString()) * cntsize;
            }

            double ROI = (PricePL / double.Parse(dr["originalCost"].ToString())) * 100;
            dr["ROI"] = ROI.ToString("#,##0.##") + "%";                                                    //報酬率

            //dr["fee"] =                                                                                  //手續費

            //dr["tax"] =     

            // frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_RealPart.Rows.Add(dr);
        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "ucCurrentPosition_B" + ex.Message);
        }


    }

    private void ucCurrentPosition_C(string info, DataRow dr, string productDesc)
    {
        try
        {

            string CP = info.Substring(41, 1);

            dr["investorAcno"] = info.Substring(17, 7);                                                    //帳號    

            dr["ProductId"] = info.Substring(28, 10).Trim();
            string period = getOptionPeriod(dr["productId"].ToString().Substring(dr["productId"].ToString().Length - 2, 1)).ToString();
            string cp = "N";
            string strikeprice = "0";
            if (dr["ProductId"].ToString().Length > 5)
            {
                cp = getOptionCP(dr["productId"].ToString().Substring(8, 1));
                strikeprice = decimal.Parse(dr["productId"].ToString().Substring(3, 5)).ToString("#0.#");
                dr["COMTYPE"] = "1";

                dr["productKind"] = "2";
                dr["productName"] = productDesc + strikeprice + cp + period;
            }
            else
            {
                dr["COMTYPE"] = "0";
                dr["productKind"] = "1";
                dr["productName"] = productDesc + period;
            }

            dr["COMNO"] = info.Substring(209, 7);


            dr["MKTCOMNO"] = dr["ProductId"].ToString().Substring(0, 3);
            dr["COMYM"] = "201" + dr["productId"].ToString().Substring(dr["productId"].ToString().Length - 1, 1) + getOptionPeriod(dr["productId"].ToString().Substring(dr["productId"].ToString().Length - 2, 1)).ToString().PadLeft(2, '0');
            dr["STKPRC"] = strikeprice;
            dr["CALLPUT"] = cp;
            //買賣別由目前買進留倉 目前賣出留倉判別 
            dr["BS"] = "";
            dr["OTQtyB"] = int.Parse(info.Substring(48, 4));                                                  //昨日留倉買
            dr["OTQtyS"] = int.Parse(info.Substring(52, 4));                                              //昨日留倉賣

            dr["NowOrderQtyB"] = int.Parse(info.Substring(56, 4));                                       //本日委託買
            dr["NowOrderQtyS"] = int.Parse(info.Substring(60, 4));                                        //本日委託賣

            dr["NowMatchQtyB"] = int.Parse(info.Substring(64, 4));                                        //目前成交買
            dr["NowMatchQtyS"] = int.Parse(info.Substring(68, 4));                                      //目前成交賣

            dr["TodayEnd"] = NumberTrim(info.Substring(72, 4));                                            //本日了結

            //需要串行情 要再討論 => 這個搞不出來
            dr["LiquidationPL"] = NumberTrim(info.Substring(193, 16));                                       //平倉損益

            dr["NowOTQtyB"] = int.Parse(info.Substring(76, 4));                                             //目前留倉買
            dr["NowOTQtyS"] = int.Parse(info.Substring(80, 4));                                           //目前留倉買



            double cntsize = Math.Round(double.Parse(info.Substring(166, 18)) / 1000000, 2, MidpointRounding.AwayFromZero);
            double realprice = double.Parse(info.Substring(184, 9)) / 10000;
            dr["RealPrice"] = realprice.ToString("#,##0.####");


            double AvgCostS = Math.Round(double.Parse(info.Substring(93, 9)), 2, MidpointRounding.AwayFromZero);
            double AvgCostB = Math.Round(double.Parse(info.Substring(84, 9)), 2, MidpointRounding.AwayFromZero);
            dr["AvgCostB"] = AvgCostB.ToString("#,##0.##");                                                //平均成本買  
            dr["AvgCostS"] = AvgCostS.ToString("#,##0.##");                                                //平均成本賣
            double PriceDiffB = 0;
            dr["PriceDiffB"] = PriceDiffB;
            if (int.Parse(dr["NowOTQtyB"].ToString()) > 0) //  dr["NowOTQtyB"]
            {
                PriceDiffB = realprice - AvgCostB;
                dr["PriceDiffB"] = PriceDiffB.ToString("#,##0.##");                                           //價差買              
            }

            double PriceDiffS = 0;
            dr["PriceDiffS"] = PriceDiffS;
            if (int.Parse(dr["NowOTQtyS"].ToString()) > 0) //  dr["NowOTQtyB"]
            {
                PriceDiffS = AvgCostS - realprice;
                dr["PriceDiffS"] = PriceDiffS.ToString("#,##0.##");                                            //價差賣
            }
            double PricePL = PriceDiffS * cntsize * double.Parse(dr["NowOTQtyS"].ToString()) + PriceDiffB * cntsize * double.Parse(dr["NowOTQtyB"].ToString());


            dr["PricePL"] = PricePL.ToString("#,##0.##");                                                 //浮動損益
            dr["Currency"] = info.Substring(25, 3);                                                        //幣別

            //原始投入金額
            //選擇權買方 : ex. TXO買方顯示該筆均價*口數*50；
            //選擇權賣方 : ex. TXO賣方顯示該筆所需保證金；
            //期貨 : ex. 大台顯示該筆所需保證金
            if (CP == "0") //future
            {
                // dr["originalCost"] = NumberTrim(info.Substring(102, 16))  NumberTrim(info.Substring(118, 16));
                double originalCost = double.Parse(info.Substring(102, 16)) + double.Parse(info.Substring(118, 16));
                dr["originalCost"] = NumberTrim(originalCost.ToString());
            }
            else  // option
            {
                //  dr["originalCost"] = AvgCostB * double.Parse(dr["NowOTQtyB"].ToString()) * cntsize ;
                dr["originalCost"] = NumberTrim((AvgCostB * double.Parse(dr["NowOTQtyB"].ToString()) * cntsize + double.Parse(info.Substring(118, 16))).ToString());


            }



            //added by samantha 20100927 保證金和損益是0就不算
            if (dr["PricePL"].ToString() != "" && dr["PricePL"].ToString() != "0" && ((decimal)dr["originalCost"]) != 0)
            {
                double ROI = (PricePL / double.Parse(dr["originalCost"].ToString())) * 100;
                dr["ROI"] = ROI.ToString("#,##0.##") + "%";                                                    //報酬率
            }
            else
            {
                dr["ROI"] = "0%";
            }
            //dr["fee"] =                                                                                  //手續費
            //dr["tax"] =                                                                                  //期交稅

            // frmMain.mobj_DataAgent.mobj_TradeStringHandle.mdt_RealPart.Rows.Add(dr);

            // return dr["ProductId"].ToString().Trim();

        }
        catch (Exception ex)
        {
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "ucCurrentPosition_C" + ex.Message);
            //return dr["ProductId"].ToString().Trim();
        }


    }


    //--------------------------------初始化各table 的table schema-------------------------
    /// <summary>
    /// init RealPart dt
    /// </summary>
    private void initializedRealPart()
    {
        mdt_RealPart = new DataTable("CurrentPosition");
        mdt_RealPart.Columns.Add("SYSDATE").DefaultValue = DateTime.Now.ToString("yyyy/MM/dd");
        mdt_RealPart.Columns.Add("SYSTIME").DefaultValue = DateTime.Now.ToString("HH:mm:ss");
        mdt_RealPart.Columns.Add("investorAcno", typeof(string)).DefaultValue = "";    //帳號   
        mdt_RealPart.Columns.Add("ProductId", typeof(string)).DefaultValue = "";     //商品碼  
        mdt_RealPart.Columns.Add("productKind", typeof(string)).DefaultValue = "";    //商品類別 
        mdt_RealPart.Columns.Add("BS", typeof(string)).DefaultValue = "";//買賣別

        mdt_RealPart.Columns.Add("OTQtyB", typeof(string)).DefaultValue = "";    //昨日留倉買
        mdt_RealPart.Columns.Add("OTQtyS", typeof(string)).DefaultValue = "";    //昨日留倉賣
        mdt_RealPart.Columns.Add("NowOrderQtyB", typeof(string)).DefaultValue = "";    //本日委託買

        mdt_RealPart.Columns.Add("NowOrderQtyS", typeof(string)).DefaultValue = "";    //本日委託賣

        mdt_RealPart.Columns.Add("NowMatchQtyB", typeof(string)).DefaultValue = "";    //目前成交買

        mdt_RealPart.Columns.Add("NowMatchQtyS", typeof(string)).DefaultValue = "";    //目前成交賣

        mdt_RealPart.Columns.Add("TodayEnd", typeof(string)).DefaultValue = "";    //本日了結
        mdt_RealPart.Columns.Add("LiquidationPL", typeof(decimal));    //平倉損益

        mdt_RealPart.Columns["LiquidationPL"].DefaultValue = 0;
        mdt_RealPart.Columns.Add("NowOTQtyB", typeof(string)).DefaultValue = "";    //目前留倉買
        mdt_RealPart.Columns.Add("NowOTQtyS", typeof(string)).DefaultValue = "";    //目前留倉賣
        mdt_RealPart.Columns.Add("RealPrice", typeof(string)).DefaultValue = "";    //即時價位
        mdt_RealPart.Columns.Add("AvgCostB", typeof(string)).DefaultValue = "";    //平均成本買

        mdt_RealPart.Columns.Add("AvgCostS", typeof(string)).DefaultValue = "";    //平均成本賣

        mdt_RealPart.Columns.Add("PriceDiffB", typeof(string)).DefaultValue = "";    //價差買

        mdt_RealPart.Columns.Add("PriceDiffS", typeof(string)).DefaultValue = "";    //價差賣

        mdt_RealPart.Columns.Add("PricePL", typeof(string)).DefaultValue = "";    //浮動損益
        mdt_RealPart.Columns.Add("Currency", typeof(string)).DefaultValue = "";    //幣別

        //added 20100416 by philip MOB CurrentPosition擴欄位

        mdt_RealPart.Columns.Add("originalCost", typeof(decimal)).DefaultValue = 0;       //原始投入金額
        mdt_RealPart.Columns.Add("ROI", typeof(string)).DefaultValue = "";                 //報酬率

        mdt_RealPart.Columns.Add("fee", typeof(string)).DefaultValue = "";                //手續費

        mdt_RealPart.Columns.Add("tax", typeof(string)).DefaultValue = "";                //期交稅


        ////added 20100428 by philip 供複式即時更新 擴欄位

        //mdt_RealPart.Columns.Add("multipleMatchPrice1", typeof(string));                //複式商品第1隻腳成交價

        //mdt_RealPart.Columns["multipleMatchPrice1"].DefaultValue = "0";
        //mdt_RealPart.Columns.Add("multipleMatchPrice2", typeof(string));                //複式商品第2隻腳成交價

        //mdt_RealPart.Columns["multipleMatchPrice2"].DefaultValue = "0";

        mdt_RealPart.Columns.Add("productName").DefaultValue = "";

        mdt_RealPart.Columns.Add("COMTYPE").DefaultValue = "";
        mdt_RealPart.Columns.Add("COMNO").DefaultValue = "";
        mdt_RealPart.Columns.Add("MKTCOMNO").DefaultValue = "";
        mdt_RealPart.Columns.Add("COMYM").DefaultValue = "";
        mdt_RealPart.Columns.Add("CALLPUT").DefaultValue = "";
        mdt_RealPart.Columns.Add("STKPRC").DefaultValue = "";
        DataColumn[] dcPrimaryKey = { mdt_RealPart.Columns["investorAcno"], mdt_RealPart.Columns["ProductId"], mdt_RealPart.Columns["BS"] };
        mdt_RealPart.PrimaryKey = dcPrimaryKey;
        mdt_RealPart.CaseSensitive = true;

    }

    /// <summary>
    /// init RealPart dt  added by philip 20100506 
    /// </summary>
    private void initializedRealPartMix()
    {
        this.mdt_RealPartMix = new DataTable("RealPartMix");

        this.mdt_RealPartMix.Columns.Add("investorAcno", typeof(string));    //帳號   
        this.mdt_RealPartMix.Columns.Add("ProductId", typeof(string));     //商品碼  
        this.mdt_RealPartMix.Columns.Add("productKind", typeof(string));    //商品類別 
        this.mdt_RealPartMix.Columns.Add("BS", typeof(string));//買賣別

        this.mdt_RealPartMix.Columns.Add("OTQtyB", typeof(string));    //昨日留倉買
        this.mdt_RealPartMix.Columns.Add("OTQtyS", typeof(string));    //昨日留倉賣
        this.mdt_RealPartMix.Columns.Add("NowOrderQtyB", typeof(string));    //本日委託買

        this.mdt_RealPartMix.Columns.Add("NowOrderQtyS", typeof(string));    //本日委託賣

        this.mdt_RealPartMix.Columns.Add("NowMatchQtyB", typeof(string));    //目前成交買

        this.mdt_RealPartMix.Columns.Add("NowMatchQtyS", typeof(string));    //目前成交賣

        this.mdt_RealPartMix.Columns.Add("TodayEnd", typeof(string));    //本日了結
        this.mdt_RealPartMix.Columns.Add("LiquidationPL", typeof(decimal));    //平倉損益

        this.mdt_RealPartMix.Columns["LiquidationPL"].DefaultValue = 0;
        this.mdt_RealPartMix.Columns.Add("NowOTQtyB", typeof(string));    //目前留倉買
        this.mdt_RealPartMix.Columns.Add("NowOTQtyS", typeof(string));    //目前留倉賣
        this.mdt_RealPartMix.Columns.Add("RealPrice", typeof(string));    //即時價位
        this.mdt_RealPartMix.Columns.Add("AvgCostB", typeof(string));    //平均成本買

        this.mdt_RealPartMix.Columns.Add("AvgCostS", typeof(string));    //平均成本賣

        this.mdt_RealPartMix.Columns.Add("PriceDiffB", typeof(string));    //價差買

        this.mdt_RealPartMix.Columns.Add("PriceDiffS", typeof(string));    //價差賣

        this.mdt_RealPartMix.Columns.Add("PricePL", typeof(string));    //浮動損益
        this.mdt_RealPartMix.Columns.Add("Currency", typeof(string));    //幣別

        //added 20100416 by philip MOB CurrentPosition擴欄位

        this.mdt_RealPartMix.Columns.Add("originalCost", typeof(decimal));       //原始投入金額
        this.mdt_RealPartMix.Columns.Add("ROI", typeof(string));                 //報酬率

        this.mdt_RealPartMix.Columns.Add("fee", typeof(string));                //手續費

        this.mdt_RealPartMix.Columns.Add("tax", typeof(string));                //期交稅


        //added 20100428 by philip 供複式即時更新 擴欄位

        this.mdt_RealPartMix.Columns.Add("multipleMatchPrice1", typeof(string));                //複式商品第1隻腳成交價

        this.mdt_RealPartMix.Columns["multipleMatchPrice1"].DefaultValue = "0";
        this.mdt_RealPartMix.Columns.Add("multipleMatchPrice2", typeof(string));                //複式商品第2隻腳成交價

        this.mdt_RealPartMix.Columns["multipleMatchPrice2"].DefaultValue = "0";


        DataColumn[] dcPrimaryKey = { this.mdt_RealPartMix.Columns["investorAcno"], this.mdt_RealPartMix.Columns["ProductId"], this.mdt_RealPartMix.Columns["BS"] };
        this.mdt_RealPartMix.PrimaryKey = dcPrimaryKey;
    }

    /// <summary>
    /// init UnLiquidationDetail dt
    /// </summary>
    private void initializedUnLiquidationDetail()
    {
        this.mdt_UnLiquidationDetail = new DataTable("PositionDetail");

        //added 201004013 by philip
        this.mdt_UnLiquidationDetail.Columns.Add("currency", typeof(string)).DefaultValue = "";  //幣別

        this.mdt_UnLiquidationDetail.Columns.Add("investorAcno", typeof(string)).DefaultValue = "";//下單帳號
        this.mdt_UnLiquidationDetail.Columns.Add("tradedate", typeof(string)).DefaultValue = "";
        this.mdt_UnLiquidationDetail.Columns.Add("matchTime", typeof(string)).DefaultValue = "";//成交時間
        this.mdt_UnLiquidationDetail.Columns.Add("orderNo", typeof(string)).DefaultValue = "";//成交單號
        this.mdt_UnLiquidationDetail.Columns.Add("BS", typeof(string)).DefaultValue = "";//買賣別

        this.mdt_UnLiquidationDetail.Columns.Add("productId", typeof(string)).DefaultValue = "";//商品代碼

        this.mdt_UnLiquidationDetail.Columns.Add("MatchPrice", typeof(decimal)).DefaultValue = "0";//成交價格

        this.mdt_UnLiquidationDetail.Columns.Add("RefRealPrice", typeof(string)).DefaultValue = "";//參考即時價
        this.mdt_UnLiquidationDetail.Columns.Add("OTQTY", typeof(decimal)).DefaultValue = "0";//留倉口數

        this.mdt_UnLiquidationDetail.Columns.Add("RefNowPrice", typeof(string)).DefaultValue = "";//參考現值

        this.mdt_UnLiquidationDetail.Columns.Add("RefPL", typeof(string)).DefaultValue = "";//參考浮動損益

        this.mdt_UnLiquidationDetail.Columns.Add("DTOVER", typeof(string)).DefaultValue = "";//當沖
        this.mdt_UnLiquidationDetail.Columns.Add("productKind", typeof(string)).DefaultValue = "";    //商品類別 
        this.mdt_UnLiquidationDetail.Columns.Add("matchseq", typeof(string)).DefaultValue = "";//網路流水序號
        mdt_UnLiquidationDetail.Columns.Add("multiplecomno", typeof(string)).DefaultValue = "";    //商品碼        
        mdt_UnLiquidationDetail.Columns.Add("multipleBS", typeof(string)).DefaultValue = "";       //買賣別    


        this.mdt_UnLiquidationDetail.Columns.Add("TatolMatchPrice", typeof(decimal)).DefaultValue = "0";//成交價格
        this.mdt_UnLiquidationDetail.Columns["TatolMatchPrice"].Expression = "MatchPrice*OTQTY";

        //added 20100427 by philip 多擴兩個欄位供複式商品存成交價
        mdt_UnLiquidationDetail.Columns.Add("multipleMatchPrice1", typeof(string)).DefaultValue = "";       //複式商品成交價1
        mdt_UnLiquidationDetail.Columns["multipleMatchPrice1"].DefaultValue = "0";
        mdt_UnLiquidationDetail.Columns.Add("multipleMatchPrice2", typeof(string)).DefaultValue = "";       //複式商品成交價2
        mdt_UnLiquidationDetail.Columns["multipleMatchPrice2"].DefaultValue = "0";


        mdt_UnLiquidationDetail.Columns.Add("productName").DefaultValue = "";
        mdt_UnLiquidationDetail.Columns.Add("callput").DefaultValue = "";
        mdt_UnLiquidationDetail.Columns.Add("COMTYPE").DefaultValue = "";
        mdt_UnLiquidationDetail.Columns.Add("COMNO").DefaultValue = "";
        mdt_UnLiquidationDetail.Columns.Add("MKTCOMNO").DefaultValue = "";
        mdt_UnLiquidationDetail.Columns.Add("COMYM").DefaultValue = "";
        mdt_UnLiquidationDetail.Columns.Add("stkprc", typeof(string)).DefaultValue = "";
        mdt_UnLiquidationDetail.Columns.Add("stkprc_dec", typeof(decimal)).DefaultValue = "0";

        //added by samantha 20101005 顯示每腳價位
        mdt_UnLiquidationDetail.Columns.Add("footMatchPrice").DefaultValue = "";
        mdt_UnLiquidationDetail.Columns.Add("IAMT").DefaultValue = "";
        mdt_UnLiquidationDetail.Columns.Add("MAMT").DefaultValue = "";

        mdt_UnLiquidationDetail.Columns.Add("TAX").DefaultValue = "";
        mdt_UnLiquidationDetail.Columns.Add("FEE").DefaultValue = "";
        mdt_UnLiquidationDetail.Columns.Add("EQUITY").DefaultValue = "";

        DataColumn[] dcPrimaryKey = { this.mdt_UnLiquidationDetail.Columns["investorAcno"], this.mdt_UnLiquidationDetail.Columns["matchseq"], this.mdt_UnLiquidationDetail.Columns["tradedate"], this.mdt_UnLiquidationDetail.Columns["matchTime"], this.mdt_UnLiquidationDetail.Columns["productId"], this.mdt_UnLiquidationDetail.Columns["orderNo"] };
        this.mdt_UnLiquidationDetail.PrimaryKey = dcPrimaryKey;
        mdt_UnLiquidationDetail.CaseSensitive = true;

    }

    /// <summary>
    /// 初始部位Table
    /// </summary>
    private void initializedPositionData()
    {
        mdt_PositionData = new DataTable("PositionData");
        mdt_PositionData.Columns.Add("investorAcno", typeof(string));       //帳號   
        mdt_PositionData.Columns.Add("ProductId", typeof(string));          //商品碼        
        mdt_PositionData.Columns.Add("BS", typeof(string));                 //買賣別    
        mdt_PositionData.Columns.Add("initBS", typeof(string));             //買賣別    
        mdt_PositionData.Columns.Add("initPositionQty", typeof(string));    //初始昨日留倉數  
        mdt_PositionData.Columns.Add("PositionQty", typeof(string));        //部位口數        
        mdt_PositionData.Columns.Add("PositionPrice", typeof(string));      //部位均價        
        mdt_PositionData.Columns.Add("MarketPrice", typeof(string));        //市價        
        mdt_PositionData.Columns.Add("BPrice", typeof(string));             //B均價    
        mdt_PositionData.Columns.Add("SPrice", typeof(string));             //S均價
        mdt_PositionData.Columns.Add("SEQ", typeof(string));                //序號
        mdt_PositionData.Columns.Add("productKind", typeof(string));        //商品類別 
        mdt_PositionData.Columns.Add("multiplecomno", typeof(string));    //商品碼        
        mdt_PositionData.Columns.Add("multipleBS", typeof(string));       //買賣別    


        //DataColumn[] dcPrimaryKey ={ mdt_PositionData.Columns["investorAcno"], mdt_PositionData.Columns["ProductId"], mdt_PositionData.Columns["BS"] };
        //mdt_PositionData.PrimaryKey = dcPrimaryKey;

        //modified by philip 20100416 多加一個key值

        DataColumn[] dcPrimaryKey = { mdt_PositionData.Columns["investorAcno"], mdt_PositionData.Columns["ProductId"], mdt_PositionData.Columns["BS"], mdt_PositionData.Columns["productKind"] };
        mdt_PositionData.PrimaryKey = dcPrimaryKey;

    }
    /// <summary>
    /// init UnLiquidationMain dt
    /// </summary>
    private void initializedTotalUnLiquidation()
    {
        this.mdt_TotalUnLiquidation = new DataTable("PositionMain");

        mdt_TotalUnLiquidation.Columns.Add("SYSDATE").DefaultValue = DateTime.Now.ToString("yyyy/MM/dd");
        mdt_TotalUnLiquidation.Columns.Add("SYSTIME").DefaultValue = DateTime.Now.ToString("HH:mm:ss");


        this.mdt_TotalUnLiquidation.Columns.Add("investorAcno", typeof(string)).DefaultValue = "";    //帳號   
        this.mdt_TotalUnLiquidation.Columns.Add("BS", typeof(string)).DefaultValue = "";             //買賣別   
        this.mdt_TotalUnLiquidation.Columns.Add("ProductId", typeof(string)).DefaultValue = "";     //商品碼  
        this.mdt_TotalUnLiquidation.Columns.Add("TotalOTQTY", typeof(string)).DefaultValue = "";     //總留倉口數 
        //this._dtMain.Columns.Add("NowOTQTY", typeof(string));         //當約口數 
        this.mdt_TotalUnLiquidation.Columns.Add("RefTotalPrice", typeof(string)).DefaultValue = "";     //參考總現值 
        this.mdt_TotalUnLiquidation.Columns.Add("RefTotalPL", typeof(string)).DefaultValue = "";     //參考總浮動損益
        this.mdt_TotalUnLiquidation.Columns.Add("AvgMatchPrice", typeof(double)).DefaultValue = 0;     //平均成交價

        // this.mdt_UnLiquidationMain.Columns.Add("DTOVER", typeof(string));              //當沖
        this.mdt_TotalUnLiquidation.Columns.Add("productKind", typeof(string)).DefaultValue = "";    //商品類別 

        //added 20100413 by philip
        mdt_TotalUnLiquidation.Columns.Add("currency", typeof(string)).DefaultValue = "";           //幣別

        //------modify by cedric 20100623 -------
        mdt_TotalUnLiquidation.Columns.Add("realPrice", typeof(double)).DefaultValue = 0;    //即時價
        //mdt_UnLiquidationMain.Columns.Add("realPrice", typeof(string));    //即時價
        //-----------------------------------------


        mdt_TotalUnLiquidation.Columns.Add("multiplecomno", typeof(string)).DefaultValue = "";    //商品碼        
        mdt_TotalUnLiquidation.Columns.Add("multipleBS", typeof(string)).DefaultValue = "";       //買賣別  

        //added 20100427 by philip 多擴兩個欄位供複式商品存成交價
        mdt_TotalUnLiquidation.Columns.Add("multipleMatchPrice1", typeof(string)).DefaultValue = "";       //複式商品成交價1
        mdt_TotalUnLiquidation.Columns["multipleMatchPrice1"].DefaultValue = "0";
        mdt_TotalUnLiquidation.Columns.Add("multipleMatchPrice2", typeof(string)).DefaultValue = "";       //複式商品成交價2
        mdt_TotalUnLiquidation.Columns["multipleMatchPrice2"].DefaultValue = "0";

        //added 20100505 by philip 價差供 即時組合部位查詢 使用
        mdt_TotalUnLiquidation.Columns.Add("PriceDiff", typeof(double)).DefaultValue = 0;                 //價差
        mdt_TotalUnLiquidation.Columns["PriceDiff"].Expression = "IIF(BS='B',realPrice-AvgMatchPrice ,AvgMatchPrice-realPrice) ";
        mdt_TotalUnLiquidation.Columns.Add("MultiName", typeof(string)).DefaultValue = "";                 //組合類型

        //added by samantha 20101005 顯示每腳價位
        mdt_TotalUnLiquidation.Columns.Add("footMatchPrice").DefaultValue = "";

        mdt_TotalUnLiquidation.Columns.Add("productName").DefaultValue = "";
        mdt_TotalUnLiquidation.Columns.Add("COMTYPE").DefaultValue = "";
        mdt_TotalUnLiquidation.Columns.Add("COMNO").DefaultValue = "";
        mdt_TotalUnLiquidation.Columns.Add("callput").DefaultValue = "";
        mdt_TotalUnLiquidation.Columns.Add("MKTCOMNO").DefaultValue = "";
        mdt_TotalUnLiquidation.Columns.Add("COMYM").DefaultValue = "";
        mdt_TotalUnLiquidation.Columns.Add("stkprc", typeof(string)).DefaultValue = "";
        mdt_TotalUnLiquidation.Columns.Add("stkprc_dec", typeof(decimal)).DefaultValue = "0";
        mdt_TotalUnLiquidation.Columns.Add("IAMT").DefaultValue = "";
        mdt_TotalUnLiquidation.Columns.Add("MAMT").DefaultValue = "";

        mdt_TotalUnLiquidation.Columns.Add("TAX", typeof(double)).DefaultValue = 0;
        mdt_TotalUnLiquidation.Columns.Add("FEE", typeof(double)).DefaultValue = 0;
        mdt_TotalUnLiquidation.Columns.Add("EQUITY", typeof(double)).DefaultValue = 0;

        mdt_TotalUnLiquidation.CaseSensitive = true;
        DataColumn[] dcPrimaryKey = { this.mdt_TotalUnLiquidation.Columns["investorAcno"]
                                        , this.mdt_TotalUnLiquidation.Columns["ProductId"]
                                        , this.mdt_TotalUnLiquidation.Columns["BS"]
                                        , this.mdt_TotalUnLiquidation.Columns["productKind"] };
        this.mdt_TotalUnLiquidation.PrimaryKey = dcPrimaryKey;
    }
    /// <summary>
    /// init UnLiquidationMain dt
    /// </summary>
    private void initializedUnLiquidationMain()
    {
        this.mdt_UnLiquidationMain = new DataTable("PositionMain");

        mdt_UnLiquidationMain.Columns.Add("SYSDATE").DefaultValue = DateTime.Now.ToString("yyyy/MM/dd");
        mdt_UnLiquidationMain.Columns.Add("SYSTIME").DefaultValue = DateTime.Now.ToString("HH:mm:ss");


        this.mdt_UnLiquidationMain.Columns.Add("investorAcno", typeof(string)).DefaultValue = "";    //帳號   
        this.mdt_UnLiquidationMain.Columns.Add("BS", typeof(string)).DefaultValue = "";             //買賣別   
        this.mdt_UnLiquidationMain.Columns.Add("ProductId", typeof(string)).DefaultValue = "";     //商品碼  
        this.mdt_UnLiquidationMain.Columns.Add("TotalOTQTY", typeof(string)).DefaultValue = "";     //總留倉口數 
        //this._dtMain.Columns.Add("NowOTQTY", typeof(string));         //當約口數 
        this.mdt_UnLiquidationMain.Columns.Add("RefTotalPrice", typeof(string)).DefaultValue = "";     //參考總現值 
        this.mdt_UnLiquidationMain.Columns.Add("RefTotalPL", typeof(string)).DefaultValue = "";     //參考總浮動損益
        this.mdt_UnLiquidationMain.Columns.Add("AvgMatchPrice", typeof(double)).DefaultValue = 0;     //平均成交價

        // this.mdt_UnLiquidationMain.Columns.Add("DTOVER", typeof(string));              //當沖
        this.mdt_UnLiquidationMain.Columns.Add("productKind", typeof(string)).DefaultValue = "";    //商品類別 

        //added 20100413 by philip
        mdt_UnLiquidationMain.Columns.Add("currency", typeof(string)).DefaultValue = "";           //幣別

        //------modify by cedric 20100623 -------
        mdt_UnLiquidationMain.Columns.Add("realPrice", typeof(double)).DefaultValue = 0;    //即時價
        //mdt_UnLiquidationMain.Columns.Add("realPrice", typeof(string));    //即時價
        //-----------------------------------------


        mdt_UnLiquidationMain.Columns.Add("multiplecomno", typeof(string)).DefaultValue = "";    //商品碼        
        mdt_UnLiquidationMain.Columns.Add("multipleBS", typeof(string)).DefaultValue = "";       //買賣別  

        //added 20100427 by philip 多擴兩個欄位供複式商品存成交價
        mdt_UnLiquidationMain.Columns.Add("multipleMatchPrice1", typeof(string)).DefaultValue = "";       //複式商品成交價1
        mdt_UnLiquidationMain.Columns["multipleMatchPrice1"].DefaultValue = "0";
        mdt_UnLiquidationMain.Columns.Add("multipleMatchPrice2", typeof(string)).DefaultValue = "";       //複式商品成交價2
        mdt_UnLiquidationMain.Columns["multipleMatchPrice2"].DefaultValue = "0";

        //added 20100505 by philip 價差供 即時組合部位查詢 使用
        mdt_UnLiquidationMain.Columns.Add("PriceDiff", typeof(double)).DefaultValue = 0;                 //價差
        mdt_UnLiquidationMain.Columns["PriceDiff"].Expression = "IIF(BS='B',realPrice-AvgMatchPrice ,AvgMatchPrice-realPrice) ";
        mdt_UnLiquidationMain.Columns.Add("MultiName", typeof(string)).DefaultValue = "";                 //組合類型

        //added by samantha 20101005 顯示每腳價位
        mdt_UnLiquidationMain.Columns.Add("footMatchPrice").DefaultValue = "";

        mdt_UnLiquidationMain.Columns.Add("productName").DefaultValue = "";
        mdt_UnLiquidationMain.Columns.Add("COMTYPE").DefaultValue = "";
        mdt_UnLiquidationMain.Columns.Add("COMNO").DefaultValue = "";
        mdt_UnLiquidationMain.Columns.Add("callput").DefaultValue = "";
        mdt_UnLiquidationMain.Columns.Add("MKTCOMNO").DefaultValue = "";
        mdt_UnLiquidationMain.Columns.Add("COMYM").DefaultValue = "";
        mdt_UnLiquidationMain.Columns.Add("stkprc", typeof(string)).DefaultValue = "";
        mdt_UnLiquidationMain.Columns.Add("stkprc_dec", typeof(decimal)).DefaultValue = "0";
        mdt_UnLiquidationMain.Columns.Add("IAMT").DefaultValue = "";
        mdt_UnLiquidationMain.Columns.Add("MAMT").DefaultValue = "";

        mdt_UnLiquidationMain.Columns.Add("TAX", typeof(double)).DefaultValue = 0;
        mdt_UnLiquidationMain.Columns.Add("FEE", typeof(double)).DefaultValue = 0;
        mdt_UnLiquidationMain.Columns.Add("EQUITY", typeof(double)).DefaultValue = 0;
        //added 20100416 by philip 多加一個key值
        mdt_UnLiquidationMain.CaseSensitive = true;
        DataColumn[] dcPrimaryKey = { this.mdt_UnLiquidationMain.Columns["investorAcno"], this.mdt_UnLiquidationMain.Columns["ProductId"], this.mdt_UnLiquidationMain.Columns["BS"], this.mdt_UnLiquidationMain.Columns["productKind"] };
        this.mdt_UnLiquidationMain.PrimaryKey = dcPrimaryKey;
    }
    private void initializedMOBCombineData()
    {

        //added 20101020 by will 單式商品組合

        mdt_MOBCombineData = new DataTable("MOBCombineData");

        mdt_MOBCombineData.Columns.Add("ADJNO");

        mdt_MOBCombineData.Columns.Add("COUNT");

        mdt_MOBCombineData.Columns.Add("SEQNO");

        mdt_MOBCombineData.Columns.Add("STATUS");

    }
    private void initializedCurrentEquity()
    {
        mdt_CurrentEquity = new DataTable("Equity");
        mdt_CurrentEquity.Columns.Add("SYSDATE").DefaultValue = DateTime.Now.ToString("yyyy/MM/dd");
        mdt_CurrentEquity.Columns.Add("SYSTIME").DefaultValue = DateTime.Now.ToString("HH:mm:ss");

        mdt_CurrentEquity.Columns.Add("TRDORDNO");
        mdt_CurrentEquity.Columns.Add("TRDLINESNO");
        mdt_CurrentEquity.Columns.Add("TRDSEQNO");
        mdt_CurrentEquity.Columns.Add("OFFSETDATE");
        mdt_CurrentEquity.Columns.Add("COMPANY");
        mdt_CurrentEquity.Columns.Add("ACTNO");
        mdt_CurrentEquity.Columns.Add("OPTTRDDT");
        mdt_CurrentEquity.Columns.Add("TRD_ORDNO");
        mdt_CurrentEquity.Columns.Add("OPT_ORDNO");
        mdt_CurrentEquity.Columns.Add("productid");
        mdt_CurrentEquity.Columns.Add("COMTYPE");
        mdt_CurrentEquity.Columns.Add("COMNO");
        mdt_CurrentEquity.Columns.Add("COMYM");
        mdt_CurrentEquity.Columns.Add("STKPRC");
        mdt_CurrentEquity.Columns.Add("CALLPUT");
        mdt_CurrentEquity.Columns.Add("ABBR");
        mdt_CurrentEquity.Columns.Add("PS");
        mdt_CurrentEquity.Columns.Add("TRDPRC1");
        mdt_CurrentEquity.Columns.Add("OPTPRIC1");
        mdt_CurrentEquity.Columns.Add("OFFSETQTY", typeof(int));
        mdt_CurrentEquity.Columns.Add("CURRENCY");
        mdt_CurrentEquity.Columns.Add("OSPRTLOS", typeof(decimal));
        mdt_CurrentEquity.Columns.Add("TRD_charge", typeof(decimal));
        mdt_CurrentEquity.Columns.Add("TRD_tax", typeof(decimal));
        mdt_CurrentEquity.Columns.Add("OPT_charge", typeof(decimal));
        mdt_CurrentEquity.Columns.Add("OPT_tax", typeof(decimal));
        mdt_CurrentEquity.Columns.Add("charge", typeof(decimal));
        mdt_CurrentEquity.Columns.Add("tax", typeof(decimal));
        mdt_CurrentEquity.Columns.Add("Equity", typeof(decimal));
        mdt_CurrentEquity.Columns.Add("ORDTYPE");
        mdt_CurrentEquity.Columns.Add("spread");
        mdt_CurrentEquity.Columns.Add("ProductName");
        //mdt_CurrentEquity.PrimaryKey = new DataColumn[] { mdt_CurrentEquity.Columns[""],};


    }
    private void initializedCurrentEquityCollect()
    {
        DataSet ms = new DataSet("Equity");
        mdt_CurrentEquityCollect = new DataTable("EquityCollect");

        ms.Tables.Add(mdt_CurrentEquityCollect);
        ms.Tables.Add(mdt_CurrentEquity);
        mdt_CurrentEquityCollect.Columns.Add("SYSDATE").DefaultValue = DateTime.Now.ToString("yyyy/MM/dd");
        mdt_CurrentEquityCollect.Columns.Add("SYSTIME").DefaultValue = DateTime.Now.ToString("HH:mm:ss");


        mdt_CurrentEquityCollect.Columns.Add("COMPANY");
        mdt_CurrentEquityCollect.Columns.Add("ACTNO");
        mdt_CurrentEquityCollect.Columns.Add("OFFSETDATE"); //平倉日期
        mdt_CurrentEquityCollect.Columns.Add("productid");
        mdt_CurrentEquityCollect.Columns.Add("ordtype");     //類型
        mdt_CurrentEquityCollect.Columns.Add("CURRENCY");  //幣別 

        DataColumn[] dcParent = new DataColumn[] { mdt_CurrentEquityCollect.Columns["COMPANY"], mdt_CurrentEquityCollect.Columns["ACTNO"], mdt_CurrentEquityCollect.Columns["OFFSETDATE"], mdt_CurrentEquityCollect.Columns["productid"], mdt_CurrentEquityCollect.Columns["ordtype"], mdt_CurrentEquityCollect.Columns["CURRENCY"] };
        DataColumn[] dcChild = new DataColumn[] { mdt_CurrentEquity.Columns["COMPANY"], mdt_CurrentEquity.Columns["ACTNO"], mdt_CurrentEquity.Columns["OFFSETDATE"], mdt_CurrentEquity.Columns["productid"], mdt_CurrentEquity.Columns["ordtype"], mdt_CurrentEquity.Columns["CURRENCY"] };
        DataRelation rel;
        rel = new DataRelation("rel", dcParent, dcChild);
        ms.Relations.Add(rel);
        mdt_CurrentEquityCollect.PrimaryKey = new DataColumn[] { mdt_CurrentEquityCollect.Columns["COMPANY"], mdt_CurrentEquityCollect.Columns["ACTNO"], mdt_CurrentEquityCollect.Columns["OFFSETDATE"], mdt_CurrentEquityCollect.Columns["productid"], mdt_CurrentEquityCollect.Columns["ordtype"], mdt_CurrentEquityCollect.Columns["CURRENCY"] };

        mdt_CurrentEquityCollect.Columns.Add("COMTYPE").Expression = "  max(child(rel).COMTYPE )";
        mdt_CurrentEquityCollect.Columns.Add("COMNO").Expression = " max(child(rel).COMNO)";
        mdt_CurrentEquityCollect.Columns.Add("COMYM").Expression = "  max(child(rel).COMYM)";
        mdt_CurrentEquityCollect.Columns.Add("STKPRC").Expression = "  max(child(rel).STKPRC)";
        mdt_CurrentEquityCollect.Columns.Add("CALLPUT").Expression = " max( child(rel).CALLPUT)";
        mdt_CurrentEquityCollect.Columns.Add("ABBR").Expression = "  max(child(rel).ABBR)";
        mdt_CurrentEquityCollect.Columns.Add("OFFSETQTY", typeof(int)).Expression = "sum(child(rel).OFFSETQTY)";  //平倉口數

        mdt_CurrentEquityCollect.Columns.Add("OSPRTLOS", typeof(decimal)).Expression = "sum(child(rel).OSPRTLOS)"; //交易損益       
        mdt_CurrentEquityCollect.Columns.Add("charge", typeof(decimal)).Expression = "sum(child(rel).charge)";    //手續費  
        mdt_CurrentEquityCollect.Columns.Add("tax", typeof(decimal)).Expression = "sum(child(rel).tax)";       //期交稅   
        mdt_CurrentEquityCollect.Columns.Add("equity", typeof(decimal)).Expression = "sum(child(rel).equity)";    //淨損益  = 交易損益+手續費+期交稅

        mdt_CurrentEquityCollect.Columns.Add("GiveUp", typeof(int)).Expression = "iif(ordtype='6'  ,OFFSETQTY,0)";     //放棄口數
        mdt_CurrentEquityCollect.Columns.Add("ProductName").Expression = " max( child(rel).ProductName)"; //商品代號

    }


    private void initializedWithdraw()
    {


        mdt_Withdraw = new DataTable("Withdraw");

        mdt_Withdraw.Columns.Add("FIRM").DefaultValue = "";

        mdt_Withdraw.Columns.Add("ACTNO").DefaultValue = ""; ;

        mdt_Withdraw.Columns.Add("BANKNO").DefaultValue = "";

        mdt_Withdraw.Columns.Add("BANKNAME").DefaultValue = "";

        mdt_Withdraw.Columns.Add("BANKACTNO").DefaultValue = "";

        mdt_Withdraw.Columns.Add("TRDDT").DefaultValue = "";

        mdt_Withdraw.Columns.Add("CODE").DefaultValue = "";
        mdt_Withdraw.Columns.Add("CODE_NAME").DefaultValue = "";

        mdt_Withdraw.Columns.Add("CURRENCY").DefaultValue = "";


        mdt_Withdraw.Columns.Add("AMT").DefaultValue = "";


        mdt_Withdraw.Columns.Add("MDATE").DefaultValue = "";


        mdt_Withdraw.Columns.Add("MTIME").DefaultValue = "";



    }

    private void initializedOrderWithdraw()
    {


        mdt_OrderWithdraw = new DataTable("OrderWithdraw");

        mdt_OrderWithdraw.Columns.Add("MTYPE").DefaultValue = "";

        mdt_OrderWithdraw.Columns.Add("SEQNO").DefaultValue = "";
        mdt_OrderWithdraw.Columns.Add("TYPE").DefaultValue = "";

        mdt_OrderWithdraw.Columns.Add("FIRM").DefaultValue = "";

        mdt_OrderWithdraw.Columns.Add("ACTNO").DefaultValue = ""; ;

        mdt_OrderWithdraw.Columns.Add("CODE").DefaultValue = "";
        mdt_OrderWithdraw.Columns.Add("CODE_NAME").DefaultValue = "";

        mdt_OrderWithdraw.Columns.Add("MAXAMOUNT").DefaultValue = "";


        mdt_OrderWithdraw.Columns.Add("NETVALUE").DefaultValue = "";
        mdt_OrderWithdraw.Columns.Add("IAMT").DefaultValue = "";
        mdt_OrderWithdraw.Columns.Add("RAMT").DefaultValue = "";
        mdt_OrderWithdraw.Columns.Add("OUTNO").DefaultValue = "";
        mdt_OrderWithdraw.Columns.Add("TONO").DefaultValue = "";

        mdt_OrderWithdraw.Columns.Add("MDATE").DefaultValue = "";

    }
    private void initializedRateData()
    {
        this.mdt_RateData = new DataTable("RateData");



        this.mdt_RateData.Columns.Add("FIRM", typeof(string)).DefaultValue = "";
        this.mdt_RateData.Columns.Add("ACTNO", typeof(string)).DefaultValue = "";

        this.mdt_RateData.Columns.Add("CCY", typeof(string)).DefaultValue = "";

        this.mdt_RateData.Columns.Add("FU19103", typeof(decimal)).DefaultValue = 0;
        this.mdt_RateData.Columns.Add("INIRATE", typeof(decimal)).DefaultValue = 0;
        this.mdt_RateData.Columns.Add("MATRATE", typeof(decimal)).DefaultValue = 0;
        this.mdt_RateData.Columns.Add("IAMT", typeof(decimal)).DefaultValue = 0;

        this.mdt_RateData.Columns.Add("MAMT", typeof(decimal)).DefaultValue = 0;
        this.mdt_RateData.Columns.Add("ORDCEXCESS", typeof(decimal)).DefaultValue = 0;
        this.mdt_RateData.Columns.Add("CTDAB", typeof(decimal)).DefaultValue = 0;
        this.mdt_RateData.Columns.Add("OPTEQUITY", typeof(decimal)).DefaultValue = 0;

        this.mdt_RateData.Columns.Add("STIME", typeof(string)).DefaultValue = "";

    }

    private void initializedRateForDateData()
    {
        this.mdt_RateForDateData = new DataTable("RateData");



        this.mdt_RateForDateData.Columns.Add("FIRM", typeof(string)).DefaultValue = "";
        this.mdt_RateForDateData.Columns.Add("ACTNO", typeof(string)).DefaultValue = "";

        this.mdt_RateForDateData.Columns.Add("CCY", typeof(string)).DefaultValue = "";

        this.mdt_RateForDateData.Columns.Add("FU19103", typeof(decimal)).DefaultValue = 0;
        this.mdt_RateForDateData.Columns.Add("INIRATE", typeof(decimal)).DefaultValue = 0;
        this.mdt_RateForDateData.Columns.Add("MATRATE", typeof(decimal)).DefaultValue = 0;
        this.mdt_RateForDateData.Columns.Add("IAMT", typeof(decimal)).DefaultValue = 0;

        this.mdt_RateForDateData.Columns.Add("MAMT", typeof(decimal)).DefaultValue = 0;
        this.mdt_RateForDateData.Columns.Add("ORDCEXCESS", typeof(decimal)).DefaultValue = 0;
        this.mdt_RateForDateData.Columns.Add("CTDAB", typeof(decimal)).DefaultValue = 0;
        this.mdt_RateForDateData.Columns.Add("OPTEQUITY", typeof(decimal)).DefaultValue = 0;

        this.mdt_RateForDateData.Columns.Add("MARGINCALL", typeof(decimal)).DefaultValue = 0;
        this.mdt_RateForDateData.Columns.Add("DTATIME", typeof(string)).DefaultValue = "";
        this.mdt_RateForDateData.Columns.Add("CLSTIME", typeof(string)).DefaultValue = "";

    }

    ///// <summary>
    /////MOB保證金查詢  added 20100409
    ///// </summary>
    //private void initializedMOBCurrentMargin()
    //{
    //    this.mdt_MOBCurrentMarginComplete = new DataTable("MOBCurrentMarginComplete");

    //    mdt_MOBCurrentMarginComplete.Columns.Add("list");
    //    mdt_MOBCurrentMarginComplete.Columns.Add("value");
    //    mdt_MOBCurrentMarginComplete.Columns.Add("explain");

    //    mdt_MOBCurrentMarginComplete.Rows.Add("匯率:", "", "-------");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("昨日帳戶權益數:", "", "昨日收盤後之帳戶權益數");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("昨日餘額:", "", "昨日收盤後之帳戶權益數(不含浮動損益)");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("本日出入金:", "", "今日存款及提款的金額總和");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("期貨平倉損益:", "", "(平倉價-成交價)*契約價值");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("期貨未平倉浮動損益:", "", "(即時價-成交價)*契約價值");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("選擇權平倉損益:", "", "(平倉價-成交價)*契約價值");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("選擇權未平倉浮動損益:", "", "(即時價-成交價)*契約價值");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("權利金支出/收入:", "", "今日選擇權交易所產生之收入及支出");

    //    mdt_MOBCurrentMarginComplete.Rows.Add("", "本日手續費及稅", "");

    //    mdt_MOBCurrentMarginComplete.Rows.Add("手續費:", "", "本日成交部位(期貨+選擇權)所需手續費總和");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("期交稅:", "", "本日成交部位(期貨+選擇權)所需期交稅總和");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("預扣權利金:", "", "委託成功後預扣的權利金");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("權益數:", "", "    昨日權益數+本日出入金+調整後的平倉損益+權利金支出/收入-手續費-期交稅-預扣權利金+調整後未平倉浮動損益");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("下單保證金:", "", "所有委託中的部位所需原始保證金總和");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("所需原始保證金:", "", "所有委託中部位+在倉部位所需原始保證金總和");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("所需維持保證金:", "", "所有在倉部位所需維持保證金總和");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("下單可用(提領)保證金:", "", "權益數-原始保證金-調整後未平倉浮動損失");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("買方權利金市值:", "", "台指選擇權的買(賣)方權利金市值 = 口數 * 市價(結算價) * 50");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("賣方權利金市值:", "", "台指選擇權的買(賣)方權利金市值 = 口數 * 市價(結算價) * 50");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("權益總值:", "", "權益數+買方權利金市值-賣方權利金市值");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("原始比率:", "", "權益數/所需足額原始保證金");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("維持比率:", "", "權益數/所需足額維持保證金");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("清算比率:", "", "權益總值/所需足額原始保證金");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("追繳金額:", "", "原始保證金-權益數");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("台幣權益總值:", "", "台幣權益數+買方權利金市值-賣方權利金市值");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("台幣原始比率:", "", "台幣權益數/台幣所需原始保證金");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("台幣可用保證金:", "", "-------");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("有價證券抵繳總額:", "", "有價證券抵繳總額查詢");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("資料更新日期:", "", "-------");
    //    mdt_MOBCurrentMarginComplete.Rows.Add("資料更新時間:", "", "-------");


    //    this.mdt_MOBCurrenetMarginRapid = new DataTable("MOBCurrenetMarginRapid");

    //    mdt_MOBCurrenetMarginRapid.Columns.Add("list");
    //    mdt_MOBCurrenetMarginRapid.Columns.Add("value");


    //    mdt_MOBCurrenetMarginRapid.Rows.Add("期貨未平倉浮動損益:");
    //    mdt_MOBCurrenetMarginRapid.Rows.Add("所需原始保證金:");
    //    mdt_MOBCurrenetMarginRapid.Rows.Add("所需維持保證金:");
    //    mdt_MOBCurrenetMarginRapid.Rows.Add("下單可用(提領)保證金:");
    //    mdt_MOBCurrenetMarginRapid.Rows.Add("權益總值:");
    //    mdt_MOBCurrenetMarginRapid.Rows.Add("維持比率:");
    //    mdt_MOBCurrenetMarginRapid.Rows.Add("清算比率:");
    //    mdt_MOBCurrenetMarginRapid.Rows.Add("追繳金額:");
    //    mdt_MOBCurrenetMarginRapid.Rows.Add("資料更新日期:");
    //    mdt_MOBCurrenetMarginRapid.Rows.Add("資料更新時間:");



    //}


    private string getProductId(string ClassId, string Class_Name, string Settlement_month, string Strike_Price, string CP)
    {
        if (ClassId == "1") //期貨
        {
            DataRow[] dr = mdt_FutureData.Select("Class_Name='" + Class_Name + "' and Settlement_month='" + Settlement_month + "'");
            if (dr.Length == 0)
            {
                return "";
            }
            else
            {
                return dr[0]["Commodity_Id"].ToString().Trim();
            }
            //return dr[0]["Commodity_Id"].ToString().Trim();
            //return "";
        }
        else   //選擇權
        {
            DataRow[] dr = mdt_OptionData.Select("Class_Name='" + Class_Name + "' and Settlement_month='" + Settlement_month + "' and CP='" + CP + "' and Strike_Price='" + Strike_Price + "'");
            if (dr.Length == 0)
            {
                return "";
            }
            else
            {
                return dr[0]["Commodity_Id"].ToString().Trim();
            }
            //return dr[0]["Commodity_Id"].ToString().Trim();
            //return "";
        }
    }

    // from 3.0.0.8
    private decimal getMultiplePrice(string multiplekind, decimal price1, decimal price2)
    {
        decimal multiplePrice = 0;
        if ((multiplekind == "1" || multiplekind == "2" || multiplekind == "5" || multiplekind == "0") || (multiplekind == "價格價差" || multiplekind == "時間價差" || multiplekind == "轉換/逆轉換" || multiplekind == "期貨價差"))
        {
            multiplePrice = price2 - price1;
        }
        else if ((multiplekind == "3" || multiplekind == "4") || (multiplekind == "跨式組合" || multiplekind == "勒式組合"))
        {
            multiplePrice = price1 + price2;
        }
        return multiplePrice;
    }

    // from 3.0.0.8
    private string[] MultipleProductId(string type, string ID_1st, string ID_2nd, string bs1, string bs2, string productdesc, string productdesc2, string strk1, string strk2)
    {
        //type =3 mutiple option  4 m future

        //// 1價差 2跨月 3跨式 4勒式 5轉換逆轉換 0期貨價差  
        string[] strReturn = new string[13];//第一個id,第二個策略
        //預設串英文
        strReturn[2] = ID_1st + "  " + ID_2nd;

        string classid = ID_1st.Substring(0, 3);
        string classid2 = ID_2nd.Substring(0, 3);

        string period1 = ID_1st.Substring(ID_1st.Length - 2, 2);
        string period2 = ID_2nd.Substring(ID_2nd.Length - 2, 2);
        double yearmonth1 = int.Parse("201" + period1.Substring(1, 1) + getOptionPeriod(period1.Substring(0, 1)).ToString().PadLeft(2, '0')) + getProductClassShortWeekNameInt(classid);
        double yearmonth2 = int.Parse("201" + period2.Substring(1, 1) + getOptionPeriod(period2.Substring(0, 1)).ToString().PadLeft(2, '0')) + getProductClassShortWeekNameInt(classid2);

        if (type == "3")
        {

            string strikeprice1 = ID_1st.Substring(3, 5);
            string strikeprice2 = ID_2nd.Substring(3, 5);
            string cp1 = getOptionCP(period1.Substring(0, 1));
            string cp2 = getOptionCP(period2.Substring(0, 1));

            //判斷買賣別如果相同為跨式\勒式組合
            if (bs1 == bs2)
            {
                if (yearmonth1 == yearmonth2)
                {
                    if (cp1 != cp2)
                    {
                        if (cp1 == "P")
                        {
                            changeOptionFoot(ref  ID_1st, ref  ID_2nd, ref classid, ref classid2, ref  bs1, ref  bs2, ref  period1, ref period2, ref strikeprice1, ref strikeprice2, ref cp1, ref cp2, ref productdesc, ref productdesc2, ref strk1, ref strk2);
                        }
                        //跨式,價位相同
                        if (strikeprice1 == strikeprice2)
                        {
                            strReturn[0] = classid + strikeprice1 + period1 + ":" + period2;
                            strReturn[1] = "3";

                            strReturn[2] = productdesc + decimal.Parse(strk1).ToString("#0.####") + cp1 + ":" + cp2 + getOptionPeriod(period2.Substring(0, 1));

                        }
                        else
                        {
                            //勒式
                            strReturn[0] = classid + strikeprice1 + period1 + ":" + strikeprice2 + period2;
                            strReturn[1] = "4";

                            strReturn[2] = productdesc + decimal.Parse(strk1).ToString("#0.####") + cp1 + ":" + decimal.Parse(strk2).ToString("#0.####") + cp2 + getOptionPeriod(period1.Substring(0, 1));
                        }
                    }
                }
            }
            else
            {
                //價格價差,價位不同
                if (strikeprice1 != strikeprice2)
                {
                    if (yearmonth1 == yearmonth2)
                    {
                        if (cp1 == cp2)
                        {


                            if ((cp1 == "C" && int.Parse(strikeprice1) < int.Parse(strikeprice2)) || (cp1 == "P" && int.Parse(strikeprice1) > int.Parse(strikeprice2)))
                            {
                                changeOptionFoot(ref  ID_1st, ref  ID_2nd, ref classid, ref classid2, ref  bs1, ref  bs2, ref  period1, ref period2, ref strikeprice1, ref strikeprice2, ref cp1, ref cp2, ref productdesc, ref productdesc2, ref strk1, ref strk2);
                            }


                            strReturn[0] = classid + strikeprice1 + "/" + strikeprice2 + period2;
                            strReturn[1] = "1";
                            strReturn[2] = productdesc + decimal.Parse(strk1).ToString("#0.####") + "/" + decimal.Parse(strk2).ToString("#0.####") + cp1 + getOptionPeriod(period2.Substring(0, 1));
                        }
                    }

                }
                else
                {
                    //判斷月份如不相同為跨月價差                    
                    if (yearmonth1 != yearmonth2)
                    {

                        if (cp1 == cp2)
                        {


                            if (yearmonth1 > yearmonth2)
                            {
                                changeOptionFoot(ref  ID_1st, ref  ID_2nd, ref classid, ref classid2, ref  bs1, ref  bs2, ref  period1, ref period2, ref strikeprice1, ref strikeprice2, ref cp1, ref cp2, ref productdesc, ref productdesc2, ref strk1, ref strk2);

                            }
                            if (classid != classid2)
                            {
                                strReturn[0] = classid + strikeprice1 + period1 + "/" + classid2 + period2;
                                strReturn[2] = productdesc + decimal.Parse(strk1).ToString("#0.####") + cp1 + getOptionPeriod(period1.Substring(0, 1)) + "/" + productdesc2 + getOptionPeriod(period2.Substring(0, 1));

                            }
                            else
                            {
                                strReturn[0] = classid + strikeprice1 + period1 + "/" + period2;
                                strReturn[2] = productdesc + decimal.Parse(strk1).ToString("#0.####") + cp1 + getOptionPeriod(period1.Substring(0, 1)) + "/" + getOptionPeriod(period2.Substring(0, 1));

                            }

                            strReturn[1] = "2";
                        }
                    }
                    else if (yearmonth1 == yearmonth2)
                    {
                        if (cp1 != cp2)
                        {


                            if (cp1 == "P")
                            {
                                changeOptionFoot(ref  ID_1st, ref  ID_2nd, ref classid, ref classid2, ref  bs1, ref  bs2, ref  period1, ref period2, ref strikeprice1, ref strikeprice2, ref cp1, ref cp2, ref productdesc, ref productdesc2, ref strk1, ref strk2);

                            }
                            strReturn[0] = classid + strikeprice1 + period1 + "-" + period2;
                            strReturn[1] = "5";
                            strReturn[2] = productdesc + decimal.Parse(strk1).ToString("#0.####") + cp1 + "-" + cp2 + getOptionPeriod(period1.Substring(0, 1));
                        }
                    }
                }
            }
            strReturn[7] = cp1;
            strReturn[8] = cp2;
            strReturn[9] = decimal.Parse(strk1).ToString("#0.####");
            strReturn[10] = decimal.Parse(strk2).ToString("#0.####");
        }
        else if (type == "4")
        {


            if (yearmonth1 != yearmonth2)
            {


                if (yearmonth1 > yearmonth2)
                {
                    changeFutureFoot(ref  ID_1st, ref  ID_2nd, ref  bs1, ref  bs2, ref  period1, ref period2);

                }

                strReturn[0] = classid + period1 + "/" + period2;
                strReturn[1] = "0";
                strReturn[2] = productdesc + getOptionPeriod(period1.Substring(0, 1)) + "/" + getOptionPeriod(period2.Substring(0, 1));
            }
        }
        strReturn[3] = ID_1st;
        strReturn[4] = ID_2nd;
        strReturn[5] = bs1;
        strReturn[6] = bs2;

        strReturn[11] = "201" + period1.Substring(1, 1) + getOptionPeriod(period1.Substring(0, 1)).ToString().PadLeft(2, '0');
        strReturn[12] = "201" + period2.Substring(1, 1) + getOptionPeriod(period2.Substring(0, 1)).ToString().PadLeft(2, '0');

        return strReturn;
    }
    //for 彙總查詢
    private string getmutiname(string CommodityId, string pyearmonth1, string pyearmonth2, string strikeprice1, string strikeprice2
                                                    , string cp1, string cp2, string productdesc, string productdesc2)
    {
        //type =3 mutiple option  4 m future
        string desc = CommodityId;


        string classid = "";
        string classid2 = "";

        if (CommodityId.Length == 16 && CommodityId.Substring(8, 1) == "/")//價格價差
        {
            classid = CommodityId.Substring(0, 3);
            classid2 = CommodityId.Substring(6, 3);

            desc = productdesc + strikeprice1 + "/" + strikeprice2 + cp1 + pyearmonth1.Substring(4, 2);
        }
        else if (CommodityId.Length == 16 && CommodityId.Substring(10, 1) == "/")//週選時間價差
        {
            classid = CommodityId.Substring(0, 3);
            classid2 = CommodityId.Substring(11, 3);
            desc = productdesc + strikeprice1 + strikeprice2 + cp1 + pyearmonth1.Substring(4, 2) + "/" + productdesc2 + pyearmonth2.Substring(4, 2);


        }
        else if (CommodityId.Length == 13) //時間價差、跨式、逆轉換
        {
            classid = CommodityId.Substring(0, 3);
            classid2 = classid;
            if (CommodityId.IndexOf(':') > 0)
                desc = productdesc + strikeprice1 + cp1 + ":" + cp2 + pyearmonth1.Substring(4, 2);///跨式,價位相同
            if (CommodityId.IndexOf('-') > 0)
                desc = productdesc + strikeprice1 + cp1 + "-" + cp2 + pyearmonth1.Substring(4, 2);//逆轉換
            if (CommodityId.IndexOf('/') > 0)
                desc = productdesc + strikeprice1 + cp1 + pyearmonth1.Substring(4, 2) + "/" + pyearmonth2.Substring(4, 2);//逆轉換

        }
        else if (CommodityId.Length == 18)// 勒式
        {
            classid = CommodityId.Substring(0, 3);
            classid2 = classid;
            desc = productdesc + strikeprice1 + cp1 + ":" + strikeprice2 + cp2 + pyearmonth1.Substring(4, 2);
        }


        return desc;
    }
    private void changeOptionFoot(ref string productid1, ref string productid2, ref string classid1, ref string classid2, ref string bs1, ref string bs2, ref string period1, ref string period2, ref string strikeprice1, ref string strikeprice2, ref string cp1, ref string cp2, ref string productidDesc1, ref string productidDesc2, ref string strk1, ref string strk2)
    {
        string tempPeriod = "";
        string tempstrikeprice = "";
        string tempcp = "";
        string tempbs = "";
        string tempproductid = "";
        string tempclassid = "";
        string tempproductDesc = "";

        string tempstrk = "";
        tempstrk = strk1;
        tempPeriod = period1;
        tempstrikeprice = strikeprice1;
        tempcp = cp1;
        tempbs = bs1;
        tempproductid = productid1;
        tempclassid = classid1;
        tempproductDesc = productidDesc1;
        productidDesc1 = productidDesc2;

        productidDesc2 = tempproductDesc;
        strk1 = strk2;
        period1 = period2;
        strikeprice1 = strikeprice2;
        cp1 = cp2;
        bs1 = bs2;
        productid1 = productid2;
        classid1 = classid2;

        period2 = tempPeriod;
        strikeprice2 = tempstrikeprice;
        cp2 = tempcp;
        bs2 = tempbs;
        productid2 = tempproductid;
        classid2 = tempclassid;
        strk2 = tempstrk;

    }
    private void changeFutureFoot(ref string productid1, ref string productid2, ref string bs1, ref string bs2, ref string period1, ref string period2)
    {
        string tempPeriod = "";
        string tempbs = "";
        string tempproductid = "";

        tempPeriod = period1;
        tempbs = bs1;
        tempproductid = productid1;

        period1 = period2;
        bs1 = bs2;
        productid1 = productid2;


        period2 = tempPeriod;
        bs2 = tempbs;
        productid2 = tempproductid;
    }
    public double getProductClassShortWeekNameInt(string ProductClass)
    {
        double week = 0.3;
        if (ProductClass == "TX1")
            week = 0.1;
        else if (ProductClass == "TX2")
            week = 0.2;
        else if (ProductClass == "TX4")
            week = 0.4;
        else if (ProductClass == "TX5")
            week = 0.5;
        else if (ProductClass == "MX1")//20130627 V5.0.0.13 小台短天期 modified by peter
            week = 0.1;
        else if (ProductClass == "MX2")
            week = 0.2;
        else if (ProductClass == "MX4")
            week = 0.4;
        else if (ProductClass == "MX5")
            week = 0.5;
        return week;

    }
    // from 3.0.0.8
    private string getOptionCP(string period)
    {
        period = period.ToUpper();
        string[] cperiod = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L" };
        string[] pperiod = { "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X" };
        string cp = "";
        if (Array.IndexOf<string>(cperiod, period) != -1)
        {
            cp = "C";
        }
        else if (Array.IndexOf<string>(pperiod, period) != -1)
        {
            cp = "P";
        }

        return cp;
    }
    // from 3.0.0.8
    private int getOptionPeriod(string period)
    {
        period = period.ToUpper();
        string[] cperiod = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L" };
        string[] pperiod = { "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X" };
        int returnperiod = 0;
        if (Array.IndexOf<string>(cperiod, period) != -1)
        {
            returnperiod = (Array.IndexOf<string>(cperiod, period) + 1);
        }
        else if (Array.IndexOf<string>(pperiod, period) != -1)
        {
            returnperiod = (Array.IndexOf<string>(pperiod, period) + 1);
        }

        return returnperiod;
    }


    // from 3.0.0.8
    public string[] MultiProductParser(string productkind, string BS, string ProductID, string foot1Bs)
    {

        //string[] ParseResult = new string[6];
        //modified by philip 20100427 多傳 複式單的組合類型    Option 1：Price Spread 2：Time Spread 3：Straddle Spread 4：Strangles Spread 5：Conagles Spread    0:期貨價差
        string[] ParseResult = new string[7];

        string commidity_ID = ProductID.Substring(0, 3);
        string commidity_ID2 = ProductID.Substring(0, 3);
        string[] delimeter = { commidity_ID };
        string[] split = ProductID.Split(delimeter, StringSplitOptions.RemoveEmptyEntries);


        if (productkind == "4")
        {
            ParseResult[0] = "期貨價差";
            ParseResult[6] = "0";


            string[] SettlementMonth = split[0].Split(new char[] { '/' }, StringSplitOptions.RemoveEmptyEntries);

            switch (BS)
            {
                case "S":
                    ParseResult[1] = "B";
                    ParseResult[3] = "S";

                    break;
                case "B":
                    ParseResult[1] = "S";
                    ParseResult[3] = "B";
                    break;
                case "":
                    ParseResult[1] = foot1Bs;
                    if (foot1Bs == "B")
                    {
                        ParseResult[3] = "S";
                    }
                    else
                    {
                        ParseResult[3] = "B";
                    }
                    break;
            }

            ParseResult[2] = commidity_ID + SettlementMonth[0].ToString();
            ParseResult[4] = commidity_ID + SettlementMonth[1].ToString();

        }
        else if (productkind == "3")
        {
            string[] Price = new string[2];

            if (ProductID.Substring(8, 1) == "/")          //價格價差 與 時間價差 商品碼中有  " / "
            {
                if (split[0].Length == 13)             // 價格價差
                {

                    string[] SettlementMonth = new string[1];


                    SettlementMonth[0] = split[0].Substring(split[0].Length - 2, 2);

                    string[] PriceSplit = split[0].Split(SettlementMonth, StringSplitOptions.RemoveEmptyEntries);
                    Price = PriceSplit[0].Split(new char[] { '/' }, StringSplitOptions.RemoveEmptyEntries);

                    ParseResult[0] = "價格價差";
                    ParseResult[6] = "1";

                    switch (BS)
                    {
                        case "S":
                            ParseResult[1] = "B";
                            ParseResult[3] = "S";

                            break;
                        case "B":
                            ParseResult[1] = "S";
                            ParseResult[3] = "B";
                            break;
                        case "":
                            ParseResult[1] = foot1Bs;
                            if (foot1Bs == "B")
                            {
                                ParseResult[3] = "S";
                            }
                            else
                            {
                                ParseResult[3] = "B";
                            }
                            break;
                    }
                    ParseResult[2] = commidity_ID + Price[0].ToString() + SettlementMonth[0].ToString();
                    ParseResult[4] = commidity_ID + Price[1].ToString() + SettlementMonth[0].ToString();

                }


            }
            else if ((ProductID.Length == 13 || ProductID.Length == 16) & (ProductID.Substring(10, 1) == "-" | ProductID.Substring(10, 1) == "/" | ProductID.Substring(10, 1) == ":"))     //時間價差 轉換/逆轉換 跨式
            {

                string[] SettlementMonth = new string[2];
                string[] price = { split[0].Substring(0, 5) };  //價格
                string[] MonthSplit = split[0].Split(price, StringSplitOptions.RemoveEmptyEntries);

                switch (MonthSplit[0].Substring(2, 1))
                {
                    case "/":

                        ParseResult[0] = "時間價差";
                        ParseResult[6] = "0";
                        SettlementMonth = MonthSplit[0].Split(new char[] { '/' }, StringSplitOptions.RemoveEmptyEntries);
                        if (ProductID.Length == 16)
                        {
                            commidity_ID2 = SettlementMonth[1].Substring(0, 3);
                            SettlementMonth[1] = SettlementMonth[1].Substring(3);

                        }
                        switch (BS)
                        {
                            case "B":

                                ParseResult[1] = "S";
                                ParseResult[3] = "B";

                                break;
                            case "S":
                                ParseResult[1] = "B";
                                ParseResult[3] = "S";

                                break;
                            case "":
                                ParseResult[1] = foot1Bs;
                                if (foot1Bs == "B")
                                {
                                    ParseResult[3] = "S";
                                }
                                else
                                {
                                    ParseResult[3] = "B";
                                }
                                break;
                        }

                        break;
                    case "-":

                        ParseResult[0] = "轉換/逆轉換";
                        ParseResult[6] = "5";
                        SettlementMonth = MonthSplit[0].Split(new char[] { '-' }, StringSplitOptions.RemoveEmptyEntries);

                        switch (BS)
                        {
                            case "B":
                                ParseResult[1] = "S";
                                ParseResult[3] = "B";

                                break;
                            case "S":
                                ParseResult[1] = "B";
                                ParseResult[3] = "S";
                                break;
                            case "":
                                ParseResult[1] = foot1Bs;
                                if (foot1Bs == "B")
                                {
                                    ParseResult[3] = "S";
                                }
                                else
                                {
                                    ParseResult[3] = "B";
                                }
                                break;
                        }
                        break;
                    case ":":

                        ParseResult[0] = "跨式組合";
                        ParseResult[6] = "3";
                        SettlementMonth = MonthSplit[0].Split(new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries);

                        switch (BS)
                        {
                            case "B":
                                ParseResult[1] = "B";
                                ParseResult[3] = "B";
                                break;
                            case "S":
                                ParseResult[1] = "S";
                                ParseResult[3] = "S";
                                break;
                            case "":
                                ParseResult[1] = foot1Bs;
                                ParseResult[3] = foot1Bs;

                                break;
                        }
                        break;
                }


                ParseResult[2] = commidity_ID + price[0].ToString() + SettlementMonth[0];
                ParseResult[4] = commidity_ID2 + price[0].ToString() + SettlementMonth[1]; ;

            }
            else if (ProductID.Substring(10, 1) == ":")     //勒式
            {
                Price = split[0].Split(new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries);

                ParseResult[0] = "勒式組合";
                ParseResult[6] = "4";

                switch (BS)
                {
                    case "B":
                        ParseResult[1] = "B";
                        ParseResult[3] = "B";

                        break;
                    case "S":

                        ParseResult[1] = "S";
                        ParseResult[3] = "S";

                        break;
                    case "":
                        ParseResult[1] = foot1Bs;
                        ParseResult[3] = foot1Bs;
                        break;
                }
                ParseResult[2] = commidity_ID + Price[0].ToString();
                ParseResult[4] = commidity_ID + Price[1].ToString();
            }
        }
        ParseResult[5] = ParseResult[3];
        return ParseResult;

    }


    ////取得基本資料-----
    //private void getINIData()
    //{

    //    try
    //    {
    //        WS_TRADELOGIC.TradeLogic objWS = new WS_TRADELOGIC.TradeLogic();
    //        DataSet dsData = objWS.WS_INI();
    //        //DataSet dsData = new DataSet(); 

    //        mdt_FutureData = dsData.Tables["future"];

    //        mdt_OptionData = dsData.Tables["option"];

    //        //mdt_MultipleFutureData = dsData.Tables["multipleFuture"];
    //        //mdt_FutureDetailData = dsData.Tables["futureDetail"];
    //        //mdt_OptionDetailData = dsData.Tables["optionDetail"];
    //        //mdt_TickData = dsData.Tables["KsCM026P"];
    //        //mdt_ErrorMapping = dsData.Tables["tblErrorMapping"];
    //        mdt_translate_values = dsData.Tables["translate_value"];

    //    }
    //    catch (Exception ex)
    //    {
    //        //mobj_dataAgentLog.WriteEntryData(ex.Message + "/" + ex.Source + "/" + ex.StackTrace);

    //    }

    //}

    //--------------------------------------------------------------------


    /// <summary>
    /// 0x51保證金查詢 回覆
    /// </summary>
    /// <returns>回傳DataTable</returns>
    public DataTable GetMOBCurrentMarginDT(string companyID, string acctID, string currency)
    {
        if (mdt_MOBCurrentMargin == null)
        {
            return null;
        }
        else
        {
            try
            {
                //if (currency == "TWD")
                //{
                //    currency = "NTT";
                //}
                //BOSHistoryQuery ws = new BOSHistoryQuery();
                //string str = ws.WS_getTMCOFUSE(companyID, acctID, currency);
                //if (str != "NA")
                //{
                //    mdt_MOBCurrentMargin.Rows[0]["TOTAL_DAMT"] = NumberTrim(str);
                //}
                //else
                //{
                //    mdt_MOBCurrentMargin.Rows[0]["TOTAL_DAMT"] = "";
                //}

                //mdt_MOBCurrentMargin.AcceptChanges();

            }
            catch (Exception ex)
            {

            }
            return mdt_MOBCurrentMargin;
        }
    }

    /// <summary>
    /// // 0x53當日損益查詢回覆
    /// </summary>
    /// <returns></returns>
    public DataTable GetMOBCurrentBalanceDT()
    {
        if (mdt_MOBCurrentBalance == null)
        {
            return null;
        }
        else
        {
            return mdt_MOBCurrentBalance;
        }
    }

    /// <summary>
    /// 取得RealPartMix--0x57 即時部位查詢回覆  混合查詢
    /// </summary>
    /// <returns></returns>
    public DataTable GetRealPartMixDT()
    {
        if (mdt_RealPartMix == null)
        {
            return null;
        }
        else
        {
            return mdt_RealPartMix;
        }
    }


    /// <summary>
    /// 取得RealPart--0x57 即時部位查詢回覆  單式查詢;
    /// </summary>
    /// <returns></returns>
    public DataTable GetRealPartDT()
    {
        if (mdt_RealPart == null)
        {
            return null;
        }
        else
        {
            DataTable dt = new DataTable();
            foreach (DataColumn dc in mdt_RealPart.Columns)
            {
                dt.Columns.Add(dc.ColumnName);
            }
            DataRow[] drs = mdt_RealPart.Select("", " productKind, MKTCOMNO, COMYM, STKPRC,CALLPUT");
            for (int i = 0; i < drs.Length; i++)
            {
                DataRow drNew = dt.NewRow();
                drNew.ItemArray = drs[i].ItemArray;
                dt.Rows.Add(drNew);
            }
            return dt;
        }
    }
    public DataTable GetMOBCombineDT()
    {
        if (mdt_MOBCombineData == null)
        {
            return null;
        }
        else
        {
            return mdt_MOBCombineData;
        }
    }

    public DataTable GetUnLiquidationMainDT()
    {
        if (mdt_UnLiquidationMain == null)
        {
            return null;
        }
        else
        {
            DataTable dt = new DataTable();
            foreach (DataColumn dc in mdt_UnLiquidationMain.Columns)
            {
                dt.Columns.Add(dc.ColumnName);
            }
            DataRow[] drs = mdt_UnLiquidationMain.Select("", " productKind, MKTCOMNO, COMYM, STKPRC_DEC,CALLPUT");
            for (int i = 0; i < drs.Length; i++)
            {
                DataRow drNew = dt.NewRow();
                drNew.ItemArray = drs[i].ItemArray;
                drNew["AvgMatchPrice"] = string.Format("{0:#,#0.##}", Math.Round(double.Parse(drNew["AvgMatchPrice"].ToString()), 2, MidpointRounding.AwayFromZero));//NumberTrim(drNew["AvgMatchPrice"].ToString());
                drNew["realPrice"] = NumberTrim(drNew["realPrice"].ToString());
                drNew["RefTotalPL"] = NumberTrim(drNew["RefTotalPL"].ToString());
                drNew["RefTotalPrice"] = NumberTrim(drNew["RefTotalPrice"].ToString());
                drNew["multipleMatchPrice1"] = NumberTrim(drNew["multipleMatchPrice1"].ToString());
                drNew["multipleMatchPrice2"] = NumberTrim(drNew["multipleMatchPrice2"].ToString());
                drNew["PriceDiff"] = NumberTrim(drNew["PriceDiff"].ToString());
                drNew["IAMT"] = NumberTrim(drNew["IAMT"].ToString());
                drNew["MAMT"] = NumberTrim(drNew["MAMT"].ToString());
                drNew["TAX"] = NumberTrim(drNew["TAX"].ToString());
                drNew["FEE"] = NumberTrim(drNew["FEE"].ToString());
                drNew["Equity"] = NumberTrim(drNew["Equity"].ToString());

                dt.Rows.Add(drNew);
            }
            return dt;

        }
    }

    public DataTable GetTotalUnLiquidationMainDT(string sort)
    {
        if (mdt_UnLiquidationMain == null)
        {
            return null;
        }
        else
        {
            DataTable dt = new DataTable();
            foreach (DataColumn dc in mdt_TotalUnLiquidation.Columns)
            {
                dt.Columns.Add(dc.ColumnName);
            }
            DataRow[] drs;
            if (sort == "CP")//CALLPUT
            {
                drs = mdt_TotalUnLiquidation.Select("", " productKind, MKTCOMNO, COMYM,CALLPUT, STKPRC_DEC");
            }
            else
            {
                drs = mdt_TotalUnLiquidation.Select("", " productKind, MKTCOMNO, COMYM, STKPRC_DEC,CALLPUT");
            }

            for (int i = 0; i < drs.Length; i++)
            {
                DataRow drNew = dt.NewRow();
                drNew.ItemArray = drs[i].ItemArray;
                drNew["AvgMatchPrice"] = string.Format("{0:#,#0.##}", Math.Round(double.Parse(drNew["AvgMatchPrice"].ToString()), 2, MidpointRounding.AwayFromZero));//NumberTrim(drNew["AvgMatchPrice"].ToString());
                drNew["realPrice"] = NumberTrim(drNew["realPrice"].ToString());
                drNew["RefTotalPL"] = NumberTrim(drNew["RefTotalPL"].ToString());

                drNew["multipleMatchPrice1"] = NumberTrim(drNew["multipleMatchPrice1"].ToString());
                drNew["multipleMatchPrice2"] = NumberTrim(drNew["multipleMatchPrice2"].ToString());

                drNew["TAX"] = NumberTrim(drNew["TAX"].ToString());
                drNew["FEE"] = NumberTrim(drNew["FEE"].ToString());
                drNew["Equity"] = NumberTrim(drNew["Equity"].ToString());

                dt.Rows.Add(drNew);
            }
            return dt;

        }
    }

    public DataTable GetUnLiquidationDetailDT()
    {
        if (mdt_UnLiquidationDetail == null)
        {
            return null;
        }
        else
        {
            DataTable dt = new DataTable();
            foreach (DataColumn dc in mdt_UnLiquidationDetail.Columns)
            {
                dt.Columns.Add(dc.ColumnName);
            }
            DataRow[] drs = mdt_UnLiquidationDetail.Select("", " productKind, MKTCOMNO, COMYM, STKPRC_DEC,CALLPUT");
            for (int i = 0; i < drs.Length; i++)
            {
                DataRow drNew = dt.NewRow();
                drNew.ItemArray = drs[i].ItemArray;

                drNew["MatchPrice"] = NumberTrim(drNew["MatchPrice"].ToString());
                drNew["RefRealPrice"] = NumberTrim(drNew["RefRealPrice"].ToString());
                drNew["RefNowPrice"] = NumberTrim(drNew["RefNowPrice"].ToString());
                drNew["RefPL"] = NumberTrim(drNew["RefPL"].ToString());
                drNew["TatolMatchPrice"] = NumberTrim(drNew["TatolMatchPrice"].ToString());
                drNew["multipleMatchPrice1"] = NumberTrim(drNew["multipleMatchPrice1"].ToString());
                drNew["multipleMatchPrice2"] = NumberTrim(drNew["multipleMatchPrice2"].ToString());
                drNew["IAMT"] = NumberTrim(drNew["IAMT"].ToString());
                drNew["MAMT"] = NumberTrim(drNew["MAMT"].ToString());
                drNew["TAX"] = NumberTrim(drNew["TAX"].ToString());
                drNew["FEE"] = NumberTrim(drNew["FEE"].ToString());
                drNew["Equity"] = NumberTrim(drNew["Equity"].ToString());

                dt.Rows.Add(drNew);
            }
            return dt;
        }
    }



    //V1.0.0.17 Added by peter on 20140616 月份(週選先), 買賣權(先CALL後PUT), 履約價(由小到大)
    public DataTable GetUnLiquidationMainDTSortByCP()
    {
        if (mdt_UnLiquidationMain == null)
        {
            return null;
        }
        else
        {
            DataTable dt = new DataTable();
            foreach (DataColumn dc in mdt_UnLiquidationMain.Columns)
            {
                dt.Columns.Add(dc.ColumnName);
            }
            DataRow[] drs = mdt_UnLiquidationMain.Select("", " productKind, MKTCOMNO, COMYM,CALLPUT, STKPRC_DEC");
            for (int i = 0; i < drs.Length; i++)
            {
                DataRow drNew = dt.NewRow();
                drNew.ItemArray = drs[i].ItemArray;
                drNew["AvgMatchPrice"] = string.Format("{0:#,#0.##}", Math.Round(double.Parse(drNew["AvgMatchPrice"].ToString()), 2, MidpointRounding.AwayFromZero));//NumberTrim(drNew["AvgMatchPrice"].ToString());
                drNew["realPrice"] = NumberTrim(drNew["realPrice"].ToString());
                drNew["RefTotalPL"] = NumberTrim(drNew["RefTotalPL"].ToString());
                drNew["RefTotalPrice"] = NumberTrim(drNew["RefTotalPrice"].ToString());
                drNew["multipleMatchPrice1"] = NumberTrim(drNew["multipleMatchPrice1"].ToString());
                drNew["multipleMatchPrice2"] = NumberTrim(drNew["multipleMatchPrice2"].ToString());
                drNew["PriceDiff"] = NumberTrim(drNew["PriceDiff"].ToString());
                drNew["IAMT"] = NumberTrim(drNew["IAMT"].ToString());
                drNew["MAMT"] = NumberTrim(drNew["MAMT"].ToString());
                drNew["TAX"] = NumberTrim(drNew["TAX"].ToString());
                drNew["FEE"] = NumberTrim(drNew["FEE"].ToString());
                drNew["Equity"] = NumberTrim(drNew["Equity"].ToString());

                dt.Rows.Add(drNew);
            }
            return dt;

        }
    }

    //V1.0.0.17 Added by peter on 20140616 月份(週選先), 買賣權(先CALL後PUT), 履約價(由小到大)
    public DataTable GetUnLiquidationDetailDTSortByCP()
    {
        if (mdt_UnLiquidationDetail == null)
        {
            return null;
        }
        else
        {
            DataTable dt = new DataTable();
            foreach (DataColumn dc in mdt_UnLiquidationDetail.Columns)
            {
                dt.Columns.Add(dc.ColumnName);
            }
            DataRow[] drs = mdt_UnLiquidationDetail.Select("", " productKind, MKTCOMNO, COMYM,CALLPUT, STKPRC_DEC");
            for (int i = 0; i < drs.Length; i++)
            {
                DataRow drNew = dt.NewRow();
                drNew.ItemArray = drs[i].ItemArray;

                drNew["MatchPrice"] = NumberTrim(drNew["MatchPrice"].ToString());
                drNew["RefRealPrice"] = NumberTrim(drNew["RefRealPrice"].ToString());
                drNew["RefNowPrice"] = NumberTrim(drNew["RefNowPrice"].ToString());
                drNew["RefPL"] = NumberTrim(drNew["RefPL"].ToString());
                drNew["TatolMatchPrice"] = NumberTrim(drNew["TatolMatchPrice"].ToString());
                drNew["multipleMatchPrice1"] = NumberTrim(drNew["multipleMatchPrice1"].ToString());
                drNew["multipleMatchPrice2"] = NumberTrim(drNew["multipleMatchPrice2"].ToString());
                drNew["IAMT"] = NumberTrim(drNew["IAMT"].ToString());
                drNew["MAMT"] = NumberTrim(drNew["MAMT"].ToString());
                drNew["TAX"] = NumberTrim(drNew["TAX"].ToString());
                drNew["FEE"] = NumberTrim(drNew["FEE"].ToString());
                drNew["Equity"] = NumberTrim(drNew["Equity"].ToString());

                dt.Rows.Add(drNew);
            }
            return dt;
        }
    }




    public DataTable GetRealPartDTSortByCP()
    {
        if (mdt_RealPart == null)
        {
            return null;
        }
        else
        {
            DataTable dt = new DataTable();
            foreach (DataColumn dc in mdt_RealPart.Columns)
            {
                dt.Columns.Add(dc.ColumnName);
            }
            DataRow[] drs = mdt_RealPart.Select("", " productKind, MKTCOMNO, COMYM,CALLPUT, STKPRC");
            for (int i = 0; i < drs.Length; i++)
            {
                DataRow drNew = dt.NewRow();
                drNew.ItemArray = drs[i].ItemArray;
                dt.Rows.Add(drNew);
            }
            return dt;
        }
    }


    private string ParsePGWNumber(string source, int i)
    {
        string ret = "0";
        try
        {
            ret = source.Substring(0, source.Length - i) + "." + source.Substring(source.Length - i, i);

        }
        catch (Exception ex)
        {

        }
        return ret;
    }
}
