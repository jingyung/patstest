﻿using System;
using System.Collections.Generic;
using System.Text;

//using com.ddsc.tool;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Configuration;
using System.Runtime.InteropServices;
using com.ddsc.BI.Account;
namespace com.ddsc.net
{

    [StructLayoutAttribute(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    struct OpenGWSendHead
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] NetWorkId;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
        public char[] InvestorAcno;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
        public char[] Password;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] Source;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] Type;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] ReturnCode;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] LoginType;


        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] SystemCode;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 14)]
        public char[] remark;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] DataLength;
    }
    struct OpenGWSendData04
    {

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
        public char[] NewPassword;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] Type;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] VoiceFlag;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 18)]
        public char[] remark;


    }
    struct OpenGWSendData83
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
        public char[] password;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
        public char[] IP;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
        public char[] remark;


    }
    struct OpenGWRecvHead
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public char[] NetWorkId;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
        public char[] InvestorAcno;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
        public char[] InvestorName;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] Source;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 2)]
        public char[] Type;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] ReturnCode;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public char[] LoginType;


        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] SystemCode;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 14)]
        public char[] remark;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 5)]
        public char[] DataLength;
    }
    struct OpenGWRcvData83
    {


        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
        public char[] remark;


    }
    struct OpenGWRcvData04
    {


        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
        public char[] remark;


    }


    public class SocketClient
    {

        public static byte[] StructureToByteArray(object structObj)
        {
            int size = Marshal.SizeOf(structObj);
            IntPtr buffer = Marshal.AllocHGlobal(size);
            try
            {
                Marshal.StructureToPtr(structObj, buffer, false);
                byte[] bytes = new byte[size];
                Marshal.Copy(buffer, bytes, 0, size);
                return bytes;
            }
            finally
            {
                Marshal.FreeHGlobal(buffer);
            }
        }

        ///// <summary>
        ///// 使用Socket物件
        ///// </summary>
        //public Socket m_ObjTcpSocket;

        public Socket tcp;


        /// </summary>
        private string m_strIP;
        /// <summary>
        /// remote Port
        /// </summary>
        private int m_intPort;
        /// <summary>
        /// 使用者ID
        /// </summary>
        private string m_strUserId;

        private string m_strCompany;

        /// <summary>
        /// 初始化物件


        public SocketClient(string name, string ip, string port, string company, string userId, int connectionTimeOut, int receiveTimeOut, int sendTimeOut)
        {
            try
            {
                tcp = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                m_strIP = ip;
                m_intPort = System.Convert.ToInt32(port);
                m_strUserId = userId;
                m_strCompany = company;
                // tcp = new Tcp();
                this.tcp.ReceiveBufferSize = 16 * 1024 * 1024;
                this.tcp.SendBufferSize = 16 * 1024 * 1024;

                tcp.ReceiveTimeout = receiveTimeOut;
                tcp.SendTimeout = sendTimeOut;

            }
            catch (Exception ex)
            {
                // mobj_ErrorLog.WriteError(ex.Source, "初始化失敗:" + ex.Message, ex.StackTrace, System.Diagnostics.EventLogEntryType.Error);
                throw ex;
            }

        }

        /// <summary>
        /// Socket連結
        /// </summary>
        /// <param name="remoteEP"></param>
        /// <param name="client"></param>
        public Boolean Connect()
        {
            Boolean status = false;
            try
            {

                tcp.Connect(m_strIP, m_intPort);
                status = true;
            }
            catch (Exception ex)
            {
                status = false;
                //SocketClientDispose();

                throw ex;
            }
            finally
            {


            }
            return status;
        }


        /// <summary>
        /// 接收資料處理
        /// </summary>
        public string[] Receive(int sendcount)
        {
            string[] receiveData;
            int receivecound = 0;
            System.Collections.ArrayList receiveArray = new System.Collections.ArrayList();
            string data = "";
            Boolean hasReceived = false;

            DateTime startReceiveTime = DateTime.Now;
            string timeOut = System.Configuration.ConfigurationManager.AppSettings["SOCKET_TIMEOUT"];
            if (timeOut == "")
            {
                timeOut = "0";
            }
            try
            {
                while (tcp.Connected)
                {
                    byte[] lbyt_Head;

                    byte[] lbyt_Data;
                    int lint_Len = 0;


                    lbyt_Head = ReceiveRawBuffer(50, tcp);
                    if (BitConverter.IsLittleEndian)
                        Array.Reverse(lbyt_Head, 48, 2);
                    int BodyLen = BitConverter.ToUInt16(lbyt_Head, 48);


                    if (BodyLen > 0)
                    {
                        lbyt_Data = ReceiveRawBuffer(BodyLen, tcp);

                        ReceiveRawBuffer(1, tcp);//end
                        //讀內文
                        receivecound++;
                        data = ASCIIEncoding.Default.GetString(lbyt_Data);
                        switch (lbyt_Data[0])
                        {
                            case 0x70:   //0x71 查成交價
                            case 0x72:   //0x71 查成交價
                            case 0x76:   //0x71 查成交價
                            case 0x77:   //0x71 查成交價
                                data = data.Substring(1);
                                receiveArray.Add(data);
                                break;

                            default:
                                receiveArray.Add(data);
                                break;
                        }
                       
                      
                        //----記錄第一次收到訊息的時間----------
                        if (!hasReceived)
                        {
                            hasReceived = true;

                        }
                        //systex header
                        //ret.FCODE = new char[] { Convert.ToChar(0x53) };
                        //ret.SEQNO = SEQNO.PadLeft(8, '0').ToCharArray();
                        //ret.MTYPE = " ".ToCharArray();
                        //ret.FIRM = "       ".ToCharArray();
                        //ret.ACTNO = "       ".ToCharArray();
                        //ret.BODYCNT = "00".ToCharArray(); 
                        //ret.EOR = new char[] { Convert.ToChar(0x0a) }; <==================== 當26 為0x0a時 代表沒有資料


                        // systex head+ psg header
                        //public char[] head;   1
                        //[MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                        //public char[] ESCCODE;
                        //[MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
                        //public char[] LENGTH;
                        //[MarshalAs(UnmanagedType.ByValArray, SizeConst = 3)]
                        //public char[] TYPE;

                        //[MarshalAs(UnmanagedType.ByValArray, SizeConst = 10)]
                        //public char[] NETWORKID;
                        //[MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
                        //public char[] SEQNO;        <======================  當19 為"0"時 代表沒有資料
                        Boolean conFlag = true;
                        switch (lbyt_Data[0])
                        {
                            case 0x51:   // 0x51保證金查詢 回覆
                                conFlag = false;
                                break;
                            case 0x13:       //0x13 未平倉查詢回覆
                                if (lbyt_Data[26] == 0x0a)
                                {
                                    conFlag = false;
                                }

                                break;

                            case 0x53:       // 0x53當日損益查詢回覆
                                conFlag = false;
                                break;

                            case 0x57:   //0x57 即時部位查詢回覆  單式查詢  混合查詢 分別填入兩個不同的table
                                if (lbyt_Data[26] == 0x0a)
                                {
                                    conFlag = false;
                                }

                                break;

                            case 0x62:   //0x62 拆組
                            case 0x65:  //0x65 拆組     101
                                //判斷是否為最後一筆
                                if (receivecound == sendcount)
                                {
                                    conFlag = false;
                                }

                                break;

                            case 0x22:       //0x22  平倉查詢回覆
                                if (lbyt_Data[19] == 0x30)
                                {
                                    conFlag = false;
                                }
                                break;
                            case 0x23:   // 0x23出入金查詢 回覆
                                if (lbyt_Data[19] == 0x30)
                                {
                                    conFlag = false;
                                }
                                break;
                            case 0x24:   // 0x24出入金申請 回覆
                                conFlag = false;
                                break;

                            case 0x59:   // 0x59未平倉彙總 回覆
                                if (lbyt_Data[19] == 0x30)
                                {
                                    conFlag = false;
                                }
                                break;
                            case 0x60:   // 0x60 高風險

                                if (lbyt_Data[19] == 0x30)
                                {
                                    conFlag = false;
                                }
                                break;
                            case 0x63:   // 0x63 高風險低於25
                                if (lbyt_Data[19] == 0x30)
                                {
                                    conFlag = false;
                                }
                                break;
                            case 0x70:   //0x71 查成交價
                            case 0x72:   //0x71 查成交價
                            case 0x76:   //0x71 查成交價
                            case 0x77:   //0x71 查成交價
                                
                                if (data == "0")
                                    conFlag = false;

                                break;
                            default:

                                conFlag = false;

                                break;
                        }
                        //---------------------------------------------------------------
                        if (!conFlag)
                        {

                            tcp.Close();

                            break;
                        }



                    }

                    if (DateTime.Now > startReceiveTime.AddMilliseconds(Convert.ToDouble(timeOut)))
                    {
                        break;
                        throw new Exception("Receive Time Out");
                    }
                }



            }
            catch (System.Net.Sockets.SocketException ex)
            {
                string errMsg = ex.ToString();
                throw ex;
            }
            receiveData = new string[receiveArray.Count];
            Int32 idx = 0;
            for (idx = 0; idx < receiveArray.Count; idx++)
            {
                receiveData[idx] = receiveArray[idx].ToString();
            }

            return receiveData;
        }



        public string[] ReceiveForOpenGW(int sendcount)
        {
            string[] receiveData;
            int receivecound = 0;
            System.Collections.ArrayList receiveArray = new System.Collections.ArrayList();

            Boolean hasReceived = false;

            DateTime startReceiveTime = DateTime.Now;
            string timeOut = System.Configuration.ConfigurationManager.AppSettings["SOCKET_TIMEOUT"];
            if (timeOut == "")
            {
                timeOut = "0";
            }
            try
            {
                while (tcp.Connected)
                {
                    byte[] lbyt_Head = new byte[81];

                    byte[] lbyt_Data;
                    int lint_Len = 0;
                    string STR_ReceivedData;



                    //迴圈中不斷讀取資訊
                    //讀頭碼
                    TCP_ByteRead(tcp, lbyt_Head, 0, 80);

                    OpenGWRecvHead head = new OpenGWRecvHead();

                    ParserStruct<OpenGWRecvHead>.ByteArrayToStructure(lbyt_Head, ref head);


                    lint_Len = int.Parse(new string(head.DataLength));
                    //讀內文
                    receivecound++;
                    if (lint_Len > 1)
                    {
                        lbyt_Data = new byte[lint_Len];

                        TCP_ByteRead(tcp, lbyt_Data, 0, lint_Len);

                        STR_ReceivedData = new string(Encoding.Default.GetChars(lbyt_Head))

                            + new string(Encoding.Default.GetChars(lbyt_Data));

                        receiveArray.Add(STR_ReceivedData);

                        //----記錄第一次收到訊息的時間----------
                        if (!hasReceived)
                        {
                            hasReceived = true;

                        }
                        //---------------------------------------



                        Boolean conFlag = true;
                        switch (new string(head.Type).Trim())
                        {
                            case "04":   // 更改密碼
                                conFlag = false;
                                break;
                            case "83":   // 出金密碼驗證
                                conFlag = false;
                                break;
                            default:
                                conFlag = false;
                                break;
                        }
                        //---------------------------------------------------------------
                        if (!conFlag)
                        {
                            tcp.Close();
                            //tcp.Dispose();
                            break;
                        }



                    }

                    if (DateTime.Now > startReceiveTime.AddMilliseconds(Convert.ToDouble(timeOut)))
                    {
                        break;
                        throw new Exception("Receive Time Out");
                    }
                }



            }
            catch (System.Net.Sockets.SocketException ex)
            {
                string errMsg = ex.ToString();
                throw ex;
            }
            receiveData = new string[receiveArray.Count];
            Int32 idx = 0;
            for (idx = 0; idx < receiveArray.Count; idx++)
            {
                receiveData[idx] = receiveArray[idx].ToString();
            }

            return receiveData;
        }


        /// <summary>
        /// 讀取網路流資料
        /// </summary>
        private int TCP_ByteRead(Socket tcp, byte[] buffer, int start, int length)
        {
            int lint_total = 0;
            int lint_read = 0;
            int lint_count = 0;

            do
            {
                int s = tcp.Receive(buffer, start + lint_total, length - lint_total, System.Net.Sockets.SocketFlags.None);
                lint_read = s;
                lint_total += lint_read;
                lint_count++;
            } while ((lint_total < length) && (lint_count < 100));
            return lint_total;
        }

        public void ReceiveRawBuffer(byte[] RcvBuffer, int SourceIndex, int Size, Socket RcvS)
        {
            try
            {
                int total = 0;
                int RcvLength = 0;

                total += RcvS.Receive(RcvBuffer, SourceIndex, Size, System.Net.Sockets.SocketFlags.None);
                if (total > 0)
                {
                    while (total != Size)
                    {
                        total += RcvLength = RcvS.Receive(RcvBuffer, SourceIndex + total, Size - total, SocketFlags.None);
                        if (RcvLength > 0)
                            continue;
                        else
                            throw new SocketException((int)SocketError.ConnectionReset);
                    }
                }
                else
                    throw new SocketException((int)SocketError.ConnectionReset);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public byte[] ReceiveRawBuffer(int Size, Socket RcvS)
        {
            try
            {
                int total = 0;
                int RcvLength = 0;
                byte[] RcvBuffer = new byte[Size];

                total += RcvS.Receive(RcvBuffer, 0, RcvBuffer.Length, System.Net.Sockets.SocketFlags.None);
                if (total > 0)
                {
                    while (total != RcvBuffer.Length)
                    {
                        total += RcvLength = RcvS.Receive(RcvBuffer, total, RcvBuffer.Length - total, SocketFlags.None);
                        if (RcvLength > 0)
                            continue;
                        else
                            throw new SocketException((int)SocketError.ConnectionReset);
                    }
                }
                else
                    throw new SocketException((int)SocketError.ConnectionReset);
                return RcvBuffer;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }



        /// <summary>
        /// 傳送資料
        /// </summary>
        public int m_ObjTcpSocketSendData(Socket m_ObjTcpSocket, string str_Data)
        {
            try
            {
                if (m_ObjTcpSocket != null && m_ObjTcpSocket.Connected)
                {

                    AccountSockClientParserFunction.DDSCDGWHead Head = new AccountSockClientParserFunction.DDSCDGWHead();
                    Head.HEAD = new byte[1] { AccountSockClientParserFunction.DDSCSocketHead.DGWST };
                    Head.MESSAGETIME = ASCIIEncoding.Default.GetBytes(DateTime.Now.ToString("HHmmssfff"));
                    Head.SEQ = ASCIIEncoding.Default.GetBytes("".PadRight(10, ' '));
                    Head.FUNCTION = ASCIIEncoding.Default.GetBytes("".PadRight(3, ' '));
                    Head.SYSTEMCODE = ASCIIEncoding.Default.GetBytes("WEB".PadRight(3, ' '));
                    Head.TMP = ASCIIEncoding.Default.GetBytes("".PadRight(22, ' '));

                    byte[] body = ASCIIEncoding.Default.GetBytes(str_Data);

                    Head.LENGTH = BitConverter.GetBytes(UInt16.Parse(body.Length.ToString()));
                    if (BitConverter.IsLittleEndian)
                        Array.Reverse(Head.LENGTH);
                    byte[] headbyte = AccountSockClientParserFunction.StructureToByteArray(Head);


                    byte[] SendDataBuffer = new byte[50 + body.Length + 1];
                    Array.Copy(headbyte, 0, SendDataBuffer, 0, headbyte.Length);
                    Array.Copy(body, 0, SendDataBuffer, headbyte.Length, body.Length);
                    SendDataBuffer[SendDataBuffer.Length - 1] = AccountSockClientParserFunction.DDSCSocketHead.End;

                    return m_ObjTcpSocket.Send(SendDataBuffer);
                }
            }
            catch (Exception ex)
            {
                throw ex;
                //mobj_ErrorLog.WriteError(ex.Source, ex.Message, ex.StackTrace, System.Diagnostics.EventLogEntryType.Error);

            }
            return 0;
        }

        /// <summary>
        /// 取字串轉byte後長度
        /// </summary>
        private static int getStringLen(string STR_Data)
        {
            byte[] bString = System.Text.Encoding.Default.GetBytes(STR_Data);
            return bString.Length;
        }

        //範例方法 Send 會以 ASCII 格式將指定字串資料編碼，
        //並以非同步方式將資料傳送到由指定通訊端表示的網路裝置。下列範例實作了 Send 方法
        public int Send(String data)
        {
            if (tcp.Connected)
            {
                try
                {
                    return m_ObjTcpSocketSendData(tcp, data);
                }
                catch (Exception e)
                {
                    throw e;
                    Console.WriteLine(e.ToString());
                }
            }
            else
            {
                //連結未建立
            }
            return 0;

        }

        public void ConnectionDispose()
        {
            // tcp.Shutdown(SocketShutdown.Both);

            tcp.Close();

        }





        public static string EncodeString(string pwd)
        {



            if (Boolean.Parse(ConfigurationSettings.AppSettings["EnDeCode"]))
            {
                byte[] encbuff = System.Text.Encoding.Default.GetBytes(pwd);
                return Convert.ToBase64String(encbuff);
            }
            else
                return pwd;
        }


        public static string DecodeString(string pwd)
        {
            if (Boolean.Parse(ConfigurationSettings.AppSettings["EnDeCode"]))
            {
                byte[] decbuff = Convert.FromBase64String(pwd);
                return System.Text.Encoding.Default.GetString(decbuff);
            }
            else
                return pwd;
        }



        public class ParserStruct<T>
        {
            public static void ByteArrayToStructure(byte[] bytearray, ref T obj)
            {
                int len = Marshal.SizeOf(obj);
                IntPtr i = Marshal.AllocHGlobal(len);
                Marshal.Copy(bytearray, 0, i, len);
                obj = (T)Marshal.PtrToStructure(i, typeof(T));
                Marshal.FreeHGlobal(i);
            }

            public static void ByteArrayToStructure(byte[] bytearray, int index, ref T obj)
            {
                int len = Marshal.SizeOf(obj);
                IntPtr i = Marshal.AllocHGlobal(len);
                Marshal.Copy(bytearray, index, i, len);
                obj = (T)Marshal.PtrToStructure(i, typeof(T));
                Marshal.FreeHGlobal(i);
            }
        }


    }
}
