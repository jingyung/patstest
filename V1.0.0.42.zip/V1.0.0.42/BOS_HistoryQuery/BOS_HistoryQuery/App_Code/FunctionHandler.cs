﻿using System.Text;
using System.Data;
using System.Resources;
using System.Reflection;
using System.IO;
using System.Security.Cryptography;
using System.Xml;
using System;
using System.Collections.Generic;

using com.ddsc.net;

public class FunctionHandler
{

    //public bool BindDrpDown(DataTable p_dt, System.Web.UI.HtmlControls.HtmlSelect p_DrpDown, string p_value, string p_text, bool p_IsAll)
    //{
    //    try
    //    {
    //        System.Web.UI.WebControls.ListItem m_lc = new System.Web.UI.WebControls.ListItem();
    //        m_lc.Text = "ALL";
    //        m_lc.Value = "";
    //        p_DrpDown.DataSource = p_dt;
    //        p_DrpDown.DataTextField = p_text;
    //        p_DrpDown.DataValueField = p_value;
    //        p_DrpDown.DataBind();
    //        if (p_IsAll)
    //        {
    //            p_DrpDown.Items.Insert(0, m_lc);
    //        }
    //        else
    //        {
    //            p_DrpDown.Items.Insert(0, "");
    //        }
    //        return true;
    //    }
    //    catch (Exception ex)
    //    {
    //        return false;
    //    }
    //}

    public string[] GetMessage(string SendMsg)
    {

        string remoteIP = System.Configuration.ConfigurationManager.AppSettings["REMOTE_IP"];
        string remotePORT = System.Configuration.ConfigurationManager.AppSettings["REMOTE_PORT"];
        string timeOut = System.Configuration.ConfigurationManager.AppSettings["SOCKET_TIMEOUT"];
        com.ddsc.net.SocketClient client = new com.ddsc.net.SocketClient("", remoteIP, remotePORT, "", "", Convert.ToInt32(timeOut), Convert.ToInt32(timeOut), Convert.ToInt32(timeOut));
        string remote = "";
        try
        {

            client.Connect();

            remote = ((System.Net.IPEndPoint)client.tcp.LocalEndPoint).Port.ToString();

            BOSHistoryQuery._LM.WriteLog("WS_SEND", "[" + remote + "] " + BOSHistoryQuery.GetIP() + SendMsg);
            int g = client.Send(SendMsg);

            //string T4b = DateTime.Now.ToString("HH:mm:ss.fff");

            string[] s = client.Receive(1);

            //string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
            Int32 idx = 0;
     

            BOSHistoryQuery._LM.WriteLog("WS_RECV", "[" + remote + "] " + BOSHistoryQuery.GetIP());

            client.ConnectionDispose();
            return s;
        }
        catch (Exception ex)
        {
            if (client.tcp != null)
            {
                client.ConnectionDispose();
            }
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", "[" + remote + "] " + BOSHistoryQuery.GetIP() + "[GetMessage]" + ex.Message);
            return null;
        }
        finally
        {

        }

    }
    public string[] GetMessage(string[] SendMsg)
    {
        string remoteIP = System.Configuration.ConfigurationManager.AppSettings["REMOTE_IP"];
        string remotePORT = System.Configuration.ConfigurationManager.AppSettings["REMOTE_PORT"];
        string timeOut = System.Configuration.ConfigurationManager.AppSettings["SOCKET_TIMEOUT"];
        com.ddsc.net.SocketClient client = new com.ddsc.net.SocketClient("", remoteIP, remotePORT, "", "", Convert.ToInt32(timeOut), Convert.ToInt32(timeOut), Convert.ToInt32(timeOut));

        string addr = "";
        string remote = "";
        try
        {

            client.Connect();

            remote = ((System.Net.IPEndPoint)client.tcp.LocalEndPoint).Port.ToString();
            foreach (string str in SendMsg)
            {
                string msg = str;


                BOSHistoryQuery._LM.WriteLog("WS_SEND", "[" + remote + "]" + BOSHistoryQuery.GetIP() + msg);

                int g = client.Send(msg);

                //string T4b = DateTime.Now.ToString("HH:mm:ss.fff");
            }
            string[] s = client.Receive(SendMsg.Length);

            //string T4e = DateTime.Now.ToString("HH:mm:ss.fff");
            Int32 idx = 0;
  
            BOSHistoryQuery._LM.WriteLog("WS_RECV", "[" + remote + "] " + BOSHistoryQuery.GetIP()  );



            client.ConnectionDispose();
            return s;
        }
        catch (Exception ex)
        {
            if (client.tcp != null)
            {
                client.ConnectionDispose();
            }
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", "[" + remote + "] " + BOSHistoryQuery.GetIP() + "[GetMessage]" + ex.Message);
            return null;
        }
        finally
        {

        }

    }


    public string[] GetMessageOpenGW(byte[] buffer)
    {
        string remoteIP = System.Configuration.ConfigurationManager.AppSettings["OpenGWIP"];
        string remotePORT = System.Configuration.ConfigurationManager.AppSettings["OpenGWPort"];
        string timeOut = System.Configuration.ConfigurationManager.AppSettings["SOCKET_TIMEOUT"];
        com.ddsc.net.SocketClient client = new com.ddsc.net.SocketClient("", remoteIP, remotePORT, "", "", Convert.ToInt32(timeOut), Convert.ToInt32(timeOut), Convert.ToInt32(timeOut));
        string msg = System.Text.ASCIIEncoding.ASCII.GetString(buffer);
        string addr = "";

        try
        {

            client.Connect();

            BOSHistoryQuery._LM.WriteLog("WS_OPENSEND", BOSHistoryQuery.GetIP() + msg);

            client.tcp.Send(buffer, buffer.Length, System.Net.Sockets.SocketFlags.None);


            //string T4b = DateTime.Now.ToString("HH:mm:ss.fff");

            string[] s = client.ReceiveForOpenGW(10);
            Int32 idx = 0;
            for (idx = 0; idx < s.Length; idx++)
            {
                BOSHistoryQuery._LM.WriteLog("WS_OPENRECV", BOSHistoryQuery.GetIP() + s[idx]);

            }


            client.ConnectionDispose();
            return s;
        }
        catch (Exception ex)
        {
            if (client.tcp != null)
            {
                client.ConnectionDispose();
            }
            BOSHistoryQuery._LM.WriteLog("WS_ERROR", BOSHistoryQuery.GetIP() + "[GetMessageOpenGW]" + ex.Message);
            return null;
        }
        finally
        {

        }

    }


    public string fh_EncString(string pwd)
    {
        Int32 i = 0;
        string encPwd = "";
        try
        {
            if (pwd != "")
            {
                for (i = 0; i < pwd.Length; i++)
                {
                    encPwd = encPwd + Convert.ToChar(159 - ((int)Convert.ToChar(pwd.Substring(i, 1)))).ToString();
                }
            }
        }
        catch (Exception ex)
        {

        }
        return encPwd;
    }


    public string[] getOpenGWPasswordCheck(string CompanyID, string acno, string password, string ip)
    {
        OpenGWSendHead head = new OpenGWSendHead();

        head.NetWorkId = DateTime.Now.ToString("HHmmssff").PadRight(8, ' ').ToCharArray();
        head.InvestorAcno = (CompanyID + acno).PadRight(20, ' ').ToCharArray();
        head.Password = "".PadRight(20, ' ').ToCharArray();
        head.Source = System.Configuration.ConfigurationManager.AppSettings["OpenGWSourceCode"].PadRight(1, ' ').ToCharArray();
        head.Type = "83".PadRight(2, ' ').ToCharArray();
        head.ReturnCode = "".PadRight(5, ' ').ToCharArray();
        head.LoginType = "".PadRight(1, ' ').ToCharArray();
        head.SystemCode = "DVIP".PadRight(5, ' ').ToCharArray();
        head.remark = "".PadRight(14, ' ').ToCharArray();
        head.DataLength = "72".PadRight(5, ' ').ToCharArray();

        OpenGWSendData83 body = new OpenGWSendData83();
        body.password = password.PadRight(32, ' ').ToCharArray();
        body.IP = ip.PadRight(32, ' ').ToCharArray();
        body.remark = "".PadRight(32, ' ').ToCharArray();


        byte[] h = SocketClient.StructureToByteArray(head);
        byte[] b = SocketClient.StructureToByteArray(body);

        byte[] send = new byte[h.Length + b.Length];

        Array.Copy(h, 0, send, 0, h.Length);

        Array.Copy(b, 0, send, h.Length, b.Length);

        string[] returnStr = GetMessageOpenGW(send);
        return returnStr;
    }



    public string[] getOpenGWChangePassword(string CompanyID, string acno, string password, string changepassword)
    {
        OpenGWSendHead head = new OpenGWSendHead();

        head.NetWorkId = DateTime.Now.ToString("HHmmssff").PadRight(8, ' ').ToCharArray();
        head.InvestorAcno = (CompanyID + acno).PadRight(20, ' ').ToCharArray();
        head.Password = password.PadRight(20, ' ').ToCharArray();
        head.Source = System.Configuration.ConfigurationManager.AppSettings["OpenGWSourceCode"].PadRight(1, ' ').ToCharArray();
        head.Type = "04".PadRight(2, ' ').ToCharArray();
        head.ReturnCode = "".PadRight(5, ' ').ToCharArray();
        head.LoginType = "".PadRight(1, ' ').ToCharArray();
        head.SystemCode = "DVIP".PadRight(5, ' ').ToCharArray();
        head.remark = "".PadRight(14, ' ').ToCharArray();
        head.DataLength = "40".PadRight(5, ' ').ToCharArray();

        OpenGWSendData04 body = new OpenGWSendData04();
        body.NewPassword = changepassword.PadRight(20, ' ').ToCharArray();
        body.Type = "W".PadRight(1, ' ').ToCharArray();
        body.VoiceFlag = "N".PadRight(1, ' ').ToCharArray();
        body.remark = "1".PadRight(18, ' ').ToCharArray();


        byte[] h = SocketClient.StructureToByteArray(head);
        byte[] b = SocketClient.StructureToByteArray(body);

        byte[] send = new byte[h.Length + b.Length];

        Array.Copy(h, 0, send, 0, h.Length);

        Array.Copy(b, 0, send, h.Length, b.Length);

        string[] returnStr = GetMessageOpenGW(send);
        return returnStr;
    }



    /// <summary>
    /// 成交價查詢
    /// </summary>
    /// <param name="CustomerId"></param>
    /// <param name="currency"></param>
    /// <param name="CompanyID"></param>
    /// <returns></returns>
    public string[] getMOB_MatchPrice(string productid)
    {

        string sendStr = MOB_RequestSeqID(Encoding.Default.GetString(new byte[] { 0x70 }) + productid.PadRight(20, ' '));
        string[] returnStr = GetMessage(sendStr);
        return returnStr;
    }
    public string[] getOrderPrice(string productid)
    {

        string sendStr = MOB_RequestSeqID(Encoding.Default.GetString(new byte[] { 0x77 }) + productid.PadRight(20, ' '));
        string[] returnStr = GetMessage(sendStr);
        return returnStr;
    }
    /// <summary>
    /// 最高最低價查詢
    /// </summary>
    /// <param name="CustomerId"></param>
    /// <param name="currency"></param>
    /// <param name="CompanyID"></param>
    /// <returns></returns>
    public string[] getMOB_HighLowPrice(string productid)
    {

        string sendStr = MOB_RequestSeqID(Encoding.Default.GetString(new byte[] { 0x72 }) + productid.PadRight(20, ' '));
        string[] returnStr = GetMessage(sendStr);
        return returnStr;
    }
    /// <summary>
    /// MOB保証金查詢
    /// </summary>
    /// <param name="CustomerId"></param>
    /// <param name="currency"></param>
    /// <param name="CompanyID"></param>
    /// <returns></returns>
    public string[] getMOB_CurrentMargin(string CustomerId, string currency, string CompanyID)
    {
        string futureID = System.Configuration.ConfigurationManager.AppSettings["FUTURE_ID"];
        futureID = "";
        string sendStr = MOB_RequestSeqID(Encoding.Default.GetString(new byte[] { 0x50 }) + CompanyID.Trim().PadRight(7, ' ') + CustomerId.PadLeft(7, '0') + currency.PadRight(3, ' '));
        string[] returnStr = GetMessage(sendStr);
        return returnStr;
    }

    /// <summary>
    /// 取得MOB未平倉資料
    /// </summary>
    /// <param name="CustomerId"></param>
    /// <param name="CompanyID"></param>
    /// <returns></returns>
    public string[] getMOB_UnLiquidation(string CustomerId, string CompanyID, string currency)
    {
        string futureID = System.Configuration.ConfigurationManager.AppSettings["FUTURE_ID"];
        futureID = "";
        string sendStr = MOB_RequestSeqID(Encoding.Default.GetString(new byte[] { 0x05 }) + CompanyID.Trim() + CustomerId.PadLeft(7, '0') + currency.PadRight(3, ' '));
        string[] returnStr = GetMessage(sendStr);
        return returnStr;
    }
    /// <summary>
    /// 取得彙總未平倉資料
    /// </summary>
    /// <param name="CustomerId"></param>
    /// <param name="CompanyID"></param>
    /// <returns></returns>
    public string[] getMOB_TotalUnLiquidation(string CustomerId, string CompanyID, string currency, string ACTION)
    {
        string futureID = System.Configuration.ConfigurationManager.AppSettings["FUTURE_ID"];
        futureID = "";
        string sendStr = MOB_RequestSeqID(Encoding.Default.GetString(new byte[] { 0x59 }) + CompanyID.Trim() + CustomerId.PadLeft(7, '0') + currency.PadRight(3, ' ') + ACTION.PadRight(1, ' '));
        string[] returnStr = GetMessage(sendStr);
        return returnStr;
    }


    /// <summary>
    /// 即時部位查詢
    /// </summary>
    /// <param name="CustomerId"></param>
    /// <param name="type">1:單式部位  2:全部</param>
    /// <param name="CompanyID"></param>
    /// <returns></returns>
    public string[] getMOB_CurrentPosition(string CustomerId, string type, string CompanyID)  //傳入customer id 與  type(看單式部位或是全部)
    {
        //即時部位查詢 0x56   1:單式部位  2:全部
        string futureID = System.Configuration.ConfigurationManager.AppSettings["FUTURE_ID"];
        futureID = "";
        string sendStr = MOB_RequestSeqID(Encoding.Default.GetString(new byte[] { 0x56 }) + futureID + CompanyID.Trim() + CustomerId.PadLeft(7, '0') + "2" + type + "".PadLeft(20, ' '));
        string[] returnStr = GetMessage(sendStr);
        return returnStr;
    }


    /// <summary>
    /// MOB當日損益查詢
    /// </summary>
    /// <param name="CustomerId"></param>
    /// <param name="currency"></param>
    /// <param name="CompanyID"></param>
    /// <returns></returns>
    public string[] getMOB_CurrentBalance(string CustomerId, string currency, string CompanyID)
    {
        string futureID = System.Configuration.ConfigurationManager.AppSettings["FUTURE_ID"];
        futureID = "";
        string sendStr = MOB_RequestSeqID(Encoding.Default.GetString(new byte[] { 0x52 }) + futureID + CompanyID.Trim() + CustomerId + currency);
        string[] returnStr = GetMessage(sendStr);
        return returnStr;

    }


    /// <summary>
    /// 拆組申請
    /// </summary>
    /// <param name="CustomerId"></param>
    /// <param name="CompanyID"></param>
    /// <returns></returns>
    public string[] getMOB_Combine(string CustomerId, string CompanyID, string[] combineData)
    {
        string futureID = System.Configuration.ConfigurationManager.AppSettings["FUTURE_ID"];
        futureID = "";
        string[] sendStr = new string[combineData.Length];
        for (int i = 0; i < combineData.Length; i++)
        {
            //轉換分公司和帳號 
            string senddata = combineData[i].Substring(0, 9) + CompanyID.PadLeft(7, '0') + CustomerId.PadLeft(7, '0') + combineData[i].Substring(23, combineData[i].Length - 23);
            sendStr[i] = MOB_RequestSeqID(Encoding.Default.GetString(new byte[] { 0x61 }) + senddata);
        }
        string[] returnStr = GetMessage(sendStr);
        return returnStr;
    }
    /// <summary>
    /// 了結申請
    /// </summary>
    /// <param name="CustomerId"></param>
    /// <param name="CompanyID"></param>
    /// <returns></returns>
    public string[] getMOB_Net(string CustomerId, string CompanyID, string[] combineData)
    {
        string futureID = System.Configuration.ConfigurationManager.AppSettings["FUTURE_ID"];
        futureID = "";
        string[] sendStr = new string[combineData.Length];
        for (int i = 0; i < combineData.Length; i++)
        {
            //轉換分公司和帳號 
            string senddata = combineData[i].Substring(0, 9) + CompanyID.PadLeft(7, '0') + CustomerId.PadLeft(7, '0') + combineData[i].Substring(23, combineData[i].Length - 23);

            sendStr[i] = MOB_RequestSeqID(Encoding.Default.GetString(new byte[] { 0x64 }) + senddata);
        }
        string[] returnStr = GetMessage(sendStr);
        return returnStr;
    }

    /// <summary>
    /// 查詢當日平倉
    /// </summary>
    /// <param name="CustomerId"></param>
    /// <param name="CompanyID"></param>
    /// <returns></returns>
    public string[] getCurrentEquity(string FIRM, string ACTNO, String CURRENCY, String COMTYPE, String COMNO, String COMYM, String CALLPUT, String STKPRCB, String STKPRCE)
    {

        string sendStr = MOB_RequestSeqID(Encoding.Default.GetString(new byte[] { 0x21 }) + FIRM.PadRight(7, ' ') + ACTNO.PadLeft(7, '0') + CURRENCY.PadRight(3, ' ') + COMTYPE.PadRight(1, ' ') + COMNO.PadRight(7, ' ') + COMYM.PadLeft(6, '0') + CALLPUT.PadRight(1, ' ') + STKPRCB.PadLeft(9, '0') + STKPRCE.PadLeft(9, '0'));
        string[] returnStr = GetMessage(sendStr);
        return returnStr;
    }

    /// <summary>
    /// 查詢出入金
    /// </summary>
    /// <param name="CustomerId"></param>
    /// <param name="CompanyID"></param>
    /// <returns></returns>
    public string[] getCurrentWithdraw(string FIRM, string ACTNO, String CURRENCY, String STRDATE, String ENDDATE
        , String STRTIME, String ENDTIME)
    {

        string sendStr = MOB_RequestSeqID(Encoding.Default.GetString(new byte[] { 0x23 }) + FIRM.PadRight(7, ' ') + ACTNO.PadLeft(7, '0')
            + CURRENCY.PadRight(3, ' ')
            + STRDATE.PadRight(8, '0') + ENDDATE.PadRight(8, '0') + STRTIME.PadLeft(8, '0') + ENDTIME.PadRight(8, '0')
        );
        string[] returnStr = GetMessage(sendStr);
        return returnStr;
    }


    /// <summary>
    /// 查詢出入金申請
    /// </summary>
    /// <param name="CustomerId"></param>
    /// <param name="CompanyID"></param>
    /// <returns></returns>
    public string[] getOrderWithdraw(string MTYPE, string SEQNO, String TYPE, String COMPANY, String ACTNO
        , String CURRENCY, String AMT, String TOCURRENCY, String TOMTYPE, String TOAMT
        , String ORDTM, String IP, String SOURCE, String ORDDT, String SLIPNO1, String SLIPNO2, String RCV

         )
    {

        string sendStr = MOB_RequestSeqID(Encoding.Default.GetString(new byte[] { 0x24 }) + MTYPE.PadRight(1, ' ') + SEQNO.PadLeft(9, '0')
            + TYPE.PadRight(1, ' ')
            + COMPANY.PadRight(7, ' ') + ACTNO.PadRight(7, ' ')
            + CURRENCY.PadRight(3, ' ') + AMT.PadLeft(14, '0')
             + TOCURRENCY.PadRight(3, ' ') + TOMTYPE.PadRight(1, ' ') + TOAMT.PadLeft(14, '0')
              + ORDTM.PadRight(6, ' ') + IP.PadRight(15, ' ') + SOURCE.PadRight(1, ' ') + ORDDT.PadRight(8, ' ')
              + SLIPNO1.PadRight(8, ' ') + SLIPNO2.PadRight(8, ' ') + RCV.PadRight(7, ' ')
        );
        string[] returnStr = GetMessage(sendStr);
        return returnStr;
    }


    /// <summary>
    /// 查詢高風險
    /// </summary>
    /// <param name="CustomerId"></param>
    /// <param name="CompanyID"></param>
    /// <returns></returns>
    public string[] getRateForAE(string FIRM, string AENO, int RATE)
    {

        string signRATE = "0";
        string strRATE = "0";

        if (RATE > 0)
        {
            signRATE = "0";
            strRATE = RATE.ToString("000");
        }
        else
        {
            signRATE = "-";
            strRATE = (-1 * RATE).ToString("000");
        }


        string sendStr = MOB_RequestSeqID(Encoding.Default.GetString(new byte[] { 0x60 })
            + FIRM.PadRight(7, ' ') + AENO.PadRight(6, ' ') + signRATE + strRATE.PadLeft(3, '0'));
        string[] returnStr = GetMessage(sendStr);
        return returnStr;
    }


    public string[] getRateForDate(string Date)
    {




        string sendStr = MOB_RequestSeqID(Encoding.Default.GetString(new byte[] { 0x63 })
            + Date.PadRight(8, ' '));
        string[] returnStr = GetMessage(sendStr);
        return returnStr;
    }

    //20100226 added by philip  供 MOB查詢時抓 socket的strlocalip & strlocalport
    public string MOB_RequestSeqID(string subject)
    {
        string sendData = "";
        try
        {
            //string remoteIP = System.Configuration.ConfigurationManager.AppSettings["REMOTE_IP"];
            //string remotePORT = System.Configuration.ConfigurationManager.AppSettings["REMOTE_PORT"];

            ////string addressID = mobj_AccountRequestSocketClient.strlocalip + ":" + mobj_AccountRequestSocketClient.strlocalport.PadRight(5, ' ');
            //string addressID = remoteIP + ":" + remotePORT.PadRight(5, ' ');

            ////string seq = (addressID.PadLeft(21, ' ') + "1".ToString().PadLeft(6, ' ')).PadLeft(27, ' ');
            //string seq = (addressID.PadLeft(21, ' ') + "1".ToString().PadLeft(6, ' ')).PadLeft(27, ' ');

            //sendData = "15" + seq + subject;
            //sendData = seq + subject;
            sendData = subject;
        }
        catch (Exception ex)
        {
            //AEFutureMaster.frmMain.AOBJ_ErrLog.WriteError(ex.Source, ex.StackTrace.ToString(), ex.Message, System.Diagnostics.EventLogEntryType.Error);

        }
        return sendData;
    }

    /// <summary>
    /// 取得多商品行情
    /// </summary>
    /// <param name="CustomerId"></param>
    /// <param name="currency"></param>
    /// <param name="CompanyID"></param>
    /// <returns></returns>
    public string[] getInfoByProducts(string productstring)
    {
        string senddata = "";
        foreach (string p in productstring.Split(','))
        {
            senddata += p.PadRight(20, ' ');
        }
        string sendStr = MOB_RequestSeqID(Encoding.Default.GetString(new byte[] { 0x74 }) + senddata);
        string[] returnStr = GetMessage(sendStr);
        return returnStr;
    }
    /// <summary>
    /// 現貨價查詢
    /// </summary>
    /// <param name="CustomerId"></param>
    /// <param name="currency"></param>
    /// <param name="CompanyID"></param>
    /// <returns></returns>
    public string[] getMOB_StockPrice(string kindid)
    {

        string sendStr = MOB_RequestSeqID(Encoding.Default.GetString(new byte[] { 0x76 }) + kindid.PadRight(20, ' '));
        string[] returnStr = GetMessage(sendStr);
        return returnStr;
    }

}
