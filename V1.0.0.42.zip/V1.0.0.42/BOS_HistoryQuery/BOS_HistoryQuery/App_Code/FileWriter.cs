﻿using System;
using System.Collections.Generic;
 
using System.Text;
using System.IO;
using System.Diagnostics;
namespace com.ddsc.tool
{
    public class Date
    {
        static DateTime now = DateTime.Now;
        static Stopwatch SW;
        private DateTime _Time;

        public DateTime Time
        {
            get
            {
                return _Time;
            }
        }
        private long _MS;

        public long MS
        {
            get { return _MS; }

        }


        public Date()
        {
            _Time = NowTime();
            _MS = NowMS();
        }
        public static long ElapsedMicroSeconds()
        {
            if (SW == null)
            {
                SW = new Stopwatch();
            }


            if (!SW.IsRunning)
            {
                now = DateTime.Now;
                SW.Reset();
                SW.Start();
            }
            return SW.ElapsedTicks * 1000000 / Stopwatch.Frequency;
        }


        public static long NowMS()
        {
            if (SW == null)
            {
                SW = new Stopwatch();
            }


            if (!SW.IsRunning)
            {
                now = DateTime.Now;
                SW.Reset();
                SW.Start();
            }

            return SW.ElapsedMilliseconds;
        }


        public static DateTime NowTime()
        {
            if (SW == null)
            {
                SW = new Stopwatch();
            }


            if (!SW.IsRunning)
            {
                now = DateTime.Now;
                SW.Reset();
                SW.Start();
            }

            DateTime boot = now + SW.Elapsed;
            return boot;
        }
    }



    public class FileWriter
    {
        private object lockerForLog = new object();
        BinaryWriter writer;
        StreamWriter sw_Log;

        private string ASTR_FileName = null;
        private string ASTR_FolderName = null;

        public FileWriter(string STR_FileName)
        {

            initWriter("", "", STR_FileName, "");

        }

        public FileWriter(string BasePath, string STR_FileName)
        {

            initWriter(BasePath, "", STR_FileName, "");

        }

        public FileWriter(string BasePath, string STR_FileName, string Dir)
        {

            initWriter(BasePath, "", STR_FileName, Dir);

        }
        public FileWriter(string BasePath, string ParentDirectory, string STR_FileName, string SubDirectory)
        {

            initWriter(BasePath, ParentDirectory, STR_FileName, SubDirectory);

        }
        public void initWriter(string BasePath, string ParentDirectory, string STR_FileName, string SubDirectory)
        {

            try
            {
                ASTR_FileName = STR_FileName;
                if (ParentDirectory.Trim().Length == 0)
                {
                    if (BasePath.Trim().Length > 0)
                    {
                        if (SubDirectory.Trim().Length > 0)
                            ASTR_FolderName = BasePath.TrimEnd() + "\\Log\\" + DateTime.Now.ToString("yyyyMMdd") + "\\" + SubDirectory;
                        else
                            ASTR_FolderName = BasePath.TrimEnd() + "\\Log\\" + DateTime.Now.ToString("yyyyMMdd");
                    }
                    else
                    {
                        if (SubDirectory.Trim().Length > 0)
                            ASTR_FolderName = AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "\\Log\\" + DateTime.Now.ToString("yyyyMMdd") + "\\" + SubDirectory;
                        else
                            ASTR_FolderName = AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "\\Log\\" + DateTime.Now.ToString("yyyyMMdd");
                    }
                }
                else //
                {
                    if (BasePath.Trim().Length > 0)
                    {
                        if (SubDirectory.Trim().Length > 0)
                            ASTR_FolderName = BasePath.TrimEnd() + "\\Log\\" + ParentDirectory + "\\" + SubDirectory;
                        else
                            ASTR_FolderName = BasePath.TrimEnd() + "\\Log\\" + ParentDirectory;
                    }
                    else
                    {
                        if (SubDirectory.Trim().Length > 0)
                            ASTR_FolderName = AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "\\Log\\" + ParentDirectory + "\\" + SubDirectory;
                        else
                            ASTR_FolderName = AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "\\Log\\" + ParentDirectory;
                    }
                }
                //   ASTR_FolderName = AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "\\Log\\" + DateTime.Now.ToString("yyyyMMdd");

                if (!Directory.Exists(ASTR_FolderName))
                {
                    Directory.CreateDirectory(ASTR_FolderName);
                }
                if (!Directory.Exists(ASTR_FolderName))
                {
                    Directory.CreateDirectory(ASTR_FolderName);
                }
                string str_path = ASTR_FolderName + "\\" + ASTR_FileName + ".txt";
                if (File.Exists(str_path))
                {
                    sw_Log = File.AppendText(str_path);
                }
                else
                {
                    sw_Log = File.CreateText(str_path);
                }
                writer = new BinaryWriter(sw_Log.BaseStream);

                sw_Log.WriteLine(Date.NowTime().ToString("yyyyMMdd HH:mm:ss.fff") + "-" + "Open Log File");
                sw_Log.Flush();
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }


        public void WriteLine(byte[] lineToWrite)
        {

            try
            {
                lock (this.lockerForLog)
                {
                    if (sw_Log.BaseStream != null)
                    {
                        writer.Write(ASCIIEncoding.ASCII.GetBytes(Date.NowTime().ToString("yyyyMMdd HH:mm:ss.fff") + "-"));
                        writer.Write(lineToWrite);
                        writer.Flush();
                        //sw_Log.WriteLine(DateTime.Now.ToString("yyyyMMdd HH:mm:ss.fff") + " -->:" + lineToWrite);
                        //sw_Log.Flush();
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }

        public void WriteLine(string lineToWrite)
        {
            try
            {

                lock (this.lockerForLog)
                {
                    if (sw_Log.BaseStream != null)
                    {
                        sw_Log.WriteLine(Date.NowTime().ToString("yyyyMMdd HH:mm:ss.fff") + "-" + lineToWrite);
                        sw_Log.Flush();
                    }
                }
            }
            catch (Exception ex)
            {
            }
        }

        public void Close()
        {
            if (sw_Log.BaseStream != null)
                sw_Log.Close();


        }
    }


    public class FileWriterReader
    {
        private object lockerForLog = new object();

        StreamWriter sw_Log;

        private string ASTR_FileName = null;
        private string ASTR_FolderName = null;

        public FileWriterReader(string STR_FileName)
        {
            initWriter("", STR_FileName, "");
        }
        public FileWriterReader(string BasePath, string STR_FileName)
        {

            initWriter(BasePath, STR_FileName, "");

        }

        public FileWriterReader(string BasePath, string STR_FileName, string Dir)
        {

            initWriter(BasePath, STR_FileName, Dir);

        }

        public void initWriter(string BasePath, string STR_FileName, string Dir)
        {

            try
            {
                ASTR_FileName = STR_FileName;

                if (BasePath.Trim().Length > 0)
                {
                    if (Dir.Trim().Length > 0)
                        ASTR_FolderName = BasePath.TrimEnd() + "\\Log\\" + DateTime.Now.ToString("yyyyMMdd") + "\\" + Dir;
                    else
                        ASTR_FolderName = BasePath.TrimEnd() + "\\Log\\" + DateTime.Now.ToString("yyyyMMdd");
                }
                else
                {
                    if (Dir.Trim().Length > 0)
                        ASTR_FolderName = AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "\\Log\\" + DateTime.Now.ToString("yyyyMMdd") + "\\" + Dir;
                    else
                        ASTR_FolderName = AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "\\Log\\" + DateTime.Now.ToString("yyyyMMdd");
                }


                if (!Directory.Exists(ASTR_FolderName))
                {
                    Directory.CreateDirectory(ASTR_FolderName);
                }
                if (!Directory.Exists(ASTR_FolderName))
                {
                    Directory.CreateDirectory(ASTR_FolderName);
                }
                string str_path = ASTR_FolderName + "\\" + ASTR_FileName + ".txt";
                if (File.Exists(str_path))
                {
                    sw_Log = File.AppendText(str_path);
                }
                else
                {
                    sw_Log = File.CreateText(str_path);
                }



                sw_Log.Flush();

            }
            catch (Exception ex)
            {
                throw ex;
            }


        }

        public void Write(string lineToWrite)
        {
            try
            {

                lock (this.lockerForLog)
                {
                    if (sw_Log.BaseStream != null)
                    {


                        sw_Log.WriteLine(lineToWrite);
                        sw_Log.Flush();
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }


        public void Close()
        {
            if (sw_Log.BaseStream != null)
                sw_Log.Close();



        }
    }

    public class FileALLReader
    {
        private object lockerForLog = new object();


        StreamReader sr;
        private string ASTR_FileName = null;
        private string ASTR_FolderName = null;
        public FileALLReader(string STR_FileName)
        {
            initWriter("", STR_FileName, "");
        }
        public FileALLReader(string BasePath, string STR_FileName)
        {

            initWriter(BasePath, STR_FileName, "");

        }

        public FileALLReader(string BasePath, string STR_FileName, string Dir)
        {

            initWriter(BasePath, STR_FileName, Dir);

        }

        public void initWriter(string BasePath, string STR_FileName, string Dir)
        {

            try
            {
                ASTR_FileName = STR_FileName;
                if (BasePath.Trim().Length > 0)
                {
                    if (Dir.Trim().Length > 0)
                        ASTR_FolderName = BasePath.TrimEnd() + "\\Log\\" + DateTime.Now.ToString("yyyyMMdd") + "\\" + Dir;
                    else
                        ASTR_FolderName = BasePath.TrimEnd() + "\\Log\\" + DateTime.Now.ToString("yyyyMMdd");
                }
                else
                {
                    if (Dir.Trim().Length > 0)
                        ASTR_FolderName = AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "\\Log\\" + DateTime.Now.ToString("yyyyMMdd") + "\\" + Dir;
                    else
                        ASTR_FolderName = AppDomain.CurrentDomain.BaseDirectory.ToString().TrimEnd() + "\\Log\\" + DateTime.Now.ToString("yyyyMMdd");
                }
                if (!Directory.Exists(ASTR_FolderName))
                {
                    Directory.CreateDirectory(ASTR_FolderName);
                }



                string str_path = ASTR_FolderName + "\\" + ASTR_FileName + ".txt";
                if (File.Exists(str_path))
                {
                    sr = new StreamReader(str_path);
                }


            }
            catch (Exception ex)
            {
                throw ex;
            }


        }


        public string read()
        {
            if (sr != null)
            {
                if (sr.BaseStream != null)
                {

                    return sr.ReadToEnd();
                }
                else
                    return "";
            }
            return "";



        }

        public void Close()
        {
            if (sr != null)
            {
                if (sr.BaseStream != null)
                    sr.Close();
            }

        }
    }
}
