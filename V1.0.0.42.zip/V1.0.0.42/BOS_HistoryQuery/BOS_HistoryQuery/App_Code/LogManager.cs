﻿using System;
using System.Collections.Generic;

using System.Text;
using com.ddsc.core;
namespace com.ddsc.tool
{
    public class LogManager : IDisposable
    {
        bool _EnabledPutLogTime = true;

        public bool EnabledPutLogTime
        {
            get { return _EnabledPutLogTime; }
            set { _EnabledPutLogTime = value; }
        }




        QueuePoolByLock<object[]> _QP;
        object _objLock;

        Dictionary<string, FileWriter> _listFW;
        string _path;
        public LogManager(string path)
        {
            _path = path;
            //_QP = new QueuePoolByLock<object[]>(1);
            //_listFW = new Dictionary<string, FileWriter>();
            _objLock = new object();

            //_QP.ParameterExcute += new QueuePoolByLock<object[]>.ParameterHandler(_QP_ParameterExcute);
            //_QP.Go();
        }

        void _QP_ParameterExcute(object[] ff)
        {
            try
            {

                string Key = (string)ff[0];

                lock (_objLock)
                {
                    if (_listFW.ContainsKey(Key))
                    {
                        if (ff[1] is string)
                            _listFW[Key].WriteLine((string)ff[1]);
                        if (ff[1] is byte[])
                            _listFW[Key].WriteLine((byte[])ff[1]);

                    }
                }
            }
            catch (Exception ex)
            {
            }
        }
        public bool checkFileWriter(string Key)
        {
            lock (_objLock)
            {
                return _listFW.ContainsKey(Key);
            }
        }
        public void AddFileWriter(string Key, FileWriter FW)
        {
            if (!_listFW.ContainsKey(Key))
            {
                _listFW.Add(Key, FW);
            }
        }
        public FileWriter this[string key]
        {
            get
            {

                if (_listFW.ContainsKey(key))
                    return _listFW[key];

                else
                    return null;
            }
        }


        public void WriteLog(string Key, string content)
        {
            try
            {
                lock (_objLock)
                {
                    FileWriter ff = new FileWriter(_path, Key);
                    ff.WriteLine(content);
                    ff.Close();
                }
            }
            catch (Exception ex)
            {
            }
            //if (_EnabledPutLogTime)
            //{
            //    _QP.PutData2Queue(new object[] { Key, Date.NowTime().ToString("yyyyMMddHHmmssfff") + content });

            //}
            //else
            //    _QP.PutData2Queue(new object[] { Key, content });


            //    if (_listFW.ContainsKey(Key))
            //        _listFW[Key].WriteLine(content);
            //}
        }

        public void WriteLog(string Key, byte[] content)
        {
            if (_EnabledPutLogTime)
            {
                byte[] des = new byte[content.Length + 17];
                byte[] MesageTime = ASCIIEncoding.ASCII.GetBytes(Date.NowTime().ToString("yyyyMMddHHmmssfff"));
                Array.Copy(MesageTime, 0, des, 0, MesageTime.Length);
                Array.Copy(content, 0, des, MesageTime.Length, content.Length);
                _QP.PutData2Queue(new object[] { Key, des });
            }
            else
                _QP.PutData2Queue(new object[] { Key, content });

            //lock (_objLock)
            //{
            //    if (_listFW.ContainsKey(Key))
            //        _listFW[Key].WriteLine(content);
            //}
        }
        public void CloseWriteLog(string Key)
        {
            if (_listFW.ContainsKey(Key))
            {
                _listFW[Key].Close();
                _listFW.Remove(Key);
            }
        }




        #region IDisposable 成員

        public void Dispose()
        {
            _QP.Dispose();
            foreach (string key in _listFW.Keys)
            {
                _listFW[key].Close();
            }


            _listFW.Clear();

            if (_QP != null)
            {
                _QP.Dispose();
            }
            GC.SuppressFinalize(this);


        }

        #endregion
    }
}
