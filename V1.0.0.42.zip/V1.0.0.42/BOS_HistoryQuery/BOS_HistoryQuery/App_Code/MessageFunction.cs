﻿using System;
using System.Collections.Generic;
//using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
namespace MessageServer
{


    public static class DDSCSocketHead
    {
        public const byte Connecting = 0x01;
        public const byte Connected = 0x02;

        public const byte endCode = 0x0a;
        public const byte Alive = 0x13;

        public const byte PutMessage = 0x30;
        public const byte OutMessage = 0x31;

    }

    //PutMessage  head(1) + length(4) +seq(4)+GroupID(30)+id(20) +message(600)+  +datestar(8)+dateEnd(8)+timestart(4) + timeend(4)+dataorder(4)+crtid(20)+endcode(1)
    //Connecting  head(1) + length(4) +userlevel(1)+company(7) +userid(20)  +endcode(1)
    [StructLayoutAttribute(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct PutMessageBody
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public byte[] Seq;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public byte[] MessageOption;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 30)]
        public byte[] GroupID;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
        public byte[] Id;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 600)]
        public byte[] Message;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 6)]
        public byte[] Color;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public byte[] DateStart;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public byte[] DateEnd;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public byte[] TimeStart;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public byte[] TimeEnd;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public byte[] DataOrder;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
        public byte[] CrtId;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public byte[] Company;


        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1000)]
        public byte[] HyperLink;
    }

    [StructLayoutAttribute(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct ConnectingBody
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1)]
        public byte[] UserLevel;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 7)]
        public byte[] Company;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 20)]
        public byte[] UserId;

    }
    [StructLayoutAttribute(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
    public struct OutMessageBody
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
        public byte[] Seq;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 600)]
        public byte[] Message;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
        public byte[] Color;

        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 1000)]
        public byte[] HyperLink;
    }



    public class ParserStruct<T>
    {
        public static void ByteArrayToStructure(byte[] bytearray, ref T obj)
        {
            int len = Marshal.SizeOf(obj);
            IntPtr i = Marshal.AllocHGlobal(len);
            Marshal.Copy(bytearray, 0, i, len);
            obj = (T)Marshal.PtrToStructure(i, typeof(T));
            Marshal.FreeHGlobal(i);
        }

        public static void ByteArrayToStructure(byte[] bytearray, int index, ref T obj)
        {
            int len = Marshal.SizeOf(obj);
            IntPtr i = Marshal.AllocHGlobal(len);
            Marshal.Copy(bytearray, index, i, len);
            obj = (T)Marshal.PtrToStructure(i, typeof(T));
            Marshal.FreeHGlobal(i);
        }
    }
    public class ParserFunction
    {
        public static T[] ConcatArrays<T>(params T[][] list)
        {
            int l=0;
            for (int i = 0; i < list.Length;i++ )
            {
                l += list[i].Length;
            }

            var result = new T[l]; 
            int offset = 0;
            for (int x = 0; x < list.Length; x++)
            {
                list[x].CopyTo(result, offset);
                offset += list[x].Length;
            }
            return result;
        }

        public static byte[] StructureToByteArray(object structObj)
        {
            int size = Marshal.SizeOf(structObj);
            IntPtr buffer = Marshal.AllocHGlobal(size);
            try
            {
                Marshal.StructureToPtr(structObj, buffer, false);
                byte[] bytes = new byte[size];
                Marshal.Copy(buffer, bytes, 0, size);
                return bytes;
            }
            finally
            {
                Marshal.FreeHGlobal(buffer);
            }
        }
    }
    class MessageFunction
    {
    }
}
