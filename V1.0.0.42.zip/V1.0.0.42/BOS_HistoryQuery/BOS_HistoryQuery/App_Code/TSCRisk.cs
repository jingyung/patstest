﻿using System;

namespace Common
{
    /// <summary>
    /// TSCRisk 的摘要描述。
    /// </summary>
    public class TSCRisk
    {
        public TSCRisk()
        {
            //
            // TODO: 在此加入建構函式的程式碼
            //
        }
        //		IMV, Delta, Gamma, Vega, Theta
        //		S : Futures Price
        //		X: 履約價
        //		R: 0.02
        //		C or P: Call price or Put price
        //		V: AACALLIMV function or AAPutIMV function
        //		T: (Trading days before execution/252)

        public static double R = 0.02d;
        public static double SNorm(double z)
        {
            double c1 = 2.506628;
            double c2 = 0.3193815;
            double c3 = -0.3565638;

            double c4 = 1.7814779;
            double c5 = -1.821256;
            double c6 = 1.3302744;
            int w = 0;
            if (z > 0 || z == 0)
            {
                w = 1;
            }
            else
            {
                w = -1;
            }
            double y = 1 / (1 + 0.2316419 * w * z);
            return 0.5 + w * (0.5 - (Math.Exp(-z * z / 2) / c1) * (y * (c2 + y * (c3 + y * (c4 + y * (c5 + y * c6))))));

        }
        public static double FNorm(double z)
        {
            //return 1 / Math.Sqrt((2 * 3.14159265358979)) / Math.Exp(z * z / 2);
            return 1 / Math.Sqrt((2 * Math.PI)) / Math.Exp(z * z / 2);
        }
        public static double AACALL(double s, double x, double r, double v, double t)
        {
            double d1 = (Math.Log(s / x) + (r + v * v / 2) * t) / v / Math.Sqrt(t);
            double d2 = d1 - v * Math.Sqrt(t);
            return s * SNorm(d1) - x * SNorm(d2) / Math.Exp(r * t);
        }
        public static double AAPUT(double s, double x, double r, double v, double t)
        {
            double d1 = (Math.Log(s / x) + (r + v * v / 2) * t) / v / Math.Sqrt(t);
            double d2 = d1 - v * Math.Sqrt(t);
            return x * SNorm(-d2) / Math.Exp(r * t) - s * SNorm(-d1);
        }
        public static double AACALLIMV(double s, double x, double r, double t, double c)
        {
            double v = 1;
            for (int i = 1; i <= 100; i++)
            {
                double d1 = (Math.Log(s / x) + (r + v * v / 2) * t) / v / Math.Sqrt(t);
                double d2 = d1 - v * Math.Sqrt(t);
                double c1 = s * SNorm(d1) - x * SNorm(d2) / Math.Exp(r * t);
                double T_EXP = 0;
                if (v * v / 2 > 50.6568715)
                {
                    T_EXP = 50.6568715;
                }
                else if (v * v / 2 < -50.6568715)
                {
                    T_EXP = -50.6568715;
                }
                else
                {
                    T_EXP = v * v / 2;
                }
                //double vega = 1 / Math.Sqrt((2 * 3.14159268)) / Math.Exp(T_EXP) * s * Math.Sqrt(t);
                double vega = 1 / Math.Sqrt((2 * Math.PI)) / Math.Exp(T_EXP) * s * Math.Sqrt(t);
                v = Math.Abs(v - (c1 - c) / vega);
            }
            return v;
        }
        public static double AAPUTIMV(double s, double x, double r, double t, double p)
        {
            double v = 1;
            for (int i = 1; i <= 100; i++)
            {
                double d1 = (Math.Log(s / x) + (r + v * v / 2) * t) / v / Math.Sqrt(t);
                double d2 = d1 - v * Math.Sqrt(t);
                double p1 = x * SNorm(-d2) / Math.Exp(r * t) - s * SNorm(-d1);
                double T_EXP = 0;
                if (v * v / 2 > 50.6568715)
                {
                    T_EXP = 50.6568715;
                }
                else if (v * v / 2 < -50.6568715)
                {
                    T_EXP = -50.6568715;
                }
                else
                {
                    T_EXP = v * v / 2;
                }
                //double vega = 1 / Math.Sqrt(2 * 3.14159268) / Math.Exp(T_EXP) * s * Math.Sqrt(t);
                double vega = 1 / Math.Sqrt(2 * Math.PI) / Math.Exp(T_EXP) * s * Math.Sqrt(t);
                v = Math.Abs(v - (p1 - p) / vega);
            }
            return v;
        }
        public static double AAC_DELTA(double s, double x, double r, double v, double t)
        {
            double d1 = (Math.Log(s / x) + (r + v * v / 2) * t) / v / Math.Sqrt(t);
            //double d2 = d1 - v * Math.Sqrt(t);
            return SNorm(d1);
        }
        public static double AAP_DELTA(double s, double x, double r, double v, double t)
        {
            double d1 = (Math.Log(s / x) + (r + v * v / 2) * t) / v / Math.Sqrt(t);
            //double d2 = d1 - v * Math.Sqrt(t);
            return -SNorm(-d1);
        }
        public static double AA_DELTA(double s, double x, double r, double v, double t)
        {
            double d1 = (Math.Log(s / x) + (r + v * v / 2) * t) / v / Math.Sqrt(t);
            //double d2 = d1 - v * Math.Sqrt(t);
            return SNorm(-d1);
        }
        public static double AAC_GAMMA(double s, double x, double r, double v, double t)
        {
            double d1 = (Math.Log(s / x) + (r + v * v / 2) * t) / v / Math.Sqrt(t);
            //double d2 = d1 - v * Math.Sqrt(t);
            return FNorm(d1) / s / v / Math.Sqrt(t);
        }
        public static double AAP_GAMMA(double s, double x, double r, double v, double t)
        {
            double d1 = (Math.Log(s / x) + (r + v * v / 2) * t) / v / Math.Sqrt(t);
            //double d2 = d1 - v * Math.Sqrt(t);
            return FNorm(d1) / s / v / Math.Sqrt(t);
        }
        public static double AAC_VEGA(double s, double x, double r, double v, double t)
        {
            double d1 = (Math.Log(s / x) + (r + v * v / 2) * t) / v / Math.Sqrt(t);
            //double d2 = d1 - v * Math.Sqrt(t);
            return s * FNorm(d1) * Math.Sqrt(t);
        }
        public static double AAP_VEGA(double s, double x, double r, double v, double t)
        {
            double d1 = (Math.Log(s / x) + (r + v * v / 2) * t) / v / Math.Sqrt(t);
            //double d2 = d1 - v * Math.Sqrt(t);
            return s * FNorm(d1) * Math.Sqrt(t);
        }
        public static double AAC_THETA(double s, double x, double r, double v, double t)
        {
            double d1 = (Math.Log(s / x) + (r + v * v / 2) * t) / v / Math.Sqrt(t);
            double d2 = d1 - v * Math.Sqrt(t);
            return (-s * FNorm(d1) * v / 2 / Math.Sqrt(t) - r * x * FNorm(d2) / Math.Exp(r * t)) / 365;
        }
        public static double AAP_THETA(double s, double x, double r, double v, double t)
        {
            double d1 = (Math.Log(s / x) + (r + v * v / 2) * t) / v / Math.Sqrt(t);
            double d2 = d1 - v * Math.Sqrt(t);
            return (-s * FNorm(d1) * v / 2 / Math.Sqrt(t) + r * x * FNorm(-d2) / Math.Exp(r * t)) / 365;
        }
        public static double AAIMV(string cp, double s, double k, double r, double t, double p)
        {
            double v = 1;
            double diff = 0;
            int i = cp.ToUpper() == "C" ? 1 : -1;
            if (s == 0) s = 0.00000001;
            if (k == 0) k = 0.00000001;
            if (t == 0) t = 0.00000001;
            if (p == 0) p = 0.00000001;
            while (true)
            {
                double vega = cp.ToUpper() == "C" ? AAC_VEGA(s, k, r, v, t) : AAP_VEGA(s, k, r, v, t);
                double p1 = BSPrice(cp, s, k, r, t, v);
                diff = (p1 - p) / vega;
                v = v - diff;
                if (Math.Abs(diff) <= 0.0001) break;
            }
            return Math.Abs(v);
        }

        public static double BSPrice(string cp, double s, double k, double r, double t, double v)
        {
            if (s == 0) s = 0.00000001;
            if (k == 0) k = 0.00000001;
            if (t == 0) t = 0.00000001;
            if (v == 0) v = 0.00000001;
            int i = cp.ToUpper() == "C" ? 1 : -1;
            double d1 = (Math.Log(s / k) + (r + v * v / 2) * t) / v / Math.Sqrt(t);
            double d2 = d1 - v * Math.Sqrt(t);
            return i * s * CND(i * d1) - i * k * Math.Exp(-r * t) * CND(i * d2);
        }

        public static double CND(double X)
        {
            double L = 0.0;
            double K = 0.0;
            double dCND = 0.0;
            const double a1 = 0.31938153;
            const double a2 = -0.356563782;
            const double a3 = 1.781477937;
            const double a4 = -1.821255978;
            const double a5 = 1.330274429;

            L = Math.Abs(X);
            K = 1.0 / (1.0 + 0.2316419 * L);
            dCND = 1.0 - 1.0 / Math.Sqrt(2 * Convert.ToDouble(Math.PI.ToString())) * Math.Exp(-L * L / 2.0) * (a1 * K + a2 * K * K + a3 * Math.Pow(K, 3.0) + a4 * Math.Pow(K, 4.0) + a5 * Math.Pow(K, 5.0));

            if (X < 0)
            {
                return 1.0 - dCND;
            }
            else
            {
                return dCND;
            }
        }
    }
}